import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { polls } from "@/db/schema";
import { desc } from "drizzle-orm";
import { pollToJson } from "@/lib/serialize";
import { canManageSite } from "@/lib/auth";

export const dynamic = "force-dynamic";

function normalizeOptions(input: unknown): { id: string; text: string; votes: number }[] {
  if (!Array.isArray(input)) return [];
  return input
    .map((o, i) => {
      const obj = (o || {}) as { id?: string; text?: string; votes?: number };
      return {
        id: String(obj.id || `o${i + 1}`),
        text: String(obj.text || "").slice(0, 160),
        votes: Math.max(0, Number(obj.votes) || 0),
      };
    })
    .filter((o) => o.text.trim() !== "")
    .slice(0, 10);
}

export async function GET() {
  const rows = await db
    .select()
    .from(polls)
    .orderBy(desc(polls.pinned), desc(polls.createdAt))
    .limit(50);
  return NextResponse.json({ polls: rows.map(pollToJson) });
}

export async function POST(req: NextRequest) {
  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek" }, { status: 400 });
  }
  const question = String(body.question || "").trim();
  if (!question)
    return NextResponse.json({ error: "Anket sorusu gerekli" }, { status: 400 });
  const options = normalizeOptions(body.options);
  if (options.length < 2)
    return NextResponse.json(
      { error: "En az 2 seçenek girmelisiniz" },
      { status: 400 }
    );
  const [row] = await db
    .insert(polls)
    .values({
      question: question.slice(0, 300),
      description: String(body.description || "").slice(0, 600),
      options: JSON.stringify(options),
      position: ["feed-top", "feed-inline", "emlak-top", "sikayet-top"].includes(
        String(body.position)
      )
        ? String(body.position)
        : "feed-top",
      active: body.active === undefined ? true : !!body.active,
      pinned: !!body.pinned,
      multi: !!body.multi,
      showResults: body.showResults === undefined ? true : !!body.showResults,
    })
    .returning();
  return NextResponse.json({ poll: pollToJson(row) });
}
