import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { pollVotes, polls } from "@/db/schema";
import { and, eq } from "drizzle-orm";
import { pollToJson } from "@/lib/serialize";
import { getClientIp } from "@/lib/ip";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const pid = Number(id);
  if (!pid) return NextResponse.json({ error: "Geçersiz id" }, { status: 400 });
  let body: { optionId?: string };
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek" }, { status: 400 });
  }
  const optionId = String(body.optionId || "");
  if (!optionId)
    return NextResponse.json({ error: "Seçenek belirtilmedi" }, { status: 400 });

  const [poll] = await db.select().from(polls).where(eq(polls.id, pid)).limit(1);
  if (!poll) return NextResponse.json({ error: "Anket bulunamadı" }, { status: 404 });
  if (!poll.active)
    return NextResponse.json({ error: "Bu anket kapatılmış" }, { status: 400 });

  const ip = await getClientIp();
  const existing = await db
    .select()
    .from(pollVotes)
    .where(and(eq(pollVotes.pollId, pid), eq(pollVotes.ip, ip)))
    .limit(1);
  if (existing.length > 0) {
    return NextResponse.json(
      { error: "Bu ankete zaten oy verdiniz", poll: pollToJson(poll), already: true },
      { status: 409 }
    );
  }

  let options: { id: string; text: string; votes: number }[] = [];
  try {
    options = JSON.parse(poll.options || "[]");
  } catch {
    options = [];
  }
  const target = options.find((o) => o.id === optionId);
  if (!target)
    return NextResponse.json({ error: "Geçersiz seçenek" }, { status: 400 });
  target.votes = Number(target.votes || 0) + 1;

  await db.insert(pollVotes).values({ pollId: pid, optionId, ip });
  const [row] = await db
    .update(polls)
    .set({ options: JSON.stringify(options) })
    .where(eq(polls.id, pid))
    .returning();

  return NextResponse.json({ poll: pollToJson(row), voted: optionId });
}
