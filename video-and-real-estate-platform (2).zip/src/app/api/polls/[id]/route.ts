import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { pollVotes, polls } from "@/db/schema";
import { eq } from "drizzle-orm";
import { pollToJson } from "@/lib/serialize";
import { canManageSite } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  const { id } = await ctx.params;
  const pid = Number(id);
  if (!pid) return NextResponse.json({ error: "Geçersiz id" }, { status: 400 });
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek" }, { status: 400 });
  }
  const patch: Record<string, unknown> = {};
  if (body.question !== undefined)
    patch.question = String(body.question).slice(0, 300);
  if (body.description !== undefined)
    patch.description = String(body.description).slice(0, 600);
  if (body.position !== undefined)
    patch.position = ["feed-top", "feed-inline", "emlak-top", "sikayet-top"].includes(
      String(body.position)
    )
      ? String(body.position)
      : "feed-top";
  if (body.active !== undefined) patch.active = !!body.active;
  if (body.pinned !== undefined) patch.pinned = !!body.pinned;
  if (body.multi !== undefined) patch.multi = !!body.multi;
  if (body.showResults !== undefined) patch.showResults = !!body.showResults;
  if (Array.isArray(body.options)) {
    const opts = (body.options as unknown[])
      .map((o, i) => {
        const obj = (o || {}) as { id?: string; text?: string; votes?: number };
        return {
          id: String(obj.id || `o${i + 1}`),
          text: String(obj.text || "").slice(0, 160),
          votes: Math.max(0, Number(obj.votes) || 0),
        };
      })
      .filter((o) => o.text.trim() !== "")
      .slice(0, 10);
    if (opts.length >= 2) patch.options = JSON.stringify(opts);
  }
  // Oyları sıfırla
  if (body.resetVotes) {
    const [cur] = await db.select().from(polls).where(eq(polls.id, pid)).limit(1);
    if (cur) {
      const opts = JSON.parse(cur.options || "[]") as {
        id: string;
        text: string;
        votes: number;
      }[];
      patch.options = JSON.stringify(opts.map((o) => ({ ...o, votes: 0 })));
      await db.delete(pollVotes).where(eq(pollVotes.pollId, pid));
    }
  }
  const [row] = await db
    .update(polls)
    .set(patch)
    .where(eq(polls.id, pid))
    .returning();
  if (!row) return NextResponse.json({ error: "Bulunamadı" }, { status: 404 });
  return NextResponse.json({ poll: pollToJson(row) });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  const { id } = await ctx.params;
  const pid = Number(id);
  if (!pid) return NextResponse.json({ error: "Geçersiz id" }, { status: 400 });
  await db.delete(polls).where(eq(polls.id, pid));
  await db.delete(pollVotes).where(eq(pollVotes.pollId, pid));
  return NextResponse.json({ ok: true });
}
