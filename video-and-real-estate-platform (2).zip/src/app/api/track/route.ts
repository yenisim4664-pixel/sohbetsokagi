import { NextRequest, NextResponse } from "next/server";
import { getClientIp, recordVisit } from "@/lib/ip";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  let path = "/";
  try {
    const body = (await req.json()) as { path?: string };
    if (body.path && typeof body.path === "string") path = body.path.slice(0, 200);
  } catch {
    // varsayılan kalsın
  }
  const ip = await getClientIp();
  const ua = req.headers.get("user-agent") || "";
  await recordVisit(ip, path, ua);
  return NextResponse.json({ ok: true });
}
