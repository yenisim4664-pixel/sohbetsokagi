import { NextRequest, NextResponse } from "next/server";
import { promises as fs } from "fs";
import { existsSync } from "fs";
import path from "path";
import crypto from "crypto";
import { spawnSync } from "child_process";
import { getClientIp, isIpBanned } from "@/lib/ip";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

/** Ziyaretçiler için şikayet medyası yükleme (sınırlı, güvenli) */
const MAX_SIZE = 60 * 1024 * 1024; // 60MB

const EXT_MAP: Record<string, string> = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
  "video/mp4": ".mp4",
  "video/webm": ".webm",
  "video/quicktime": ".mov",
};

let ffmpegChecked: boolean | null = null;
function hasFfmpeg(): boolean {
  if (ffmpegChecked !== null) return ffmpegChecked;
  try {
    ffmpegChecked = spawnSync("ffmpeg", ["-version"], { stdio: "ignore" }).status === 0;
  } catch {
    ffmpegChecked = false;
  }
  return ffmpegChecked;
}

export async function POST(req: NextRequest) {
  const ip = await getClientIp();
  if (await isIpBanned(ip))
    return NextResponse.json({ error: "Erişiminiz kısıtlandı" }, { status: 403 });

  try {
    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File))
      return NextResponse.json({ error: "Dosya bulunamadı" }, { status: 400 });
    const mime = file.type || "";
    const isImage = mime.startsWith("image/");
    const isVideo = mime.startsWith("video/");
    if (!isImage && !isVideo)
      return NextResponse.json(
        { error: "Sadece fotoğraf veya video yükleyebilirsiniz" },
        { status: 400 }
      );
    if (file.size > MAX_SIZE)
      return NextResponse.json(
        { error: "Dosya 60MB sınırını aşıyor" },
        { status: 400 }
      );

    const relDir = path.join("uploads", "sikayet", new Date().toISOString().slice(0, 7).replace("-", ""));
    const absDir = path.join(process.cwd(), "public", relDir);
    await fs.mkdir(absDir, { recursive: true });

    const ext = EXT_MAP[mime] || (isVideo ? ".mp4" : ".jpg");
    const name = crypto.randomBytes(8).toString("hex") + ext;
    const absPath = path.join(absDir, name);
    await fs.writeFile(absPath, Buffer.from(await file.arrayBuffer()));

    const url = "/" + path.posix.join(relDir.split(path.sep).join("/"), name);
    let posterUrl = "";
    if (isVideo && hasFfmpeg()) {
      const posterName = name.replace(ext, ".jpg");
      const posterAbs = path.join(absDir, posterName);
      try {
        spawnSync(
          "ffmpeg",
          ["-y", "-ss", "1", "-i", absPath, "-frames:v", "1", "-q:v", "4", posterAbs],
          { stdio: "ignore", timeout: 30_000 }
        );
        if (existsSync(posterAbs))
          posterUrl = "/" + path.posix.join(relDir.split(path.sep).join("/"), posterName);
      } catch {
        posterUrl = "";
      }
    }

    return NextResponse.json({
      url,
      posterUrl,
      mediaType: isVideo ? "video" : "image",
      size: file.size,
    });
  } catch {
    return NextResponse.json({ error: "Yükleme başarısız" }, { status: 500 });
  }
}
