import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { complaints } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { complaintToJson } from "@/lib/serialize";
import { canManageSite } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const cid = Number(id);
  if (!cid) return NextResponse.json({ error: "Geçersiz id" }, { status: 400 });
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek" }, { status: 400 });
  }

  // Herkese açık görüntülenme sayacı
  if (body.action === "view") {
    await db
      .update(complaints)
      .set({ views: sql`${complaints.views} + 1` })
      .where(eq(complaints.id, cid));
    return NextResponse.json({ ok: true });
  }

  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });

  const patch: Record<string, unknown> = {};
  if (body.title !== undefined) patch.title = String(body.title).slice(0, 160);
  if (body.body !== undefined) patch.body = String(body.body).slice(0, 2500);
  if (body.name !== undefined) patch.name = String(body.name).slice(0, 80);
  if (body.district !== undefined)
    patch.district = String(body.district).slice(0, 60);
  if (body.mediaUrl !== undefined)
    patch.mediaUrl = String(body.mediaUrl).slice(0, 500);
  if (body.posterUrl !== undefined)
    patch.posterUrl = String(body.posterUrl).slice(0, 500);
  if (body.mediaType !== undefined)
    patch.mediaType = body.mediaType === "video" ? "video" : "image";
  if (body.adminNote !== undefined)
    patch.adminNote = String(body.adminNote).slice(0, 300);
  if (body.pinned !== undefined) patch.pinned = !!body.pinned;
  if (body.status !== undefined) {
    const s = String(body.status);
    patch.status = ["onaylandi", "reddedildi", "beklemede"].includes(s)
      ? s
      : "beklemede";
    patch.reviewedAt = new Date();
  }

  const [row] = await db
    .update(complaints)
    .set(patch)
    .where(eq(complaints.id, cid))
    .returning();
  if (!row) return NextResponse.json({ error: "Bulunamadı" }, { status: 404 });
  return NextResponse.json({ complaint: complaintToJson(row) });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  const { id } = await ctx.params;
  const cid = Number(id);
  if (!cid) return NextResponse.json({ error: "Geçersiz id" }, { status: 400 });
  await db.delete(complaints).where(eq(complaints.id, cid));
  return NextResponse.json({ ok: true });
}
