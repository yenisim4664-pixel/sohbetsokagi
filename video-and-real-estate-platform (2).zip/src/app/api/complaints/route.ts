import { NextRequest, NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/db";
import { complaints } from "@/db/schema";
import { and, desc, eq, gt, sql } from "drizzle-orm";
import { complaintToJson } from "@/lib/serialize";
import { canManageSite } from "@/lib/auth";
import { getClientIp } from "@/lib/ip";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const scope = req.nextUrl.searchParams.get("scope") || "public";
  const manage = await canManageSite();

  if (scope === "admin") {
    if (!manage)
      return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
    const rows = await db
      .select()
      .from(complaints)
      .orderBy(desc(complaints.createdAt))
      .limit(300);
    return NextResponse.json({ complaints: rows.map(complaintToJson) });
  }

  if (scope === "mine") {
    // Ziyaretçinin kendi gönderileri (IP bazlı) — durum takibi için
    const ip = await getClientIp();
    const rows = await db
      .select()
      .from(complaints)
      .where(eq(complaints.ip, ip))
      .orderBy(desc(complaints.createdAt))
      .limit(20);
    return NextResponse.json({ complaints: rows.map(complaintToJson) });
  }

  const rows = await db
    .select()
    .from(complaints)
    .where(eq(complaints.status, "onaylandi"))
    .orderBy(desc(complaints.pinned), desc(complaints.createdAt))
    .limit(100);
  return NextResponse.json({ complaints: rows.map(complaintToJson) });
}

export async function POST(req: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek" }, { status: 400 });
  }
  const bodyText = String(body.body || "").trim();
  if (bodyText.length < 15)
    return NextResponse.json(
      { error: "Şikayet metni en az 15 karakter olmalı" },
      { status: 400 }
    );

  const ip = await getClientIp();
  // Hız sınırı: aynı IP'den son 1 saatte en fazla 3 gönderi
  const since = new Date(Date.now() - 60 * 60 * 1000);
  const recent = await db
    .select({ c: sql<number>`count(*)::int` })
    .from(complaints)
    .where(and(eq(complaints.ip, ip), gt(complaints.createdAt, since)));
  if ((recent[0]?.c ?? 0) >= 3) {
    return NextResponse.json(
      { error: "Saatte en fazla 3 şikayet gönderebilirsiniz. Lütfen sonra tekrar deneyin." },
      { status: 429 }
    );
  }

  const ticket = "SS-" + crypto.randomBytes(3).toString("hex").toUpperCase();
  const [row] = await db
    .insert(complaints)
    .values({
      name: String(body.name || "").slice(0, 80),
      district: String(body.district || "").slice(0, 60),
      title: String(body.title || "").slice(0, 160),
      body: bodyText.slice(0, 2500),
      mediaUrl: String(body.mediaUrl || "").slice(0, 500),
      mediaType: body.mediaType === "video" ? "video" : "image",
      posterUrl: String(body.posterUrl || "").slice(0, 500),
      status: "beklemede",
      ip,
      ticket,
    })
    .returning();

  return NextResponse.json({
    complaint: complaintToJson(row),
    message:
      "Şikayetiniz alındı ve yönetici onayına gönderildi. Onaylandığında Şikayetler akışında yayınlanacak.",
    ticket,
  });
}
