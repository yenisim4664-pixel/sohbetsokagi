import { NextRequest, NextResponse } from "next/server";
import { isAdminAuthed } from "@/lib/auth";
import { sendPushToAll } from "@/lib/push";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  if (!(await isAdminAuthed()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  let body: { title?: string; body?: string; url?: string };
  try {
    body = await req.json();
  } catch {
    body = {};
  }
  const result = await sendPushToAll({
    title: body.title || "Sohbet Sokağı",
    body: body.body || "Yeni bir içerik sizi bekliyor!",
    url: body.url || "/",
  });
  return NextResponse.json(result);
}
