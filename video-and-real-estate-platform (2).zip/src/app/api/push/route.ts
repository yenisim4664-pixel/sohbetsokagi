import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { pushSubs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ensureVapidKeys } from "@/lib/push";

export const dynamic = "force-dynamic";

export async function GET() {
  const keys = await ensureVapidKeys();
  return NextResponse.json({ publicKey: keys.publicKey });
}

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json()) as {
      subscription?: { endpoint?: string; keys?: { p256dh: string; auth: string } };
    };
    const sub = body.subscription;
    if (!sub?.endpoint)
      return NextResponse.json({ error: "Geçersiz abonelik" }, { status: 400 });
    await db
      .insert(pushSubs)
      .values({ endpoint: sub.endpoint, data: JSON.stringify(sub) })
      .onConflictDoUpdate({
        target: pushSubs.endpoint,
        set: { data: JSON.stringify(sub) },
      });
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Abonelik kaydedilemedi" }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const body = (await req.json()) as { endpoint?: string };
    if (body.endpoint)
      await db.delete(pushSubs).where(eq(pushSubs.endpoint, body.endpoint));
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ ok: true });
  }
}
