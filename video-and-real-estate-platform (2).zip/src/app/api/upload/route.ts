import { NextRequest, NextResponse } from "next/server";
import { canManageSite } from "@/lib/auth";
import { promises as fs } from "fs";
import { existsSync } from "fs";
import path from "path";
import crypto from "crypto";
import { spawnSync } from "child_process";

export const dynamic = "force-dynamic";
export const maxDuration = 120;

const MAX_SIZE = 150 * 1024 * 1024; // 150MB

let ffmpegChecked: boolean | null = null;
function hasFfmpeg(): boolean {
  if (ffmpegChecked !== null) return ffmpegChecked;
  try {
    const r = spawnSync("ffmpeg", ["-version"], { stdio: "ignore" });
    ffmpegChecked = r.status === 0;
  } catch {
    ffmpegChecked = false;
  }
  return ffmpegChecked;
}

const EXT_MAP: Record<string, string> = {
  "image/jpeg": ".jpg",
  "image/png": ".png",
  "image/webp": ".webp",
  "image/gif": ".gif",
  "video/mp4": ".mp4",
  "video/webm": ".webm",
  "video/quicktime": ".mov",
  "application/vnd.apple.mpegurl": ".m3u8",
};

export async function POST(req: NextRequest) {
  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  try {
    const form = await req.formData();
    const file = form.get("file");
    if (!(file instanceof File))
      return NextResponse.json({ error: "Dosya bulunamadı" }, { status: 400 });
    const mime = file.type || "application/octet-stream";
    const isImage = mime.startsWith("image/");
    const isVideo = mime.startsWith("video/");
    if (!isImage && !isVideo)
      return NextResponse.json(
        { error: "Sadece görsel veya video yükleyebilirsiniz" },
        { status: 400 }
      );
    if (file.size > MAX_SIZE)
      return NextResponse.json(
        { error: "Dosya 150MB sınırını aşıyor" },
        { status: 400 }
      );

    const ym = new Date().toISOString().slice(0, 7).replace("-", "");
    const relDir = path.join("uploads", ym);
    const absDir = path.join(process.cwd(), "public", relDir);
    await fs.mkdir(absDir, { recursive: true });

    const ext =
      EXT_MAP[mime] || path.extname(file.name || "").toLowerCase() || ".bin";
    const name = crypto.randomBytes(8).toString("hex") + ext;
    const absPath = path.join(absDir, name);
    const buf = Buffer.from(await file.arrayBuffer());
    await fs.writeFile(absPath, buf);

    const url = "/" + path.posix.join(relDir, name);
    let posterUrl = "";

    // Video ise ve sunucuda ffmpeg varsa 1. saniyeden küçük resim üret
    if (isVideo && hasFfmpeg()) {
      const posterName = name.replace(ext, ".jpg");
      const posterAbs = path.join(absDir, posterName);
      try {
        spawnSync(
          "ffmpeg",
          ["-y", "-ss", "1", "-i", absPath, "-frames:v", "1", "-q:v", "4", posterAbs],
          { stdio: "ignore", timeout: 30_000 }
        );
        if (existsSync(posterAbs)) {
          posterUrl = "/" + path.posix.join(relDir, posterName);
        }
      } catch {
        // ffmpeg yok başarısızsa postersız devam
      }
    }

    return NextResponse.json({
      url,
      posterUrl,
      mediaType: isVideo ? "video" : "image",
      size: file.size,
      name: file.name,
    });
  } catch (e) {
    console.error("Upload hatası", e);
    return NextResponse.json({ error: "Yükleme başarısız" }, { status: 500 });
  }
}
