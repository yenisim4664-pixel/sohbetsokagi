import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { listings } from "@/db/schema";
import { desc } from "drizzle-orm";
import { listingToListing } from "@/lib/serialize";
import { canManageSite } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const rows = await db
    .select()
    .from(listings)
    .orderBy(desc(listings.pinned), desc(listings.createdAt))
    .limit(200);
  return NextResponse.json({ listings: rows.map(listingToListing) });
}

export async function POST(req: NextRequest) {
  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek" }, { status: 400 });
  }
  const title = String(body.title || "").trim();
  if (!title)
    return NextResponse.json({ error: "İlan başlığı gerekli" }, { status: 400 });
  const images = Array.isArray(body.images)
    ? (body.images as unknown[]).map(String).filter(Boolean).slice(0, 10)
    : [];
  const [row] = await db
    .insert(listings)
    .values({
      title: title.slice(0, 200),
      description: String(body.description || "").slice(0, 4000),
      price: Math.max(0, Math.round(Number(body.price) || 0)),
      type: body.type === "kiralik" ? "kiralik" : "satilik",
      status: ["satildi", "kiralandi"].includes(String(body.status))
        ? String(body.status)
        : "aktif",
      rooms: String(body.rooms || "").slice(0, 20),
      area: Math.max(0, Math.round(Number(body.area) || 0)),
      floor: String(body.floor || "").slice(0, 30),
      heating: String(body.heating || "").slice(0, 40),
      district: String(body.district || "").slice(0, 60),
      images: JSON.stringify(images),
      phone: String(body.phone || "").slice(0, 20),
      pinned: !!body.pinned,
    })
    .returning();
  return NextResponse.json({ listing: listingToListing(row) });
}
