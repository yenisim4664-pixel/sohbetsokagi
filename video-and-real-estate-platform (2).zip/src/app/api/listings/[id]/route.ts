import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { listings } from "@/db/schema";
import { eq, sql } from "drizzle-orm";
import { listingToListing } from "@/lib/serialize";
import { canManageSite } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const lid = Number(id);
  if (!lid) return NextResponse.json({ error: "Geçersiz id" }, { status: 400 });
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek" }, { status: 400 });
  }

  // Herkese açık görüntülenme sayacı
  if (body.action === "view") {
    await db
      .update(listings)
      .set({ views: sql`${listings.views} + 1` })
      .where(eq(listings.id, lid));
    return NextResponse.json({ ok: true });
  }

  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });

  const patch: Record<string, unknown> = { updatedAt: new Date() };
  if (body.title !== undefined) patch.title = String(body.title).slice(0, 200);
  if (body.description !== undefined)
    patch.description = String(body.description).slice(0, 4000);
  if (body.price !== undefined)
    patch.price = Math.max(0, Math.round(Number(body.price) || 0));
  if (body.type !== undefined)
    patch.type = body.type === "kiralik" ? "kiralik" : "satilik";
  if (body.status !== undefined)
    patch.status = ["satildi", "kiralandi"].includes(String(body.status))
      ? String(body.status)
      : "aktif";
  if (body.rooms !== undefined) patch.rooms = String(body.rooms).slice(0, 20);
  if (body.area !== undefined)
    patch.area = Math.max(0, Math.round(Number(body.area) || 0));
  if (body.floor !== undefined) patch.floor = String(body.floor).slice(0, 30);
  if (body.heating !== undefined)
    patch.heating = String(body.heating).slice(0, 40);
  if (body.district !== undefined)
    patch.district = String(body.district).slice(0, 60);
  if (body.phone !== undefined) patch.phone = String(body.phone).slice(0, 20);
  if (body.pinned !== undefined) patch.pinned = !!body.pinned;
  if (Array.isArray(body.images))
    patch.images = JSON.stringify(
      (body.images as unknown[]).map(String).filter(Boolean).slice(0, 10)
    );

  const [row] = await db
    .update(listings)
    .set(patch)
    .where(eq(listings.id, lid))
    .returning();
  if (!row) return NextResponse.json({ error: "Bulunamadı" }, { status: 404 });
  return NextResponse.json({ listing: listingToListing(row) });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  const { id } = await ctx.params;
  const lid = Number(id);
  if (!lid) return NextResponse.json({ error: "Geçersiz id" }, { status: 400 });
  await db.delete(listings).where(eq(listings.id, lid));
  return NextResponse.json({ ok: true });
}
