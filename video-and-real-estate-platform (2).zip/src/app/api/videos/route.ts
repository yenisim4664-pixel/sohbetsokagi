import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { desc } from "drizzle-orm";
import { videoToPost } from "@/lib/serialize";
import { canManageSite } from "@/lib/auth";
import { getSetting, loadSiteData } from "@/lib/settings";
import { sendPushToAll } from "@/lib/push";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const offset = Math.max(0, Number(sp.get("offset")) || 0);
  const limit = Math.min(20, Math.max(1, Number(sp.get("limit")) || 4));
  const rows = await db
    .select()
    .from(videos)
    .orderBy(desc(videos.pinned), desc(videos.createdAt))
    .limit(limit + 1)
    .offset(offset);
  const hasMore = rows.length > limit;
  return NextResponse.json({
    videos: rows.slice(0, limit).map(videoToPost),
    hasMore,
  });
}

export async function POST(req: NextRequest) {
  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek" }, { status: 400 });
  }
  const videoUrl = String(body.videoUrl || "").trim();
  if (!videoUrl)
    return NextResponse.json({ error: "Video adresi gerekli" }, { status: 400 });
  const [row] = await db
    .insert(videos)
    .values({
      title: String(body.title || "").slice(0, 200),
      description: String(body.description || "").slice(0, 3000),
      videoUrl,
      posterUrl: String(body.posterUrl || ""),
      pinned: !!body.pinned,
    })
    .returning();
  // Yeni videoda tüm abonelere push bildirimi gönder
  try {
    if ((await getSetting("push_on_post")) !== "0") {
      const site = await loadSiteData();
      await sendPushToAll({
        title: site.siteName,
        body: row.title
          ? `Yeni video: ${row.title}`
          : "Yeni bir video yayınlandı!",
        url: "/",
      });
    }
  } catch {
    // Bildirim hatası paylaşımı engellemez
  }
  return NextResponse.json({ video: videoToPost(row) });
}
