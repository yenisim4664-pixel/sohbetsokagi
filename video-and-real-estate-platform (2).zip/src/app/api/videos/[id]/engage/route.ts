import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { likes, videos } from "@/db/schema";
import { and, eq, sql } from "drizzle-orm";
import { getClientIp } from "@/lib/ip";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function POST(req: NextRequest, ctx: Ctx) {
  const { id } = await ctx.params;
  const vid = Number(id);
  if (!vid) return NextResponse.json({ error: "Geçersiz id" }, { status: 400 });
  let body: { kind?: string } = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }

  if (body.kind === "view") {
    const [row] = await db
      .update(videos)
      .set({ views: sql`${videos.views} + 1` })
      .where(eq(videos.id, vid))
      .returning({ views: videos.views });
    return NextResponse.json({ views: row?.views ?? 0 });
  }

  if (body.kind === "like") {
    const ip = await getClientIp();
    const existing = await db
      .select({ id: likes.id })
      .from(likes)
      .where(and(eq(likes.videoId, vid), eq(likes.ip, ip)))
      .limit(1);
    let liked: boolean;
    if (existing.length > 0) {
      await db.delete(likes).where(eq(likes.id, existing[0].id));
      await db
        .update(videos)
        .set({ likes: sql`GREATEST(${videos.likes} - 1, 0)` })
        .where(eq(videos.id, vid));
      liked = false;
    } else {
      await db.insert(likes).values({ videoId: vid, ip });
      await db
        .update(videos)
        .set({ likes: sql`${videos.likes} + 1` })
        .where(eq(videos.id, vid));
      liked = true;
    }
    const [row] = await db
      .select({ likes: videos.likes })
      .from(videos)
      .where(eq(videos.id, vid))
      .limit(1);
    return NextResponse.json({ liked, likes: row?.likes ?? 0 });
  }

  return NextResponse.json({ error: "Geçersiz işlem" }, { status: 400 });
}
