import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { eq } from "drizzle-orm";
import { videoToPost } from "@/lib/serialize";
import { canManageSite } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, ctx: Ctx) {
  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  const { id } = await ctx.params;
  const vid = Number(id);
  if (!vid) return NextResponse.json({ error: "Geçersiz id" }, { status: 400 });
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek" }, { status: 400 });
  }
  const patch: Record<string, unknown> = {};
  if (body.title !== undefined) patch.title = String(body.title).slice(0, 200);
  if (body.description !== undefined)
    patch.description = String(body.description).slice(0, 3000);
  if (body.videoUrl !== undefined && String(body.videoUrl).trim())
    patch.videoUrl = String(body.videoUrl).trim();
  if (body.posterUrl !== undefined) patch.posterUrl = String(body.posterUrl);
  if (body.pinned !== undefined) patch.pinned = !!body.pinned;
  const [row] = await db
    .update(videos)
    .set(patch)
    .where(eq(videos.id, vid))
    .returning();
  if (!row) return NextResponse.json({ error: "Bulunamadı" }, { status: 404 });
  return NextResponse.json({ video: videoToPost(row) });
}

export async function DELETE(_req: NextRequest, ctx: Ctx) {
  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  const { id } = await ctx.params;
  const vid = Number(id);
  if (!vid) return NextResponse.json({ error: "Geçersiz id" }, { status: 400 });
  await db.delete(videos).where(eq(videos.id, vid));
  return NextResponse.json({ ok: true });
}
