import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { bannedIps } from "@/db/schema";
import { desc, sql } from "drizzle-orm";
import {
  createAdminSession,
  destroyAdminSession,
  hashPassword,
  isAdminAuthed,
  verifyAdminPassword,
} from "@/lib/auth";
import { getClientIp } from "@/lib/ip";
import { setSetting } from "@/lib/settings";
import { pushSubCount } from "@/lib/push";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ action: string }> };

// Basit giriş denemesi sınırlama (bellek içi)
const loginFails = new Map<string, { count: number; until: number }>();
function loginBlocked(ip: string): boolean {
  const f = loginFails.get(ip);
  if (!f) return false;
  if (f.until > Date.now()) return true;
  if (f.count >= 8 && f.until <= Date.now()) {
    loginFails.set(ip, { count: 0, until: 0 });
  }
  return false;
}
function noteFail(ip: string) {
  const f = loginFails.get(ip) || { count: 0, until: 0 };
  const count = f.count + 1;
  loginFails.set(ip, {
    count,
    until: count >= 8 ? Date.now() + 10 * 60 * 1000 : 0,
  });
}

const SETTING_WHITELIST = new Set([
  "site_name",
  "tagline",
  "logo_url",
  "footer_text",
  "theme",
  "owner",
  "seo",
  "banners",
  "owner_ips",
  "push_on_post",
  "watermark",
  "dark_theme",
  "dark_enabled",
  "complaints_enabled",
  "complaint_intro",
]);

export async function GET(req: NextRequest, ctx: Ctx) {
  const { action } = await ctx.params;

  if (action === "me") {
    return NextResponse.json({
      authed: await isAdminAuthed(),
      ip: await getClientIp(),
    });
  }

  if (!(await isAdminAuthed()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });

  if (action === "stats") {
    const v = await db.execute(
      sql`SELECT COUNT(*)::int AS c, COALESCE(SUM(views),0)::int AS sv, COALESCE(SUM(likes),0)::int AS sl FROM videos`
    );
    const l = await db.execute(
      sql`SELECT COUNT(*)::int AS c, COUNT(*) FILTER (WHERE status='aktif')::int AS aktif, COALESCE(SUM(views),0)::int AS sv FROM listings`
    );
    const s = await db.execute(
      sql`SELECT COUNT(*)::int AS c FROM stories WHERE expires_at > NOW()`
    );
    const today = await db.execute(
      sql`SELECT COUNT(*)::int AS c, COUNT(DISTINCT ip)::int AS u FROM visits WHERE created_at >= date_trunc('day', NOW())`
    );
    const total = await db.execute(sql`SELECT COUNT(*)::int AS c FROM visits`);
    const recent = await db.execute(
      sql`SELECT ip, path, created_at AS "createdAt" FROM visits ORDER BY id DESC LIMIT 18`
    );
    const suspicious = await db.execute(
      sql`SELECT ip, COUNT(*)::int AS hits FROM visits WHERE created_at > NOW() - INTERVAL '6 hours' GROUP BY ip HAVING COUNT(*) > 120 ORDER BY hits DESC LIMIT 12`
    );
    const pollsAgg = await db.execute(
      sql`SELECT COUNT(*)::int AS c, COUNT(*) FILTER (WHERE active)::int AS aktif FROM polls`
    );
    const complaintsAgg = await db.execute(
      sql`SELECT COUNT(*)::int AS c, COUNT(*) FILTER (WHERE status='beklemede')::int AS bekleyen, COUNT(*) FILTER (WHERE status='onaylandi')::int AS onayli FROM complaints`
    );
    const bans = await db
      .select()
      .from(bannedIps)
      .orderBy(desc(bannedIps.createdAt));
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const r0 = (x: any) => (x?.rows?.[0] ?? {}) as Record<string, number>;
    return NextResponse.json({
      videos: r0(v).c ?? 0,
      totalViews: r0(v).sv ?? 0,
      totalLikes: r0(v).sl ?? 0,
      listings: r0(l).c ?? 0,
      activeListings: r0(l).aktif ?? 0,
      listingViews: r0(l).sv ?? 0,
      activeStories: r0(s).c ?? 0,
      visitsToday: r0(today).c ?? 0,
      uniqueToday: r0(today).u ?? 0,
      visitsTotal: r0(total).c ?? 0,
      pushSubs: await pushSubCount(),
      polls: r0(pollsAgg).c ?? 0,
      activePolls: r0(pollsAgg).aktif ?? 0,
      complaints: r0(complaintsAgg).c ?? 0,
      pendingComplaints: r0(complaintsAgg).bekleyen ?? 0,
      approvedComplaints: r0(complaintsAgg).onayli ?? 0,
      recentVisits: recent.rows ?? [],
      suspicious: suspicious.rows ?? [],
      bans: bans.map((b) => ({
        id: b.id,
        ip: b.ip,
        reason: b.reason,
        createdAt: b.createdAt,
      })),
      currentIp: await getClientIp(),
    });
  }

  return NextResponse.json({ error: "Bilinmeyen işlem" }, { status: 404 });
}

export async function POST(req: NextRequest, ctx: Ctx) {
  const { action } = await ctx.params;
  let body: Record<string, unknown> = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }

  if (action === "login") {
    const ip = await getClientIp();
    if (loginBlocked(ip))
      return NextResponse.json(
        { error: "Çok fazla hatalı deneme. 10 dakika bekleyin." },
        { status: 429 }
      );
    const ok = await verifyAdminPassword(String(body.password || ""));
    if (!ok) {
      noteFail(ip);
      return NextResponse.json({ error: "Şifre hatalı" }, { status: 401 });
    }
    loginFails.delete(ip);
    await createAdminSession();
    return NextResponse.json({ ok: true });
  }

  if (action === "logout") {
    await destroyAdminSession();
    return NextResponse.json({ ok: true });
  }

  if (!(await isAdminAuthed()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });

  if (action === "settings") {
    const key = String(body.key || "");
    if (!SETTING_WHITELIST.has(key))
      return NextResponse.json({ error: "Geçersiz ayar" }, { status: 400 });
    const value = typeof body.value === "string" ? body.value : JSON.stringify(body.value);
    if (["theme", "owner", "seo", "banners", "watermark", "dark_theme"].includes(key)) {
      try {
        JSON.parse(value);
      } catch {
        return NextResponse.json({ error: "Geçersiz JSON" }, { status: 400 });
      }
    }
    await setSetting(key, value);
    return NextResponse.json({ ok: true });
  }

  if (action === "password") {
    const ok = await verifyAdminPassword(String(body.current || ""));
    if (!ok)
      return NextResponse.json({ error: "Mevcut şifre hatalı" }, { status: 401 });
    const next = String(body.next || "");
    if (next.length < 6)
      return NextResponse.json(
        { error: "Yeni şifre en az 6 karakter olmalı" },
        { status: 400 }
      );
    await setSetting("admin_password_hash", hashPassword(next));
    return NextResponse.json({ ok: true });
  }

  if (action === "ban") {
    const ip = String(body.ip || "").trim();
    if (!/^[\d.:a-fA-F]{3,45}$/.test(ip))
      return NextResponse.json({ error: "Geçersiz IP adresi" }, { status: 400 });
    await db
      .insert(bannedIps)
      .values({ ip, reason: String(body.reason || "").slice(0, 200) })
      .onConflictDoNothing();
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "Bilinmeyen işlem" }, { status: 404 });
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  const { action } = await ctx.params;
  if (!(await isAdminAuthed()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });

  if (action === "ban") {
    let ip = req.nextUrl.searchParams.get("ip") || "";
    if (!ip) {
      try {
        const body = (await req.json()) as { ip?: string };
        ip = body.ip || "";
      } catch {
        ip = "";
      }
    }
    if (!ip) return NextResponse.json({ error: "IP gerekli" }, { status: 400 });
    await db.delete(bannedIps).where(sql`${bannedIps.ip} = ${ip}`);
    return NextResponse.json({ ok: true });
  }

  return NextResponse.json({ error: "Bilinmeyen işlem" }, { status: 404 });
}
