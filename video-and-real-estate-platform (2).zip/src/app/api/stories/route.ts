import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { stories } from "@/db/schema";
import { asc, eq, gt, lt } from "drizzle-orm";
import { storyToItem } from "@/lib/serialize";
import { canManageSite } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  // Süresi dolan hikayeleri (24 saat) otomatik sil
  try {
    await db.delete(stories).where(lt(stories.expiresAt, new Date()));
  } catch {
    // yoksay
  }
  const rows = await db
    .select()
    .from(stories)
    .where(gt(stories.expiresAt, new Date()))
    .orderBy(asc(stories.createdAt));
  return NextResponse.json({ stories: rows.map(storyToItem) });
}

export async function POST(req: NextRequest) {
  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Geçersiz istek" }, { status: 400 });
  }
  const mediaUrl = String(body.mediaUrl || "").trim();
  if (!mediaUrl)
    return NextResponse.json({ error: "Medya adresi gerekli" }, { status: 400 });
  const hours = Math.min(48, Math.max(1, Number(body.hours) || 24));
  const mediaType = body.mediaType === "video" ? "video" : "image";
  const [row] = await db
    .insert(stories)
    .values({
      mediaUrl,
      mediaType,
      expiresAt: new Date(Date.now() + hours * 60 * 60 * 1000),
    })
    .returning();
  return NextResponse.json({ story: storyToItem(row) });
}

export async function DELETE(req: NextRequest) {
  if (!(await canManageSite()))
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  const id = Number(req.nextUrl.searchParams.get("id"));
  if (!id) return NextResponse.json({ error: "Geçersiz id" }, { status: 400 });
  await db.delete(stories).where(eq(stories.id, id));
  return NextResponse.json({ ok: true });
}
