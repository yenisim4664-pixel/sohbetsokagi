import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Sohbet Sokağı — Elbistan",
    short_name: "Sohbet Sokağı",
    description:
      "Elbistan merkezli video akışı ve emlak platformu. Giriş yok, üyelik yok.",
    start_url: "/",
    display: "standalone",
    background_color: "#FAF7F3",
    theme_color: "#FF5A3C",
    lang: "tr",
    icons: [
      {
        src: "/icons/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icons/icon-512.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  };
}
