import type { Metadata, Viewport } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin", "latin-ext"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-jakarta",
  display: "swap",
});

const BASE_URL =
  process.env.NEXT_PUBLIC_SITE_URL || "https://www.sohbetsokagi.com";

export const metadata: Metadata = {
  metadataBase: new URL(BASE_URL),
  title: {
    default: "Sohbet Sokağı — Elbistan Video Akışı ve Emlak Platformu",
    template: "%s | Sohbet Sokağı",
  },
  description:
    "Elbistan merkezli Sohbet Sokağı: şehirden akıcı videolar, 24 saatlik hikayeler ve Sohbet Sokağı Emlak ile güncel kiralık & satılık ilanları. Giriş yok, üyelik yok — herkes izleyebilir.",
  keywords: [
    "Elbistan",
    "Sohbet Sokağı",
    "Elbistan emlak",
    "Elbistan kiralık daire",
    "Elbistan satılık ev",
    "Elbistan videoları",
  ],
  applicationName: "Sohbet Sokağı",
  authors: [{ name: "Sohbet Sokağı" }],
  creator: "Sohbet Sokağı",
  publisher: "Sohbet Sokağı",
  icons: { icon: "/icons/icon-512.png", apple: "/icons/icon-512.png" },
  openGraph: {
    type: "website",
    locale: "tr_TR",
    siteName: "Sohbet Sokağı",
    title: "Sohbet Sokağı — Elbistan Video Akışı ve Emlak Platformu",
    description:
      "Elbistan'dan akıcı videolar, 24 saatlik hikayeler ve güncel emlak ilanları.",
    images: ["/icons/icon-512.png"],
  },
  twitter: {
    card: "summary_large_image",
    title: "Sohbet Sokağı",
    description: "Elbistan'ın video akışı ve emlak platformu.",
    images: ["/icons/icon-512.png"],
  },
  category: "Sosyal Medya ve Emlak",
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#FF5A3C",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="tr" className={jakarta.variable}>
      <body className="antialiased">{children}</body>
    </html>
  );
}
