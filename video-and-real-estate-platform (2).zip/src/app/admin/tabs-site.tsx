"use client";

import { useState } from "react";
import type { OwnerProfile, SeoConfig, SiteData, ThemeConfig } from "@/lib/types";
import { THEME_PRESETS, themeVars } from "@/lib/types";
import { BadgeCheck, Building2, Check, Globe } from "lucide-react";
import {
  Field,
  PrimaryBtn,
  TextArea,
  TextInput,
  Toggle,
  Uploader,
  useToast,
} from "@/components/site/ui";

type SaveFn = (key: string, value: string) => Promise<boolean>;

function SectionCard({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-[var(--line)] bg-[var(--card)] p-5">
      <h3 className="mb-4 text-[14px] font-extrabold tracking-tight">{title}</h3>
      {children}
    </section>
  );
}

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <label className="flex items-center justify-between gap-3 rounded-xl border border-[var(--line)] bg-[var(--bg)] px-3 py-2">
      <span className="text-[12px] font-bold">{label}</span>
      <span className="flex items-center gap-2">
        <span className="font-mono text-[10.5px] font-bold text-[var(--muted)]">
          {value.toUpperCase()}
        </span>
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-8 w-10 cursor-pointer rounded-lg border border-[var(--line)] bg-transparent p-0.5"
        />
      </span>
    </label>
  );
}

/* ------------------------------ GÖRÜNÜM ------------------------------ */

export function AppearanceTab({
  site,
  save,
}: {
  site: SiteData;
  save: SaveFn;
}) {
  const [theme, setTheme] = useState<ThemeConfig>(site.theme);
  const [meta, setMeta] = useState({
    siteName: site.siteName,
    tagline: site.tagline,
    logoUrl: site.logoUrl,
    footerText: site.footerText,
  });
  const [busy, setBusy] = useState(false);
  const { toast, node } = useToast();

  async function saveAll() {
    setBusy(true);
    const results = await Promise.all([
      save("theme", JSON.stringify(theme)),
      save("site_name", meta.siteName),
      save("tagline", meta.tagline),
      save("logo_url", meta.logoUrl),
      save("footer_text", meta.footerText),
    ]);
    setBusy(false);
    if (results.every(Boolean)) toast("Görünüm kaydedildi — site yenilendi");
  }

  return (
    <div className="flex flex-col gap-4">
      {node}
      <SectionCard title="Hazır Temalar">
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-5">
          {THEME_PRESETS.map((p) => {
            const selected = theme.accent === p.theme.accent && theme.bg === p.theme.bg;
            return (
              <button
                key={p.id}
                onClick={() => setTheme({ ...p.theme, radius: theme.radius })}
                className={`relative overflow-hidden rounded-2xl border-2 text-left transition active:scale-[.98] ${
                  selected
                    ? "border-[var(--accent)]"
                    : "border-[var(--line)] hover:border-[var(--muted)]"
                }`}
              >
                <span
                  className="block h-14"
                  style={{
                    background: `linear-gradient(120deg, ${p.theme.gradientFrom}, ${p.theme.gradientTo})`,
                  }}
                />
                <span
                  className="flex items-center justify-between px-3 py-2"
                  style={{ background: p.theme.card, color: p.theme.ink }}
                >
                  <span className="text-[11px] font-extrabold">{p.name}</span>
                  {selected && <Check size={13} className="text-emerald-500" />}
                </span>
              </button>
            );
          })}
        </div>
      </SectionCard>

      <SectionCard title="Renk Özelleştirme">
        <div className="grid gap-2 sm:grid-cols-2">
          <ColorField
            label="Ana renk (vurgu)"
            value={theme.accent}
            onChange={(v) => setTheme({ ...theme, accent: v })}
          />
          <ColorField
            label="Vurgu metin rengi"
            value={theme.accentInk}
            onChange={(v) => setTheme({ ...theme, accentInk: v })}
          />
          <ColorField
            label="Hikaye halkası başlangıç"
            value={theme.gradientFrom}
            onChange={(v) => setTheme({ ...theme, gradientFrom: v })}
          />
          <ColorField
            label="Hikaye halkası bitiş"
            value={theme.gradientTo}
            onChange={(v) => setTheme({ ...theme, gradientTo: v })}
          />
          <ColorField
            label="Arka plan"
            value={theme.bg}
            onChange={(v) => setTheme({ ...theme, bg: v })}
          />
          <ColorField
            label="Kart rengi"
            value={theme.card}
            onChange={(v) => setTheme({ ...theme, card: v })}
          />
          <ColorField
            label="Metin rengi"
            value={theme.ink}
            onChange={(v) => setTheme({ ...theme, ink: v })}
          />
          <ColorField
            label="Soluk metin"
            value={theme.muted}
            onChange={(v) => setTheme({ ...theme, muted: v })}
          />
          <ColorField
            label="Kenarlık"
            value={theme.line}
            onChange={(v) => setTheme({ ...theme, line: v })}
          />
          <label className="flex items-center justify-between gap-3 rounded-xl border border-[var(--line)] bg-[var(--bg)] px-3 py-2">
            <span className="text-[12px] font-bold">Köşe yuvarlaklığı</span>
            <span className="flex items-center gap-2">
              <input
                type="range"
                min={6}
                max={28}
                value={parseInt(theme.radius)}
                onChange={(e) =>
                  setTheme({ ...theme, radius: `${e.target.value}px` })
                }
                className="w-24 accent-[var(--accent)]"
              />
              <span className="font-mono text-[10.5px] font-bold text-[var(--muted)]">
                {theme.radius}
              </span>
            </span>
          </label>
        </div>

        {/* Canlı önizleme */}
        <div
          className="mt-4 rounded-2xl border border-[var(--line)] p-4"
          style={{ ...themeVars(theme), background: theme.bg } as React.CSSProperties}
        >
          <div className="flex items-center gap-2.5">
            <span
              className="flex h-9 w-9 items-center justify-center rounded-xl text-[11px] font-extrabold text-white"
              style={{
                background: `linear-gradient(45deg, ${theme.gradientFrom}, ${theme.gradientTo})`,
              }}
            >
              SS
            </span>
            <div>
              <p className="text-[13px] font-extrabold" style={{ color: theme.ink }}>
                {meta.siteName || "Sohbet Sokağı"}
              </p>
              <p className="text-[10px] font-semibold" style={{ color: theme.muted }}>
                {meta.tagline || "Elbistan"}
              </p>
            </div>
            <span
              className="ml-auto flex items-center gap-1 rounded-full px-3 py-1.5 text-[10.5px] font-extrabold"
              style={{ background: theme.accent, color: theme.accentInk }}
            >
              <Building2 size={11} /> Emlak
            </span>
          </div>
          <div
            className="mt-3 p-3"
            style={{
              background: theme.card,
              border: `1px solid ${theme.line}`,
              borderRadius: theme.radius,
            }}
          >
            <p className="flex items-center gap-1 text-[12px] font-extrabold" style={{ color: theme.ink }}>
              Örnek gönderi kartı
              <BadgeCheck size={13} className="fill-[#0095F6]" style={{ color: theme.card }} />
            </p>
            <p className="text-[11px] font-semibold" style={{ color: theme.muted }}>
              Renkleriniz canlı olarak bu şekilde görünecek.
            </p>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Logo, İsim ve Footer">
        <div className="flex flex-col gap-3">
          <div className="flex items-start gap-3">
            <div className="flex-1">
              <Field label="Site Adı">
                <TextInput
                  value={meta.siteName}
                  onChange={(e) =>
                    setMeta({ ...meta, siteName: e.target.value })
                  }
                />
              </Field>
            </div>
            {meta.logoUrl ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={meta.logoUrl}
                alt="Logo"
                className="mt-5 h-10 w-10 rounded-xl border border-[var(--line)] object-cover"
              />
            ) : null}
          </div>
          <Field label="Slogan (header altında görünür)">
            <TextInput
              value={meta.tagline}
              onChange={(e) => setMeta({ ...meta, tagline: e.target.value })}
            />
          </Field>
          <Field label="Logo URL (boş bırakılırsa SS monogramı kullanılır)">
            <TextInput
              value={meta.logoUrl}
              onChange={(e) => setMeta({ ...meta, logoUrl: e.target.value })}
              placeholder="https://.../logo.png"
            />
          </Field>
          <Uploader
            accept="image/jpeg,image/png,image/webp"
            onUploaded={(files) => {
              if (files[0]) {
                setMeta((m) => ({ ...m, logoUrl: files[0].url }));
                toast("Logo yüklendi");
              }
            }}
          >
            Logo dosyası yükle
          </Uploader>
          <Field label="Footer Metni">
            <TextArea
              rows={2}
              value={meta.footerText}
              onChange={(e) =>
                setMeta({ ...meta, footerText: e.target.value })
              }
            />
          </Field>
        </div>
      </SectionCard>

      <PrimaryBtn onClick={saveAll} disabled={busy} className="self-start">
        {busy ? "Kaydediliyor..." : "Tüm Görünüm Ayarlarını Kaydet"}
      </PrimaryBtn>
    </div>
  );
}

/* ------------------------------ PROFİL ------------------------------ */

export function ProfileTab({ site, save }: { site: SiteData; save: SaveFn }) {
  const [owner, setOwner] = useState<OwnerProfile>(site.owner);
  const [busy, setBusy] = useState(false);
  const { toast, node } = useToast();

  async function saveAll() {
    setBusy(true);
    const ok = await save("owner", JSON.stringify(owner));
    setBusy(false);
    if (ok) toast("Profil bilgileri kaydedildi");
  }

  return (
    <div className="flex flex-col gap-4">
      {node}
      <SectionCard title="Profil Kartı Önizleme">
        <div
          className="rounded-2xl border border-[var(--line)] bg-[var(--bg)] p-4"
        >
          <div className="flex items-center gap-3">
            <span className="ring-gradient rounded-full p-[2.5px]">
              {owner.avatar ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={owner.avatar}
                  alt=""
                  className="h-14 w-14 rounded-full border-2 border-[var(--bg)] object-cover"
                />
              ) : (
                <span className="flex h-14 w-14 items-center justify-center rounded-full border-2 border-[var(--bg)] bg-[var(--line)] text-xs font-extrabold">
                  SS
                </span>
              )}
            </span>
            <div>
              <p className="flex items-center gap-1.5 text-[15px] font-extrabold tracking-tight">
                {owner.name || "İsim"}
                {owner.verified && (
                  <BadgeCheck size={16} className="fill-[#0095F6] text-[var(--bg)]" />
                )}
              </p>
              <p className="text-[11.5px] font-bold text-[var(--muted)]">
                @{owner.username} · {owner.whatsapp}
              </p>
            </div>
          </div>
          {owner.bio && (
            <p className="mt-3 whitespace-pre-line text-[12.5px] font-medium text-[var(--ink)]/80">
              {owner.bio}
            </p>
          )}
        </div>
      </SectionCard>

      <SectionCard title="Profil Bilgileri">
        <div className="flex flex-col gap-3">
          <div className="grid grid-cols-2 gap-3">
            <Field label="Görünen İsim">
              <TextInput
                value={owner.name}
                onChange={(e) => setOwner({ ...owner, name: e.target.value })}
              />
            </Field>
            <Field label="Kullanıcı Adı">
              <TextInput
                value={owner.username}
                onChange={(e) =>
                  setOwner({ ...owner, username: e.target.value })
                }
              />
            </Field>
          </div>
          <Field label="Biyografi">
            <TextArea
              rows={3}
              value={owner.bio}
              onChange={(e) => setOwner({ ...owner, bio: e.target.value })}
            />
          </Field>
          <Field label="Avatar URL">
            <TextInput
              value={owner.avatar}
              onChange={(e) => setOwner({ ...owner, avatar: e.target.value })}
            />
          </Field>
          <Uploader
            accept="image/jpeg,image/png,image/webp"
            onUploaded={(files) => {
              if (files[0]) {
                setOwner((o) => ({ ...o, avatar: files[0].url }));
                toast("Avatar yüklendi");
              }
            }}
          >
            Avatar yükle
          </Uploader>
          <Toggle
            checked={owner.verified}
            onChange={(v) => setOwner({ ...owner, verified: v })}
            label="Mavi tik (doğrulanmış hesap rozeti) göster"
          />
        </div>
      </SectionCard>

      <SectionCard title="İletişim ve Yönlendirmeler">
        <div className="flex flex-col gap-3">
          <Field label="WhatsApp Numarası (90 ile başlayan, boşluksuz)">
            <TextInput
              value={owner.whatsapp}
              onChange={(e) => setOwner({ ...owner, whatsapp: e.target.value })}
              placeholder="905551112233"
            />
          </Field>
          <Field label="Instagram Profil URL">
            <TextInput
              value={owner.instagram}
              onChange={(e) =>
                setOwner({ ...owner, instagram: e.target.value })
              }
              placeholder="https://instagram.com/kullaniciadi"
            />
          </Field>
          <Field label="E-posta">
            <TextInput
              value={owner.email}
              onChange={(e) => setOwner({ ...owner, email: e.target.value })}
              placeholder="info@ornek.com"
            />
          </Field>
          <p className="rounded-xl bg-[var(--bg)] px-3.5 py-2.5 text-[11.5px] font-semibold leading-relaxed text-[var(--muted)]">
            WhatsApp butonu, Instagram butonu ve &quot;Reklam ve İş Birliği&quot;
            butonları profil sayfasında ve emlak sayfasında otomatik görünür;
            tümü bu bilgileri kullanır.
          </p>
        </div>
      </SectionCard>

      <PrimaryBtn onClick={saveAll} disabled={busy} className="self-start">
        {busy ? "Kaydediliyor..." : "Profil Ayarlarını Kaydet"}
      </PrimaryBtn>
    </div>
  );
}

/* ------------------------------ SEO ------------------------------ */

export function SeoTab({ site, save }: { site: SiteData; save: SaveFn }) {
  const [seo, setSeo] = useState<SeoConfig>(site.seo);
  const [busy, setBusy] = useState(false);
  const { toast, node } = useToast();

  async function saveAll() {
    setBusy(true);
    const ok = await save("seo", JSON.stringify(seo));
    setBusy(false);
    if (ok) toast("SEO ayarları kaydedildi");
  }

  return (
    <div className="flex flex-col gap-4">
      {node}
      <SectionCard title="Google Önizleme">
        <div className="rounded-2xl border border-[var(--line)] bg-white p-4">
          <p className="flex items-center gap-1.5 text-[11px] font-semibold text-neutral-600">
            <Globe size={11} /> sohbetsokagi.com
          </p>
          <p className="mt-1 line-clamp-1 text-[16px] font-medium text-[#1a0dab]">
            {seo.title || "Sayfa başlığı"}
          </p>
          <p className="mt-0.5 line-clamp-2 text-[12.5px] leading-snug text-neutral-600">
            {seo.description || "Sayfa açıklaması burada görünür."}
          </p>
        </div>
      </SectionCard>

      <SectionCard title="SEO Meta Etiketleri">
        <div className="flex flex-col gap-3">
          <Field label={`Site Başlığı (${seo.title.length}/70)`}>
            <TextInput
              value={seo.title}
              maxLength={70}
              onChange={(e) => setSeo({ ...seo, title: e.target.value })}
            />
          </Field>
          <Field label={`Açıklama (${seo.description.length}/160)`}>
            <TextArea
              rows={3}
              maxLength={160}
              value={seo.description}
              onChange={(e) => setSeo({ ...seo, description: e.target.value })}
            />
          </Field>
          <Field label="Anahtar Kelimeler (virgülle ayırın)">
            <TextArea
              rows={2}
              value={seo.keywords}
              onChange={(e) => setSeo({ ...seo, keywords: e.target.value })}
            />
          </Field>
          <Field label="Sosyal Paylaşım Görseli (OG Image) URL">
            <TextInput
              value={seo.ogImage}
              onChange={(e) => setSeo({ ...seo, ogImage: e.target.value })}
            />
          </Field>
          <Uploader
            accept="image/jpeg,image/png,image/webp"
            onUploaded={(files) => {
              if (files[0]) {
                setSeo((s) => ({ ...s, ogImage: files[0].url }));
                toast("OG görseli yüklendi");
              }
            }}
          >
            OG görseli yükle (1200×630 önerilir)
          </Uploader>
          <p className="rounded-xl bg-[var(--bg)] px-3.5 py-2.5 text-[11.5px] font-semibold leading-relaxed text-[var(--muted)]">
            Bunların yanında site; video gönderileri için VideoObject, ilanlar
            için RealEstateListing, profil için ProfilePage yapısal verilerini
            (schema.org JSON-LD), sitemap.xml ve robots.txt dosyalarını
            otomatik üretir.
          </p>
        </div>
      </SectionCard>

      <PrimaryBtn onClick={saveAll} disabled={busy} className="self-start">
        {busy ? "Kaydediliyor..." : "SEO Ayarlarını Kaydet"}
      </PrimaryBtn>
    </div>
  );
}
