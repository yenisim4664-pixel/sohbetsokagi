"use client";

import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import type { SiteData } from "@/lib/types";
import {
  AlertTriangle,
  BellRing,
  Building2,
  Camera,
  Clapperboard,
  Clock3,
  Eye,
  Fingerprint,
  Globe,
  Heart,
  Image as ImageIcon,
  KeyRound,
  LayoutDashboard,
  LogOut,
  Palette,
  Search,
  Send,
  ShieldCheck,
  ShieldX,
  UserCog,
  Users,
  BarChart3,
  AlertCircle,
  Droplets,
} from "lucide-react";
import {
  Field,
  GhostBtn,
  PrimaryBtn,
  TextInput,
  Toggle,
  useToast,
} from "@/components/site/ui";
import { VideosTab, StoriesTab, BannersTab } from "./tabs-content";
import { EmlakTab } from "./tabs-emlak";
import { AppearanceTab, ProfileTab, SeoTab } from "./tabs-site";
import { ComplaintsTab, PollsTab, WatermarkTab } from "./tabs-extra";

export type Stats = {
  videos: number;
  totalViews: number;
  totalLikes: number;
  listings: number;
  activeListings: number;
  listingViews: number;
  activeStories: number;
  visitsToday: number;
  uniqueToday: number;
  visitsTotal: number;
  pushSubs: number;
  polls: number;
  activePolls: number;
  complaints: number;
  pendingComplaints: number;
  approvedComplaints: number;
  recentVisits: { ip: string; path: string; createdAt: string }[];
  suspicious: { ip: string; hits: number }[];
  bans: { id: number; ip: string; reason: string; createdAt: string }[];
  currentIp: string;
};

const TABS = [
  { id: "genel", label: "Genel Bakış", icon: LayoutDashboard },
  { id: "videolar", label: "Videolar", icon: Clapperboard },
  { id: "hikayeler", label: "Hikayeler", icon: Camera },
  { id: "emlak", label: "Emlak Admini", icon: Building2 },
  { id: "anketler", label: "Anketler", icon: BarChart3 },
  { id: "sikayetler", label: "Şikayetler", icon: AlertCircle },
  { id: "banner", label: "Bannerlar", icon: ImageIcon },
  { id: "gorunum", label: "Görünüm", icon: Palette },
  { id: "filigran", label: "Filigran & Dark", icon: Droplets },
  { id: "profil", label: "Profil & İletişim", icon: UserCog },
  { id: "seo", label: "SEO", icon: Search },
  { id: "guvenlik", label: "Güvenlik", icon: ShieldCheck },
];

function fmtDate(d: string) {
  try {
    return new Date(d).toLocaleString("tr-TR", {
      day: "2-digit",
      month: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return d;
  }
}

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  sub?: string;
}) {
  return (
    <div className="rounded-2xl border border-[var(--line)] bg-[var(--card)] p-4">
      <div className="flex items-center gap-2 text-[var(--muted)]">
        <Icon size={15} className="text-[var(--accent)]" />
        <span className="text-[11px] font-extrabold uppercase tracking-wide">
          {label}
        </span>
      </div>
      <p className="mt-1.5 text-2xl font-extrabold tracking-tight">
        {typeof value === "number" ? value.toLocaleString("tr-TR") : value}
      </p>
      {sub && (
        <p className="text-[11px] font-semibold text-[var(--muted)]">{sub}</p>
      )}
    </div>
  );
}

function Card({
  title,
  icon: Icon,
  children,
  action,
}: {
  title: string;
  icon: React.ElementType;
  children: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-[var(--line)] bg-[var(--card)] p-5">
      <div className="mb-4 flex items-center justify-between">
        <h3 className="flex items-center gap-2 text-[14px] font-extrabold tracking-tight">
          <Icon size={16} className="text-[var(--accent)]" /> {title}
        </h3>
        {action}
      </div>
      {children}
    </section>
  );
}

export default function AdminApp({ site }: { site: SiteData }) {
  const [tab, setTab] = useState("genel");
  const [stats, setStats] = useState<Stats | null>(null);
  const [banIp, setBanIp] = useState("");
  const [banReason, setBanReason] = useState("");
  const [pwCur, setPwCur] = useState("");
  const [pwNew, setPwNew] = useState("");
  const [pushOnPost, setPushOnPost] = useState(site.pushOnPost);
  const [ownerIps, setOwnerIps] = useState(
    site.ownerIps ? site.ownerIps.split(",").map((s) => s.trim()).filter(Boolean) : []
  );
  const router = useRouter();
  const { toast, node } = useToast();

  const loadStats = useCallback(async () => {
    try {
      const r = await fetch("/api/admin/stats");
      if (r.ok) setStats(await r.json());
    } catch {
      // yoksay
    }
  }, []);

  useEffect(() => {
    loadStats();
  }, [loadStats, tab]);

  const saveSetting = useCallback(
    async (key: string, value: string) => {
      const r = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ key, value }),
      });
      if (r.ok) {
        toast("Kaydedildi");
        router.refresh();
        return true;
      }
      const j = await r.json().catch(() => ({}));
      toast(j.error || "Kaydedilemedi");
      return false;
    },
    [router, toast]
  );

  async function ban(ip: string, reason: string) {
    const r = await fetch("/api/admin/ban", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ip, reason }),
    });
    if (r.ok) {
      toast(`${ip} yasaklandı`);
      setBanIp("");
      setBanReason("");
      loadStats();
    } else toast("Yasaklama başarısız");
  }

  async function unban(ip: string) {
    const r = await fetch("/api/admin/ban?ip=" + encodeURIComponent(ip), {
      method: "DELETE",
    });
    if (r.ok) {
      toast("Yasak kaldırıldı");
      loadStats();
    }
  }

  async function saveOwnerIp(ip: string) {
    const next = [...new Set([...ownerIps, ip])];
    const ok = await saveSetting("owner_ips", next.join(","));
    if (ok) setOwnerIps(next);
  }

  async function removeOwnerIp(ip: string) {
    const next = ownerIps.filter((x) => x !== ip);
    const ok = await saveSetting("owner_ips", next.join(","));
    if (ok) setOwnerIps(next);
  }

  async function changePassword() {
    const r = await fetch("/api/admin/password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ current: pwCur, next: pwNew }),
    });
    const j = await r.json().catch(() => ({}));
    if (r.ok) {
      toast("Şifre güncellendi");
      setPwCur("");
      setPwNew("");
    } else toast(j.error || "Şifre değiştirilemedi");
  }

  async function testPush() {
    const r = await fetch("/api/push/send", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: site.siteName,
        body: "Test bildirimi: Bildirim sistemi sorunsuz çalışıyor!",
        url: "/",
      }),
    });
    const j = await r.json().catch(() => ({}));
    if (r.ok)
      toast(`${j.sent ?? 0} aboneye bildirim gönderildi (${j.total ?? 0} kayıt)`);
    else toast("Gönderilemedi");
  }

  async function logout() {
    await fetch("/api/admin/logout", { method: "POST" });
    router.replace("/");
    router.refresh();
  }

  return (
    <div className="pb-16">
      {node}
      {/* Üst çubuk */}
      <header className="sticky top-0 z-40 border-b border-[var(--line)] bg-[var(--bg)]/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[900px] items-center justify-between gap-3 px-4 py-3">
          <div className="flex items-center gap-2.5">
            <span className="ring-gradient flex h-9 w-9 items-center justify-center rounded-xl text-[11px] font-extrabold text-white">
              SS
            </span>
            <div>
              <p className="text-[14px] font-extrabold leading-tight tracking-tight">
                Admin Paneli
              </p>
              <p className="text-[10.5px] font-semibold text-[var(--muted)]">
                {site.siteName} · tam kontrol
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="/"
              className="flex items-center gap-1.5 rounded-full border border-[var(--line)] bg-[var(--card)] px-3.5 py-2 text-[11.5px] font-extrabold transition hover:border-[var(--accent)] hover:text-[var(--accent)]"
            >
              <Globe size={14} /> Siteyi Gör
            </a>
            <button
              onClick={logout}
              className="flex items-center gap-1.5 rounded-full bg-[var(--ink)] px-3.5 py-2 text-[11.5px] font-extrabold text-[var(--bg)] transition hover:opacity-85"
            >
              <LogOut size={14} /> Çıkış
            </button>
          </div>
        </div>
        <div className="no-scrollbar mx-auto flex max-w-[900px] gap-1 overflow-x-auto px-3 pb-2">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-2 text-[11.5px] font-extrabold transition active:scale-95 ${
                tab === t.id
                  ? "bg-[var(--accent)] text-[var(--accent-ink)] shadow"
                  : "text-[var(--muted)] hover:bg-[var(--card)] hover:text-[var(--ink)]"
              }`}
            >
              <t.icon size={14} /> {t.label}
            </button>
          ))}
        </div>
      </header>

      <main className="mx-auto max-w-[900px] px-4 pt-5">
        {tab === "genel" && (
          <div className="flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <StatCard
                icon={Users}
                label="Bugün"
                value={stats?.uniqueToday ?? "…"}
                sub={`${stats?.visitsToday ?? 0} sayfa gezinme`}
              />
              <StatCard
                icon={Eye}
                label="Toplam Ziyaret"
                value={stats?.visitsTotal ?? "…"}
                sub="tüm zamanlar"
              />
              <StatCard
                icon={Clapperboard}
                label="Video"
                value={stats?.videos ?? "…"}
                sub={`${stats?.totalViews ?? 0} izlenme`}
              />
              <StatCard
                icon={Heart}
                label="Beğeni"
                value={stats?.totalLikes ?? "…"}
                sub="tüm videolar"
              />
              <StatCard
                icon={Building2}
                label="İlan"
                value={stats?.listings ?? "…"}
                sub={`${stats?.activeListings ?? 0} aktif · ${statVal(stats?.listingViews)} görüntülenme`}
              />
              <StatCard
                icon={Camera}
                label="Aktif Hikaye"
                value={stats?.activeStories ?? "…"}
                sub="24 saat döngüsü"
              />
              <StatCard
                icon={BellRing}
                label="Bildirim Abonesi"
                value={stats?.pushSubs ?? "…"}
                sub="web push kayıtları"
              />
              <StatCard
                icon={ShieldX}
                label="Yasaklı IP"
                value={stats?.bans.length ?? "…"}
                sub="erişimi engelli"
              />
              <StatCard
                icon={BarChart3}
                label="Anket"
                value={stats?.polls ?? "…"}
                sub={`${stats?.activePolls ?? 0} aktif anket`}
              />
              <StatCard
                icon={AlertCircle}
                label="Şikayet"
                value={stats?.complaints ?? "…"}
                sub={`${stats?.pendingComplaints ?? 0} onay bekliyor`}
              />
            </div>

            {!!stats?.pendingComplaints && (
              <button
                onClick={() => setTab("sikayetler")}
                className="flex items-center gap-3 rounded-2xl border border-amber-500/30 bg-amber-500/10 px-5 py-4 text-left transition hover:bg-amber-500/15"
              >
                <AlertCircle size={20} className="shrink-0 text-amber-600" />
                <span>
                  <span className="block text-[13.5px] font-extrabold text-amber-700">
                    {stats.pendingComplaints} şikayet onayınızı bekliyor
                  </span>
                  <span className="block text-[11.5px] font-semibold text-amber-600/80">
                    İncelemek için tıklayın — onayladıklarınız filigranlı olarak yayınlanır.
                  </span>
                </span>
              </button>
            )}

            <Card
              title="Şüpheli IP Adresleri"
              icon={AlertTriangle}
              action={
                <span className="text-[10.5px] font-bold text-[var(--muted)]">
                  son 6 saatte 120+ istek
                </span>
              }
            >
              {stats?.suspicious.length ? (
                <div className="flex flex-col gap-2">
                  {stats.suspicious.map((s) => (
                    <div
                      key={s.ip}
                      className="flex items-center justify-between gap-2 rounded-xl border border-amber-500/25 bg-amber-500/5 px-3.5 py-2.5"
                    >
                      <div>
                        <p className="font-mono text-[13px] font-bold">{s.ip}</p>
                        <p className="text-[10.5px] font-bold text-amber-600">
                          {s.hits} istek / 6 saat
                        </p>
                      </div>
                      <button
                        onClick={() => ban(s.ip, "Şüpheli aktivite (otomatik tespit)")}
                        className="rounded-full bg-rose-500 px-3.5 py-1.5 text-[11px] font-extrabold text-white transition hover:opacity-90 active:scale-95"
                      >
                        Yasakla
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-[12.5px] font-semibold text-[var(--muted)]">
                  Şüpheli aktivite tespit edilmedi. Her şey normal görünüyor.
                </p>
              )}
            </Card>

            <Card title="Son Ziyaretler" icon={Clock3}>
              {stats?.recentVisits.length ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-[12px]">
                    <thead>
                      <tr className="text-[10.5px] uppercase tracking-wide text-[var(--muted)]">
                        <th className="pb-2 pr-3 font-extrabold">IP Adresi</th>
                        <th className="pb-2 pr-3 font-extrabold">Sayfa</th>
                        <th className="pb-2 font-extrabold">Zaman</th>
                      </tr>
                    </thead>
                    <tbody className="font-semibold">
                      {stats.recentVisits.map((v, i) => (
                        <tr key={i} className="border-t border-[var(--line)]">
                          <td className="py-2 pr-3 font-mono">{v.ip}</td>
                          <td className="py-2 pr-3 text-[var(--muted)]">
                            {v.path}
                          </td>
                          <td className="py-2 text-[var(--muted)]">
                            {fmtDate(v.createdAt)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <p className="text-[12.5px] font-semibold text-[var(--muted)]">
                  Henüz ziyaret kaydı yok.
                </p>
              )}
            </Card>
          </div>
        )}

        {tab === "videolar" && <VideosTab />}
        {tab === "hikayeler" && <StoriesTab />}
        {tab === "emlak" && <EmlakTab />}
        {tab === "banner" && (
          <BannersTab banners={site.banners} onSave={(b) => saveSetting("banners", JSON.stringify(b))} />
        )}
        {tab === "anketler" && <PollsTab />}
        {tab === "sikayetler" && (
          <ComplaintsTab
            watermark={site.watermark}
            intro={site.complaintIntro}
            save={saveSetting}
          />
        )}
        {tab === "filigran" && <WatermarkTab site={site} save={saveSetting} />}
        {tab === "gorunum" && <AppearanceTab site={site} save={saveSetting} />}
        {tab === "profil" && <ProfileTab site={site} save={saveSetting} />}
        {tab === "seo" && <SeoTab site={site} save={saveSetting} />}

        {tab === "guvenlik" && stats && (
          <div className="flex flex-col gap-4">
            <Card title="Sahip Cihazı — Site İçi Hızlı Paylaşım" icon={Fingerprint}>
              <p className="mb-3 text-[12.5px] font-semibold leading-relaxed text-[var(--muted)]">
                Kayıtlı IP adreslerinden siteye giren cihazlar, admin paneline
                girmeden doğrudan akış üzerinden video, hikaye ve ilan
                paylaşabilir; gönderileri yönetebilir.
              </p>
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-lg bg-[var(--bg)] px-3 py-2 font-mono text-[12.5px] font-bold">
                  Bu cihaz: {stats.currentIp}
                </span>
                <PrimaryBtn onClick={() => saveOwnerIp(stats.currentIp)}>
                  Bu Cihazı Sahip Olarak Kaydet
                </PrimaryBtn>
              </div>
              {ownerIps.length > 0 && (
                <div className="mt-3 flex flex-wrap gap-2">
                  {ownerIps.map((ip) => (
                    <span
                      key={ip}
                      className="flex items-center gap-2 rounded-full border border-[var(--line)] bg-[var(--bg)] py-1.5 pl-3.5 pr-1.5 font-mono text-[11.5px] font-bold"
                    >
                      {ip}
                      <button
                        onClick={() => removeOwnerIp(ip)}
                        className="rounded-full p-1 text-[var(--muted)] transition hover:bg-rose-500/10 hover:text-rose-500"
                        aria-label="Kaldır"
                      >
                        ✕
                      </button>
                    </span>
                  ))}
                </div>
              )}
            </Card>

            <Card title="IP Yasaklama" icon={ShieldX}>
              <div className="flex flex-col gap-2 sm:flex-row">
                <div className="flex-1">
                  <Field label="IP Adresi">
                    <TextInput
                      value={banIp}
                      onChange={(e) => setBanIp(e.target.value)}
                      placeholder="örn. 85.34.12.90"
                    />
                  </Field>
                </div>
                <div className="flex-1">
                  <Field label="Sebep (opsiyonel)">
                    <TextInput
                      value={banReason}
                      onChange={(e) => setBanReason(e.target.value)}
                      placeholder="Spam, saldırı vb."
                    />
                  </Field>
                </div>
                <div className="flex items-end">
                  <PrimaryBtn
                    onClick={() => banIp.trim() && ban(banIp.trim(), banReason)}
                    disabled={!banIp.trim()}
                    className="w-full sm:w-auto"
                  >
                    Yasakla
                  </PrimaryBtn>
                </div>
              </div>
              {stats.bans.length > 0 && (
                <div className="mt-4 flex flex-col gap-2">
                  {stats.bans.map((b) => (
                    <div
                      key={b.id}
                      className="flex items-center justify-between gap-2 rounded-xl border border-rose-500/20 bg-rose-500/5 px-3.5 py-2.5"
                    >
                      <div>
                        <p className="font-mono text-[12.5px] font-bold">
                          {b.ip}
                        </p>
                        <p className="text-[10.5px] font-semibold text-[var(--muted)]">
                          {b.reason || "Sebep belirtilmedi"} ·{" "}
                          {fmtDate(String(b.createdAt))}
                        </p>
                      </div>
                      <button
                        onClick={() => unban(b.ip)}
                        className="rounded-full border border-[var(--line)] bg-[var(--card)] px-3.5 py-1.5 text-[11px] font-extrabold transition hover:border-emerald-500 hover:text-emerald-600 active:scale-95"
                      >
                        Yasağı Kaldır
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </Card>

            <Card title="Bildirim Sistemi (Web Push)" icon={BellRing}>
              <div className="flex flex-col gap-3">
                <Toggle
                  checked={pushOnPost}
                  onChange={(v) => {
                    setPushOnPost(v);
                    saveSetting("push_on_post", v ? "1" : "0");
                  }}
                  label="Yeni video paylaşıldığında abonelere otomatik bildirim gönder"
                />
                <div className="flex items-center justify-between rounded-xl bg-[var(--bg)] px-3.5 py-2.5">
                  <span className="text-[12.5px] font-bold">
                    Kayıtlı abone: {stats.pushSubs.toLocaleString("tr-TR")}
                  </span>
                  <GhostBtn onClick={testPush} className="!py-2">
                    <Send size={14} /> Test Bildirimi Gönder
                  </GhostBtn>
                </div>
              </div>
            </Card>

            <Card title="Admin Şifresini Değiştir" icon={KeyRound}>
              <div className="flex flex-col gap-3 sm:flex-row">
                <div className="flex-1">
                  <Field label="Mevcut Şifre">
                    <TextInput
                      type="password"
                      value={pwCur}
                      onChange={(e) => setPwCur(e.target.value)}
                    />
                  </Field>
                </div>
                <div className="flex-1">
                  <Field label="Yeni Şifre (en az 6 karakter)">
                    <TextInput
                      type="password"
                      value={pwNew}
                      onChange={(e) => setPwNew(e.target.value)}
                    />
                  </Field>
                </div>
                <div className="flex items-end">
                  <PrimaryBtn
                    onClick={changePassword}
                    disabled={!pwCur || pwNew.length < 6}
                    className="w-full sm:w-auto"
                  >
                    Güncelle
                  </PrimaryBtn>
                </div>
              </div>
            </Card>
          </div>
        )}
        {tab === "guvenlik" && !stats && (
          <p className="py-10 text-center text-sm font-semibold text-[var(--muted)]">
            Yükleniyor...
          </p>
        )}
      </main>
    </div>
  );
}

function statVal(n: number | undefined) {
  return (n ?? 0).toLocaleString("tr-TR");
}
