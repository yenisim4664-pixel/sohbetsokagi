"use client";

import { useCallback, useEffect, useState } from "react";
import type { Complaint, Poll, SiteData, ThemeConfig, WatermarkConfig } from "@/lib/types";
import {
  COMPLAINT_STATUS_LABEL,
  DEFAULT_DARK_THEME,
  formatCount,
  timeAgo,
} from "@/lib/types";
import {
  BarChart3,
  Check,
  CheckCircle2,
  Clock3,
  Droplets,
  Moon,
  Pencil,
  Pin,
  Plus,
  RotateCcw,
  Trash2,
  X,
  XCircle,
} from "lucide-react";
import {
  Field,
  GhostBtn,
  Modal,
  PrimaryBtn,
  Select,
  TextArea,
  TextInput,
  Toggle,
  Uploader,
  useToast,
} from "@/components/site/ui";
import Watermark from "@/components/site/Watermark";

type SaveFn = (key: string, value: string) => Promise<boolean>;

const POSITION_LABEL: Record<string, string> = {
  "feed-top": "Akış üstü (banner alanı)",
  "feed-inline": "Akış içi (gönderiler arası)",
  "emlak-top": "Emlak sayfası üstü",
  "sikayet-top": "Şikayetler sayfası üstü",
};

const STATUS_CLS: Record<string, string> = {
  beklemede: "bg-amber-500/15 text-amber-600",
  onaylandi: "bg-emerald-500/15 text-emerald-600",
  reddedildi: "bg-rose-500/15 text-rose-500",
};

function Card({
  title,
  icon: Icon,
  children,
  action,
}: {
  title: string;
  icon: React.ElementType;
  children: React.ReactNode;
  action?: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-[var(--line)] bg-[var(--card)] p-5">
      <div className="mb-4 flex items-center justify-between gap-2">
        <h3 className="flex items-center gap-2 text-[14px] font-extrabold tracking-tight">
          <Icon size={16} className="text-[var(--accent)]" /> {title}
        </h3>
        {action}
      </div>
      {children}
    </section>
  );
}

/* ============================ ANKETLER ============================ */

type PollForm = {
  question: string;
  description: string;
  options: { id: string; text: string; votes: number }[];
  position: string;
  active: boolean;
  pinned: boolean;
  showResults: boolean;
};

const EMPTY_POLL: PollForm = {
  question: "",
  description: "",
  options: [
    { id: "o1", text: "", votes: 0 },
    { id: "o2", text: "", votes: 0 },
  ],
  position: "feed-top",
  active: true,
  pinned: false,
  showResults: true,
};

export function PollsTab() {
  const [list, setList] = useState<Poll[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<PollForm>(EMPTY_POLL);
  const [busy, setBusy] = useState(false);
  const { toast, node } = useToast();

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/polls");
      const j = await r.json();
      if (r.ok) setList(j.polls);
    } catch {
      // yoksay
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function openNew() {
    setForm({ ...EMPTY_POLL, options: EMPTY_POLL.options.map((o) => ({ ...o })) });
    setEditId(null);
    setOpen(true);
  }

  function openEdit(p: Poll) {
    setForm({
      question: p.question,
      description: p.description,
      options: p.options.map((o) => ({ ...o })),
      position: p.position,
      active: p.active,
      pinned: p.pinned,
      showResults: p.showResults,
    });
    setEditId(p.id);
    setOpen(true);
  }

  async function submit() {
    if (!form.question.trim()) return toast("Anket sorusu gerekli");
    const opts = form.options.filter((o) => o.text.trim());
    if (opts.length < 2) return toast("En az 2 seçenek girin");
    setBusy(true);
    const r = await fetch(editId ? `/api/polls/${editId}` : "/api/polls", {
      method: editId ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...form, options: opts }),
    });
    setBusy(false);
    if (r.ok) {
      setOpen(false);
      toast(editId ? "Anket güncellendi" : "Anket yayınlandı");
      load();
    } else {
      const j = await r.json().catch(() => ({}));
      toast(j.error || "İşlem başarısız");
    }
  }

  async function patch(id: number, payload: Record<string, unknown>) {
    const r = await fetch(`/api/polls/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (r.ok) load();
    else toast("İşlem başarısız");
  }

  async function remove(id: number) {
    if (!confirm("Bu anket ve tüm oyları silinsin mi?")) return;
    const r = await fetch(`/api/polls/${id}`, { method: "DELETE" });
    if (r.ok) {
      toast("Anket silindi");
      load();
    }
  }

  return (
    <div className="flex flex-col gap-3">
      {node}
      <div className="flex items-center justify-between gap-2">
        <p className="text-[13px] font-bold text-[var(--muted)]">
          {list.length} anket · banner alanında ve seçtiğiniz sayfalarda görünür
        </p>
        <PrimaryBtn onClick={openNew} className="!py-2">
          <Plus size={15} /> Yeni Anket
        </PrimaryBtn>
      </div>

      {loading ? (
        <p className="py-10 text-center text-sm font-semibold text-[var(--muted)]">
          Yükleniyor...
        </p>
      ) : list.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-[var(--line)] py-12 text-center text-sm font-semibold text-[var(--muted)]">
          Henüz anket yok — ilk anketinizi oluşturun.
        </p>
      ) : (
        list.map((p) => (
          <div
            key={p.id}
            className="rounded-2xl border border-[var(--line)] bg-[var(--card)] p-4"
          >
            <div className="flex items-start gap-3">
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-1.5 text-[13.5px] font-extrabold tracking-tight">
                  {p.pinned && (
                    <Pin size={11} className="fill-[var(--accent)] text-[var(--accent)]" />
                  )}
                  {p.question}
                </p>
                <p className="mt-0.5 flex flex-wrap items-center gap-2 text-[10.5px] font-bold text-[var(--muted)]">
                  <span className="rounded-full bg-[var(--bg)] px-2 py-0.5">
                    {POSITION_LABEL[p.position]}
                  </span>
                  <span
                    className={`rounded-full px-2 py-0.5 ${
                      p.active
                        ? "bg-emerald-500/10 text-emerald-600"
                        : "bg-[var(--bg)]"
                    }`}
                  >
                    {p.active ? "AKTİF" : "KAPALI"}
                  </span>
                  <span>{formatCount(p.totalVotes)} oy</span>
                  <span>{timeAgo(p.createdAt)}</span>
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-1">
                <button
                  onClick={() => patch(p.id, { active: !p.active })}
                  className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--bg)]"
                  title={p.active ? "Anketi kapat" : "Anketi aç"}
                >
                  {p.active ? <XCircle size={16} /> : <CheckCircle2 size={16} />}
                </button>
                <button
                  onClick={() => patch(p.id, { pinned: !p.pinned })}
                  className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--bg)]"
                  title="Üste sabitle"
                >
                  <Pin size={16} />
                </button>
                <button
                  onClick={() => {
                    if (confirm("Oylar sıfırlansın mı?")) patch(p.id, { resetVotes: true });
                  }}
                  className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--bg)]"
                  title="Oyları sıfırla"
                >
                  <RotateCcw size={16} />
                </button>
                <button
                  onClick={() => openEdit(p)}
                  className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--bg)]"
                  title="Düzenle"
                >
                  <Pencil size={16} />
                </button>
                <button
                  onClick={() => remove(p.id)}
                  className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-rose-500/10 hover:text-rose-500"
                  title="Sil"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
            <div className="mt-2.5 flex flex-col gap-1">
              {p.options.map((o) => {
                const pct = p.totalVotes ? Math.round((o.votes / p.totalVotes) * 100) : 0;
                return (
                  <div
                    key={o.id}
                    className="relative overflow-hidden rounded-lg bg-[var(--bg)] px-3 py-1.5"
                  >
                    <span
                      className="absolute inset-y-0 left-0 bg-[var(--accent)]/15"
                      style={{ width: `${pct}%` }}
                    />
                    <span className="relative flex items-center justify-between text-[11.5px] font-bold">
                      <span>{o.text}</span>
                      <span className="tabular-nums">
                        %{pct} · {formatCount(o.votes)}
                      </span>
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        ))
      )}

      <Modal
        open={open}
        onClose={() => setOpen(false)}
        title={editId ? "Anketi Düzenle" : "Yeni Anket"}
        wide
      >
        <div className="space-y-3.5">
          <Field label="Anket Sorusu *">
            <TextInput
              value={form.question}
              onChange={(e) => setForm({ ...form, question: e.target.value })}
              placeholder="Örn: Elbistan'da en acil çözülmesi gereken sorun nedir?"
            />
          </Field>
          <Field label="Açıklama (opsiyonel)">
            <TextArea
              rows={2}
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
            />
          </Field>

          <div>
            <span className="mb-1.5 block text-xs font-bold text-[var(--muted)]">
              Seçenekler (metinleri ve oy sayılarını düzenleyebilirsiniz)
            </span>
            <div className="flex flex-col gap-2">
              {form.options.map((o, i) => (
                <div key={o.id} className="flex items-center gap-2">
                  <TextInput
                    value={o.text}
                    placeholder={`Seçenek ${i + 1}`}
                    onChange={(e) => {
                      const next = [...form.options];
                      next[i] = { ...next[i], text: e.target.value };
                      setForm({ ...form, options: next });
                    }}
                  />
                  <input
                    value={o.votes}
                    inputMode="numeric"
                    title="Oy sayısı"
                    onChange={(e) => {
                      const next = [...form.options];
                      next[i] = {
                        ...next[i],
                        votes: Math.max(0, Number(e.target.value.replace(/\D/g, "")) || 0),
                      };
                      setForm({ ...form, options: next });
                    }}
                    className="w-20 shrink-0 rounded-xl border border-[var(--line)] bg-[var(--bg)] px-2.5 py-2.5 text-center text-sm font-bold focus:border-[var(--accent)] focus:outline-none"
                  />
                  {form.options.length > 2 && (
                    <button
                      onClick={() =>
                        setForm({
                          ...form,
                          options: form.options.filter((_, x) => x !== i),
                        })
                      }
                      className="shrink-0 rounded-lg p-2 text-[var(--muted)] hover:bg-rose-500/10 hover:text-rose-500"
                    >
                      <X size={16} />
                    </button>
                  )}
                </div>
              ))}
            </div>
            {form.options.length < 10 && (
              <GhostBtn
                className="mt-2 w-full !py-2"
                onClick={() =>
                  setForm({
                    ...form,
                    options: [
                      ...form.options,
                      { id: `o${Date.now()}`, text: "", votes: 0 },
                    ],
                  })
                }
              >
                <Plus size={14} /> Seçenek Ekle
              </GhostBtn>
            )}
          </div>

          <Field label="Nerede Gösterilsin?">
            <Select
              value={form.position}
              onChange={(e) => setForm({ ...form, position: e.target.value })}
            >
              {Object.entries(POSITION_LABEL).map(([k, v]) => (
                <option key={k} value={k}>
                  {v}
                </option>
              ))}
            </Select>
          </Field>
          <Toggle
            checked={form.active}
            onChange={(v) => setForm({ ...form, active: v })}
            label="Anket aktif (oy verilebilir)"
          />
          <Toggle
            checked={form.showResults}
            onChange={(v) => setForm({ ...form, showResults: v })}
            label="Oy verince sonuçları ve yüzdeleri göster"
          />
          <Toggle
            checked={form.pinned}
            onChange={(v) => setForm({ ...form, pinned: v })}
            label="Üste sabitle"
          />
          <div className="flex gap-2 pt-1">
            <GhostBtn className="flex-1" onClick={() => setOpen(false)}>
              Vazgeç
            </GhostBtn>
            <PrimaryBtn className="flex-1" onClick={submit} disabled={busy}>
              {busy ? "Kaydediliyor..." : editId ? "Güncelle" : "Yayınla"}
            </PrimaryBtn>
          </div>
        </div>
      </Modal>
    </div>
  );
}

/* ============================ ŞİKAYETLER ============================ */

export function ComplaintsTab({
  watermark,
  intro,
  save,
}: {
  watermark: WatermarkConfig;
  intro: string;
  save: SaveFn;
}) {
  const [list, setList] = useState<Complaint[]>([]);
  const [filter, setFilter] = useState("beklemede");
  const [loading, setLoading] = useState(true);
  const [edit, setEdit] = useState<Complaint | null>(null);
  const [note, setNote] = useState("");
  const [introText, setIntroText] = useState(intro);
  const { toast, node } = useToast();

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/complaints?scope=admin");
      const j = await r.json();
      if (r.ok) setList(j.complaints);
    } catch {
      // yoksay
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = list.filter((c) => (filter === "all" ? true : c.status === filter));
  const pending = list.filter((c) => c.status === "beklemede").length;

  async function patch(id: number, payload: Record<string, unknown>) {
    const r = await fetch(`/api/complaints/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (r.ok) {
      toast("Güncellendi");
      setEdit(null);
      load();
    } else toast("İşlem başarısız");
  }

  async function remove(id: number) {
    if (!confirm("Bu şikayet kalıcı olarak silinsin mi?")) return;
    const r = await fetch(`/api/complaints/${id}`, { method: "DELETE" });
    if (r.ok) {
      toast("Silindi");
      load();
    }
  }

  return (
    <div className="flex flex-col gap-3">
      {node}
      <Card title="Şikayet Modülü Ayarları" icon={Clock3}>
        <Field label="Sayfa açıklama metni (kullanıcıya gösterilir)">
          <TextArea
            rows={2}
            value={introText}
            onChange={(e) => setIntroText(e.target.value)}
          />
        </Field>
        <PrimaryBtn
          className="mt-2.5"
          onClick={() => save("complaint_intro", introText)}
        >
          Metni Kaydet
        </PrimaryBtn>
      </Card>

      <div className="flex flex-wrap items-center gap-1.5">
        {[
          ["beklemede", `Onay Bekleyen${pending ? ` (${pending})` : ""}`],
          ["onaylandi", "Yayında"],
          ["reddedildi", "Reddedilen"],
          ["all", "Tümü"],
        ].map(([id, label]) => (
          <button
            key={id}
            onClick={() => setFilter(id)}
            className={`rounded-full px-3.5 py-1.5 text-[11px] font-extrabold transition active:scale-95 ${
              filter === id
                ? "bg-[var(--ink)] text-[var(--bg)]"
                : "border border-[var(--line)] bg-[var(--card)] text-[var(--muted)]"
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {loading ? (
        <p className="py-10 text-center text-sm font-semibold text-[var(--muted)]">
          Yükleniyor...
        </p>
      ) : filtered.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-[var(--line)] py-12 text-center text-sm font-semibold text-[var(--muted)]">
          Bu filtrede şikayet yok.
        </p>
      ) : (
        filtered.map((c) => (
          <div
            key={c.id}
            className="flex gap-3 rounded-2xl border border-[var(--line)] bg-[var(--card)] p-3"
          >
            {c.mediaUrl && (
              <div className="relative h-20 w-24 shrink-0 overflow-hidden rounded-lg bg-black">
                {c.mediaType === "video" ? (
                  <video
                    src={c.mediaUrl}
                    poster={c.posterUrl || undefined}
                    className="h-full w-full object-cover"
                    muted
                    preload="metadata"
                  />
                ) : (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={c.mediaUrl} alt="" className="h-full w-full object-cover" />
                )}
                <Watermark wm={{ ...watermark, size: 9 }} />
              </div>
            )}
            <div className="min-w-0 flex-1">
              <p className="flex flex-wrap items-center gap-1.5 text-[13px] font-extrabold tracking-tight">
                <span className={`rounded-full px-2 py-0.5 text-[9.5px] ${STATUS_CLS[c.status]}`}>
                  {COMPLAINT_STATUS_LABEL[c.status]}
                </span>
                {c.title || "(Başlıksız)"}
              </p>
              <p className="mt-0.5 line-clamp-2 text-[11.5px] font-medium text-[var(--muted)]">
                {c.body}
              </p>
              <p className="mt-1 flex flex-wrap items-center gap-2 text-[10px] font-bold text-[var(--muted)]">
                <span>{c.name || "Anonim"}</span>
                {c.district && <span>· {c.district}</span>}
                <span className="font-mono">· {c.ticket}</span>
                <span>· {timeAgo(c.createdAt)}</span>
              </p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {c.status !== "onaylandi" && (
                  <button
                    onClick={() => patch(c.id, { status: "onaylandi" })}
                    className="flex items-center gap-1 rounded-full bg-emerald-500 px-3 py-1.5 text-[11px] font-extrabold text-white transition active:scale-95"
                  >
                    <Check size={11} /> Onayla
                  </button>
                )}
                {c.status !== "reddedildi" && (
                  <button
                    onClick={() => {
                      const r = prompt("Red sebebi (kullanıcıya gösterilir):", "");
                      if (r !== null)
                        patch(c.id, { status: "reddedildi", adminNote: r });
                    }}
                    className="flex items-center gap-1 rounded-full bg-rose-500 px-3 py-1.5 text-[11px] font-extrabold text-white transition active:scale-95"
                  >
                    <X size={11} /> Reddet
                  </button>
                )}
                <button
                  onClick={() => {
                    setEdit(c);
                    setNote(c.adminNote);
                  }}
                  className="flex items-center gap-1 rounded-full border border-[var(--line)] bg-[var(--bg)] px-3 py-1.5 text-[11px] font-extrabold"
                >
                  <Pencil size={11} /> Düzenle
                </button>
                <button
                  onClick={() => patch(c.id, { pinned: !c.pinned })}
                  className="flex items-center gap-1 rounded-full border border-[var(--line)] bg-[var(--bg)] px-3 py-1.5 text-[11px] font-extrabold"
                >
                  <Pin size={11} /> {c.pinned ? "Sabiti Kaldır" : "Sabitle"}
                </button>
                <button
                  onClick={() => remove(c.id)}
                  className="flex items-center gap-1 rounded-full border border-rose-500/30 bg-rose-500/10 px-3 py-1.5 text-[11px] font-extrabold text-rose-500"
                >
                  <Trash2 size={11} /> Sil
                </button>
              </div>
            </div>
          </div>
        ))
      )}

      <Modal open={!!edit} onClose={() => setEdit(null)} title="Şikayeti Düzenle" wide>
        {edit && (
          <div className="space-y-3.5">
            <Field label="Başlık">
              <TextInput
                value={edit.title}
                onChange={(e) => setEdit({ ...edit, title: e.target.value })}
              />
            </Field>
            <Field label="İçerik">
              <TextArea
                rows={4}
                value={edit.body}
                onChange={(e) => setEdit({ ...edit, body: e.target.value })}
              />
            </Field>
            <div className="grid grid-cols-2 gap-3">
              <Field label="Gönderen Adı">
                <TextInput
                  value={edit.name}
                  onChange={(e) => setEdit({ ...edit, name: e.target.value })}
                />
              </Field>
              <Field label="Mahalle">
                <TextInput
                  value={edit.district}
                  onChange={(e) => setEdit({ ...edit, district: e.target.value })}
                />
              </Field>
            </div>
            <Field label="Medya URL">
              <TextInput
                value={edit.mediaUrl}
                onChange={(e) => setEdit({ ...edit, mediaUrl: e.target.value })}
              />
            </Field>
            <Uploader
              accept="image/jpeg,image/png,image/webp,video/mp4,video/webm"
              onUploaded={(files) => {
                if (files[0])
                  setEdit({
                    ...edit,
                    mediaUrl: files[0].url,
                    mediaType: files[0].mediaType === "video" ? "video" : "image",
                    posterUrl: files[0].posterUrl || "",
                  });
              }}
            >
              Medyayı değiştir
            </Uploader>
            <Field label="Yönetici notu (red sebebi vb.)">
              <TextInput value={note} onChange={(e) => setNote(e.target.value)} />
            </Field>
            <div className="flex gap-2">
              <GhostBtn className="flex-1" onClick={() => setEdit(null)}>
                Vazgeç
              </GhostBtn>
              <PrimaryBtn
                className="flex-1"
                onClick={() =>
                  patch(edit.id, {
                    title: edit.title,
                    body: edit.body,
                    name: edit.name,
                    district: edit.district,
                    mediaUrl: edit.mediaUrl,
                    mediaType: edit.mediaType,
                    posterUrl: edit.posterUrl,
                    adminNote: note,
                  })
                }
              >
                Kaydet
              </PrimaryBtn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

/* ====================== FİLİGRAN + KARANLIK TEMA ====================== */

export function WatermarkTab({ site, save }: { site: SiteData; save: SaveFn }) {
  const [wm, setWm] = useState<WatermarkConfig>(site.watermark);
  const [dark, setDark] = useState<ThemeConfig>(site.darkTheme);
  const [darkEnabled, setDarkEnabled] = useState(site.darkEnabled);
  const [complaintsEnabled, setComplaintsEnabled] = useState(site.complaintsEnabled);
  const { toast, node } = useToast();

  return (
    <div className="flex flex-col gap-4">
      {node}
      <Card title="Filigran (Şikayet Medyaları)" icon={Droplets}>
        <div className="flex flex-col gap-3">
          <Toggle
            checked={wm.enabled}
            onChange={(v) => setWm({ ...wm, enabled: v })}
            label="Filigran aktif"
          />
          <Field label="Filigran Metni">
            <TextInput
              value={wm.text}
              onChange={(e) => setWm({ ...wm, text: e.target.value })}
              placeholder="Sohbet Sokağı"
            />
          </Field>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Yerleşim">
              <Select
                value={wm.position}
                onChange={(e) =>
                  setWm({ ...wm, position: e.target.value as WatermarkConfig["position"] })
                }
              >
                <option value="tile">Tüm yüzeye döşeli (önerilen)</option>
                <option value="center">Ortada tek</option>
                <option value="bottom-right">Sağ alt köşe</option>
                <option value="top-left">Sol üst köşe</option>
              </Select>
            </Field>
            <Field label="Renk">
              <input
                type="color"
                value={wm.color}
                onChange={(e) => setWm({ ...wm, color: e.target.value })}
                className="h-[42px] w-full cursor-pointer rounded-xl border border-[var(--line)] bg-[var(--bg)] p-1"
              />
            </Field>
          </div>
          <label className="flex items-center justify-between gap-3 rounded-xl border border-[var(--line)] bg-[var(--bg)] px-3.5 py-2.5">
            <span className="text-[12px] font-bold">Saydamlık</span>
            <span className="flex items-center gap-2">
              <input
                type="range"
                min={5}
                max={90}
                value={wm.opacity}
                onChange={(e) => setWm({ ...wm, opacity: Number(e.target.value) })}
                className="w-36 accent-[var(--accent)]"
              />
              <span className="w-10 text-right font-mono text-[11px] font-bold text-[var(--muted)]">
                %{wm.opacity}
              </span>
            </span>
          </label>
          <label className="flex items-center justify-between gap-3 rounded-xl border border-[var(--line)] bg-[var(--bg)] px-3.5 py-2.5">
            <span className="text-[12px] font-bold">Yazı boyutu</span>
            <span className="flex items-center gap-2">
              <input
                type="range"
                min={10}
                max={60}
                value={wm.size}
                onChange={(e) => setWm({ ...wm, size: Number(e.target.value) })}
                className="w-36 accent-[var(--accent)]"
              />
              <span className="w-10 text-right font-mono text-[11px] font-bold text-[var(--muted)]">
                {wm.size}px
              </span>
            </span>
          </label>
          <label className="flex items-center justify-between gap-3 rounded-xl border border-[var(--line)] bg-[var(--bg)] px-3.5 py-2.5">
            <span className="text-[12px] font-bold">Eğim açısı</span>
            <span className="flex items-center gap-2">
              <input
                type="range"
                min={-90}
                max={90}
                value={wm.rotate}
                onChange={(e) => setWm({ ...wm, rotate: Number(e.target.value) })}
                className="w-36 accent-[var(--accent)]"
              />
              <span className="w-10 text-right font-mono text-[11px] font-bold text-[var(--muted)]">
                {wm.rotate}°
              </span>
            </span>
          </label>

          <div>
            <span className="mb-1.5 block text-xs font-bold text-[var(--muted)]">
              Canlı Önizleme
            </span>
            <div className="relative aspect-[16/9] w-full overflow-hidden rounded-xl bg-gradient-to-br from-neutral-700 to-neutral-900">
              <div className="flex h-full items-center justify-center text-[11px] font-bold text-white/40">
                Şikayet fotoğrafı / videosu
              </div>
              <Watermark wm={wm} />
            </div>
          </div>

          <PrimaryBtn
            className="self-start"
            onClick={async () => {
              const ok = await save("watermark", JSON.stringify(wm));
              if (ok) toast("Filigran ayarları kaydedildi");
            }}
          >
            Filigranı Kaydet
          </PrimaryBtn>
        </div>
      </Card>

      <Card title="Karanlık Tema" icon={Moon}>
        <div className="flex flex-col gap-3">
          <Toggle
            checked={darkEnabled}
            onChange={(v) => {
              setDarkEnabled(v);
              save("dark_enabled", v ? "1" : "0");
            }}
            label="Kullanıcılar karanlık temayı seçebilsin (header'daki ay/güneş butonu)"
          />
          <div className="grid gap-2 sm:grid-cols-2">
            {(
              [
                ["bg", "Arka plan"],
                ["card", "Kart"],
                ["ink", "Metin"],
                ["muted", "Soluk metin"],
                ["line", "Kenarlık"],
                ["accent", "Vurgu rengi"],
                ["accentInk", "Vurgu metin"],
              ] as [keyof ThemeConfig, string][]
            ).map(([key, label]) => (
              <label
                key={key}
                className="flex items-center justify-between gap-3 rounded-xl border border-[var(--line)] bg-[var(--bg)] px-3 py-2"
              >
                <span className="text-[12px] font-bold">{label}</span>
                <span className="flex items-center gap-2">
                  <span className="font-mono text-[10px] font-bold text-[var(--muted)]">
                    {String(dark[key]).toUpperCase()}
                  </span>
                  <input
                    type="color"
                    value={String(dark[key])}
                    onChange={(e) => setDark({ ...dark, [key]: e.target.value })}
                    className="h-8 w-10 cursor-pointer rounded-lg border border-[var(--line)] bg-transparent p-0.5"
                  />
                </span>
              </label>
            ))}
          </div>
          <div
            className="rounded-2xl border p-4"
            style={{ background: dark.bg, borderColor: dark.line }}
          >
            <p className="text-[12px] font-extrabold" style={{ color: dark.ink }}>
              Karanlık tema önizlemesi
            </p>
            <div
              className="mt-2 rounded-xl p-3"
              style={{ background: dark.card, border: `1px solid ${dark.line}` }}
            >
              <p className="text-[11.5px] font-bold" style={{ color: dark.ink }}>
                Örnek kart
              </p>
              <p className="text-[10.5px] font-semibold" style={{ color: dark.muted }}>
                Soluk açıklama metni
              </p>
              <span
                className="mt-2 inline-block rounded-full px-3 py-1 text-[10px] font-extrabold"
                style={{ background: dark.accent, color: dark.accentInk }}
              >
                Buton
              </span>
            </div>
          </div>
          <div className="flex flex-wrap gap-2">
            <PrimaryBtn
              onClick={async () => {
                const ok = await save("dark_theme", JSON.stringify(dark));
                if (ok) toast("Karanlık tema kaydedildi");
              }}
            >
              Karanlık Temayı Kaydet
            </PrimaryBtn>
            <GhostBtn onClick={() => setDark(DEFAULT_DARK_THEME)}>
              <RotateCcw size={14} /> Varsayılana Dön
            </GhostBtn>
          </div>
        </div>
      </Card>

      <Card title="Modül Görünürlüğü" icon={BarChart3}>
        <Toggle
          checked={complaintsEnabled}
          onChange={(v) => {
            setComplaintsEnabled(v);
            save("complaints_enabled", v ? "1" : "0");
          }}
          label="Şikayetler sekmesi sitede görünsün"
        />
      </Card>
    </div>
  );
}
