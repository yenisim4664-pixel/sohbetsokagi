import { isAdminAuthed } from "@/lib/auth";
import { loadSiteData } from "@/lib/settings";
import { themeVars } from "@/lib/types";
import { redirect } from "next/navigation";
import type { CSSProperties } from "react";
import LoginForm from "./LoginForm";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Admin Girişi",
  robots: { index: false, follow: false },
};

export default async function AdminLoginPage() {
  if (await isAdminAuthed()) redirect("/admin");
  const site = await loadSiteData();
  return (
    <div
      style={themeVars(site.theme) as CSSProperties}
      className="flex min-h-dvh items-center justify-center bg-[var(--bg)] px-4 text-[var(--ink)]"
    >
      <LoginForm siteName={site.siteName} />
    </div>
  );
}
