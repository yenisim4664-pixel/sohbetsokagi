"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Lock, ShieldCheck } from "lucide-react";
import { PrimaryBtn, Spinner, TextInput } from "@/components/site/ui";

export default function LoginForm({ siteName }: { siteName: string }) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      const r = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password }),
      });
      if (r.ok) {
        router.replace("/admin");
        router.refresh();
      } else {
        const j = await r.json().catch(() => ({}));
        setError(j.error || "Giriş başarısız");
      }
    } catch {
      setError("Bağlantı hatası");
    }
    setBusy(false);
  }

  return (
    <form
      onSubmit={submit}
      className="animate-scale-in w-full max-w-sm rounded-3xl border border-[var(--line)] bg-[var(--card)] p-7 shadow-xl"
    >
      <div className="flex flex-col items-center text-center">
        <span className="ring-gradient flex h-14 w-14 items-center justify-center rounded-2xl text-white shadow-lg">
          <ShieldCheck size={26} />
        </span>
        <h1 className="mt-4 text-xl font-extrabold tracking-tight">
          {siteName} Admin
        </h1>
        <p className="mt-1 text-[12.5px] font-semibold text-[var(--muted)]">
          Yönetim paneline erişmek için şifrenizi girin
        </p>
      </div>
      <div className="mt-6 space-y-3">
        <div className="relative">
          <Lock
            size={15}
            className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--muted)]"
          />
          <TextInput
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Admin şifresi"
            className="pl-10"
            autoFocus
          />
        </div>
        {error && (
          <p className="rounded-xl bg-rose-500/10 px-3.5 py-2.5 text-[12px] font-bold text-rose-500">
            {error}
          </p>
        )}
        <PrimaryBtn type="submit" className="w-full" disabled={busy || !password}>
          {busy ? <Spinner size={16} /> : <ShieldCheck size={16} />}
          {busy ? "Kontrol ediliyor..." : "Panele Giriş Yap"}
        </PrimaryBtn>
        <p className="pt-1 text-center text-[10.5px] font-semibold leading-relaxed text-[var(--muted)]">
          Varsayılan şifre: <b>admin123</b> — ilk girişte Güvenlik sekmesinden
          değiştirmeyi unutmayın.
        </p>
      </div>
    </form>
  );
}
