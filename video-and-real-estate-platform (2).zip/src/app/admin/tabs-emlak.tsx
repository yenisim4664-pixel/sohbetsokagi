"use client";

import { useCallback, useEffect, useState } from "react";
import type { Listing } from "@/lib/types";
import {
  DISTRICTS,
  HEATING_OPTIONS,
  formatCount,
  formatPrice,
  timeAgo,
} from "@/lib/types";
import {
  Building2,
  Eye,
  Pencil,
  Pin,
  PinOff,
  Plus,
  Trash2,
} from "lucide-react";
import {
  Field,
  GhostBtn,
  Modal,
  PrimaryBtn,
  Select,
  TextArea,
  TextInput,
  Toggle,
  Uploader,
  useToast,
} from "@/components/site/ui";

const EMPTY_FORM = {
  title: "",
  type: "satilik",
  status: "aktif",
  price: "",
  rooms: "",
  area: "",
  floor: "",
  heating: "Doğalgaz Kombi",
  district: DISTRICTS[0],
  phone: "",
  description: "",
  images: [] as string[],
  pinned: false,
};

type FormState = typeof EMPTY_FORM;

const STATUS_LABEL: Record<string, string> = {
  aktif: "Yayında",
  satildi: "Satıldı",
  kiralandi: "Kiralandı",
};

const STATUS_CLS: Record<string, string> = {
  aktif: "bg-emerald-500/10 text-emerald-600",
  satildi: "bg-rose-500/10 text-rose-500",
  kiralandi: "bg-amber-500/10 text-amber-600",
};

export function EmlakTab() {
  const [items, setItems] = useState<Listing[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [busy, setBusy] = useState(false);
  const { toast, node } = useToast();

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/listings");
      const j = await r.json();
      if (r.ok) setItems(j.listings);
    } catch {
      // yoksay
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = items.filter((l) =>
    filter === "all"
      ? true
      : filter === "satilik" || filter === "kiralik"
        ? l.type === filter
        : l.status === filter
  );

  function openCreate() {
    setForm(EMPTY_FORM);
    setEditId(null);
    setModalOpen(true);
  }

  function openEdit(l: Listing) {
    setForm({
      title: l.title,
      type: l.type,
      status: l.status,
      price: String(l.price),
      rooms: l.rooms,
      area: String(l.area || ""),
      floor: l.floor,
      heating: l.heating || "Doğalgaz Kombi",
      district: l.district || DISTRICTS[0],
      phone: l.phone,
      description: l.description,
      images: l.images,
      pinned: l.pinned,
    });
    setEditId(l.id);
    setModalOpen(true);
  }

  async function submit() {
    if (!form.title.trim()) return toast("İlan başlığı gerekli");
    setBusy(true);
    const payload = {
      ...form,
      price: Number(String(form.price).replace(/[^\d]/g, "")) || 0,
      area: Number(form.area) || 0,
    };
    const r = await fetch(
      editId ? `/api/listings/${editId}` : "/api/listings",
      {
        method: editId ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      }
    );
    setBusy(false);
    if (r.ok) {
      setModalOpen(false);
      toast(editId ? "İlan güncellendi" : "İlan yayınlandı");
      load();
    } else toast("İşlem başarısız");
  }

  async function quickPatch(id: number, payload: Record<string, unknown>) {
    const r = await fetch(`/api/listings/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (r.ok) load();
    else toast("İşlem başarısız");
  }

  async function remove(l: Listing) {
    if (!confirm(`"${l.title}" ilanı silinsin mi?`)) return;
    const r = await fetch(`/api/listings/${l.id}`, { method: "DELETE" });
    if (r.ok) {
      toast("İlan silindi");
      load();
    }
  }

  return (
    <div className="flex flex-col gap-3">
      {node}
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap gap-1.5">
          {[
            ["all", "Tümü"],
            ["satilik", "Satılık"],
            ["kiralik", "Kiralık"],
            ["satildi", "Satıldı"],
            ["kiralandi", "Kiralandı"],
          ].map(([id, label]) => (
            <button
              key={id}
              onClick={() => setFilter(id)}
              className={`rounded-full px-3.5 py-1.5 text-[11px] font-extrabold transition active:scale-95 ${
                filter === id
                  ? "bg-[var(--ink)] text-[var(--bg)]"
                  : "border border-[var(--line)] bg-[var(--card)] text-[var(--muted)]"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
        <PrimaryBtn onClick={openCreate} className="!py-2">
          <Plus size={15} /> Yeni İlan
        </PrimaryBtn>
      </div>

      {loading ? (
        <p className="py-10 text-center text-sm font-semibold text-[var(--muted)]">
          Yükleniyor...
        </p>
      ) : filtered.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-[var(--line)] py-12 text-center text-sm font-semibold text-[var(--muted)]">
          Bu filtrede ilan yok.
        </p>
      ) : (
        <div className="flex flex-col gap-2">
          {filtered.map((l) => (
            <div
              key={l.id}
              className="flex items-center gap-3 rounded-2xl border border-[var(--line)] bg-[var(--card)] p-3"
            >
              <div className="h-14 w-20 shrink-0 overflow-hidden rounded-lg bg-neutral-200">
                {l.images[0] ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={l.images[0]}
                    alt=""
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <span className="flex h-full w-full items-center justify-center text-[var(--muted)]">
                    <Building2 size={18} />
                  </span>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="line-clamp-1 text-[13px] font-extrabold tracking-tight">
                  {l.pinned && (
                    <Pin
                      size={11}
                      className="mr-1 inline fill-[var(--accent)] text-[var(--accent)]"
                    />
                  )}
                  {l.title}
                </p>
                <p className="mt-0.5 flex flex-wrap items-center gap-2 text-[10.5px] font-bold text-[var(--muted)]">
                  <span className="text-[var(--accent)]">
                    {formatPrice(l.price, l.type)}
                  </span>
                  <span
                    className={`rounded-full px-2 py-0.5 ${STATUS_CLS[l.status]}`}
                  >
                    {STATUS_LABEL[l.status]}
                  </span>
                  <span className="flex items-center gap-1">
                    <Eye size={11} /> {formatCount(l.views)}
                  </span>
                  <span>{timeAgo(l.createdAt)}</span>
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-1">
                <select
                  value={l.status}
                  onChange={(e) => quickPatch(l.id, { status: e.target.value })}
                  className="rounded-lg border border-[var(--line)] bg-[var(--bg)] px-1.5 py-1.5 text-[10.5px] font-bold text-[var(--muted)] focus:outline-none"
                  title="Durum değiştir"
                >
                  <option value="aktif">Yayında</option>
                  <option value="satildi">Satıldı</option>
                  <option value="kiralandi">Kiralandı</option>
                </select>
                <button
                  onClick={() => quickPatch(l.id, { pinned: !l.pinned })}
                  className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--bg)] hover:text-[var(--accent)]"
                  title={l.pinned ? "Sabitlemeyi kaldır" : "Üste sabitle"}
                >
                  {l.pinned ? <PinOff size={16} /> : <Pin size={16} />}
                </button>
                <button
                  onClick={() => openEdit(l)}
                  className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--bg)] hover:text-[var(--ink)]"
                  title="Düzenle"
                >
                  <Pencil size={16} />
                </button>
                <button
                  onClick={() => remove(l)}
                  className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-rose-500/10 hover:text-rose-500"
                  title="Sil"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editId ? "İlanı Düzenle" : "Yeni Emlak İlanı"}
        wide
      >
        <div className="space-y-3.5">
          <Field label="İlan Başlığı *">
            <TextInput
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
            />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Tür">
              <Select
                value={form.type}
                onChange={(e) => setForm({ ...form, type: e.target.value })}
              >
                <option value="satilik">Satılık</option>
                <option value="kiralik">Kiralık</option>
              </Select>
            </Field>
            <Field label="Durum">
              <Select
                value={form.status}
                onChange={(e) => setForm({ ...form, status: e.target.value })}
              >
                <option value="aktif">Yayında</option>
                <option value="satildi">Satıldı</option>
                <option value="kiralandi">Kiralandı</option>
              </Select>
            </Field>
            <Field label="Fiyat (₺)">
              <TextInput
                value={form.price}
                inputMode="numeric"
                onChange={(e) => setForm({ ...form, price: e.target.value })}
              />
            </Field>
            <Field label="Oda Sayısı">
              <TextInput
                value={form.rooms}
                onChange={(e) => setForm({ ...form, rooms: e.target.value })}
                placeholder="3+1"
              />
            </Field>
            <Field label="Brüt m²">
              <TextInput
                value={form.area}
                inputMode="numeric"
                onChange={(e) => setForm({ ...form, area: e.target.value })}
              />
            </Field>
            <Field label="Kat">
              <TextInput
                value={form.floor}
                onChange={(e) => setForm({ ...form, floor: e.target.value })}
              />
            </Field>
            <Field label="Isıtma">
              <Select
                value={form.heating}
                onChange={(e) => setForm({ ...form, heating: e.target.value })}
              >
                {HEATING_OPTIONS.map((h) => (
                  <option key={h} value={h}>
                    {h}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Mahalle">
              <Select
                value={form.district}
                onChange={(e) => setForm({ ...form, district: e.target.value })}
              >
                {DISTRICTS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </Select>
            </Field>
          </div>
          <Field label="Telefon (opsiyonel)">
            <TextInput
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder="905551112233"
            />
          </Field>
          <Field label="Açıklama">
            <TextArea
              value={form.description}
              onChange={(e) =>
                setForm({ ...form, description: e.target.value })
              }
            />
          </Field>
          <Uploader
            accept="image/jpeg,image/png,image/webp"
            multiple
            onUploaded={(files) => {
              if (files.length)
                setForm((f) => ({
                  ...f,
                  images: [...f.images, ...files.map((x) => x.url)].slice(0, 10),
                }));
            }}
          >
            Fotoğraf yükle (çoklu)
          </Uploader>
          {form.images.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {form.images.map((img, i) => (
                <div key={i} className="relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={img}
                    alt=""
                    className="h-16 w-16 rounded-lg border border-[var(--line)] object-cover"
                  />
                  <button
                    onClick={() =>
                      setForm((f) => ({
                        ...f,
                        images: f.images.filter((_, x) => x !== i),
                      }))
                    }
                    className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}
          <Toggle
            checked={form.pinned}
            onChange={(v) => setForm({ ...form, pinned: v })}
            label="Üste sabitle"
          />
          <div className="flex gap-2">
            <GhostBtn className="flex-1" onClick={() => setModalOpen(false)}>
              Vazgeç
            </GhostBtn>
            <PrimaryBtn className="flex-1" onClick={submit} disabled={busy}>
              {busy ? "Kaydediliyor..." : editId ? "Güncelle" : "Yayınla"}
            </PrimaryBtn>
          </div>
        </div>
      </Modal>
    </div>
  );
}
