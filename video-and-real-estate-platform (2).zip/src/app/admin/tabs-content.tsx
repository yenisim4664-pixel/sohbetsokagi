"use client";

import { useCallback, useEffect, useState } from "react";
import type { BannerItem, StoryItem, VideoPost } from "@/lib/types";
import { formatCount, timeAgo } from "@/lib/types";
import {
  Camera,
  Clapperboard,
  Eye,
  Heart,
  Image as ImageIcon,
  Pencil,
  Pin,
  PinOff,
  Plus,
  Trash2,
} from "lucide-react";
import {
  Field,
  GhostBtn,
  Modal,
  PrimaryBtn,
  Select,
  TextArea,
  TextInput,
  Toggle,
  Uploader,
  useToast,
} from "@/components/site/ui";

const EMPTY_VIDEO = {
  title: "",
  description: "",
  videoUrl: "",
  posterUrl: "",
  pinned: false,
};

const POSITION_LABEL: Record<string, string> = {
  "feed-top": "Akış üstü",
  "feed-inline": "Akış içi",
  "emlak-top": "Emlak üstü",
};

/* ------------------------------ VİDEOLAR ------------------------------ */

export function VideosTab() {
  const [posts, setPosts] = useState<VideoPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const [form, setForm] = useState(EMPTY_VIDEO);
  const [busy, setBusy] = useState(false);
  const { toast, node } = useToast();

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/videos?limit=50");
      const j = await r.json();
      if (r.ok) setPosts(j.videos);
    } catch {
      // yoksay
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function openCreate() {
    setForm(EMPTY_VIDEO);
    setEditId(null);
    setModalOpen(true);
  }

  function openEdit(v: VideoPost) {
    setForm({
      title: v.title,
      description: v.description,
      videoUrl: v.videoUrl,
      posterUrl: v.posterUrl,
      pinned: v.pinned,
    });
    setEditId(v.id);
    setModalOpen(true);
  }

  async function submit() {
    if (!form.videoUrl.trim()) return toast("Video adresi gerekli");
    setBusy(true);
    const r = await fetch(editId ? `/api/videos/${editId}` : "/api/videos", {
      method: editId ? "PATCH" : "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setBusy(false);
    if (r.ok) {
      setModalOpen(false);
      toast(editId ? "Video güncellendi" : "Video yayınlandı");
      load();
    } else toast("İşlem başarısız");
  }

  async function togglePin(v: VideoPost) {
    await fetch(`/api/videos/${v.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pinned: !v.pinned }),
    });
    load();
  }

  async function remove(v: VideoPost) {
    if (!confirm(`"${v.title || "Bu video"}" silinsin mi?`)) return;
    const r = await fetch(`/api/videos/${v.id}`, { method: "DELETE" });
    if (r.ok) {
      toast("Video silindi");
      load();
    }
  }

  return (
    <div className="flex flex-col gap-3">
      {node}
      <div className="flex items-center justify-between">
        <p className="text-[13px] font-bold text-[var(--muted)]">
          {posts.length} video · sabitlenenler en üstte görünür
        </p>
        <PrimaryBtn onClick={openCreate} className="!py-2">
          <Plus size={15} /> Yeni Video
        </PrimaryBtn>
      </div>

      {loading ? (
        <p className="py-10 text-center text-sm font-semibold text-[var(--muted)]">
          Yükleniyor...
        </p>
      ) : posts.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-[var(--line)] py-12 text-center text-sm font-semibold text-[var(--muted)]">
          Henüz video yok — ilk videonuzu ekleyin.
        </p>
      ) : (
        <div className="flex flex-col gap-2">
          {posts.map((v) => (
            <div
              key={v.id}
              className="flex items-center gap-3 rounded-2xl border border-[var(--line)] bg-[var(--card)] p-3"
            >
              <div className="relative h-14 w-24 shrink-0 overflow-hidden rounded-lg bg-neutral-200">
                {v.posterUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={v.posterUrl}
                    alt=""
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <span className="flex h-full w-full items-center justify-center text-[var(--muted)]">
                    <Clapperboard size={18} />
                  </span>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="line-clamp-1 text-[13px] font-extrabold tracking-tight">
                  {v.pinned && (
                    <Pin size={11} className="mr-1 inline fill-[var(--accent)] text-[var(--accent)]" />
                  )}
                  {v.title || "(Başlıksız)"}
                </p>
                <p className="mt-0.5 flex items-center gap-3 text-[10.5px] font-bold text-[var(--muted)]">
                  <span className="flex items-center gap-1">
                    <Eye size={11} /> {formatCount(v.views)}
                  </span>
                  <span className="flex items-center gap-1">
                    <Heart size={11} /> {formatCount(v.likes)}
                  </span>
                  <span>{timeAgo(v.createdAt)}</span>
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-1">
                <button
                  onClick={() => togglePin(v)}
                  className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--bg)] hover:text-[var(--accent)]"
                  title={v.pinned ? "Sabitlemeyi kaldır" : "Üste sabitle"}
                >
                  {v.pinned ? <PinOff size={16} /> : <Pin size={16} />}
                </button>
                <button
                  onClick={() => openEdit(v)}
                  className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--bg)] hover:text-[var(--ink)]"
                  title="Düzenle"
                >
                  <Pencil size={16} />
                </button>
                <button
                  onClick={() => remove(v)}
                  className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-rose-500/10 hover:text-rose-500"
                  title="Sil"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={modalOpen}
        onClose={() => setModalOpen(false)}
        title={editId ? "Videoyu Düzenle" : "Yeni Video Ekle"}
      >
        <div className="space-y-3.5">
          <Uploader
            accept="video/mp4,video/webm,video/quicktime"
            onUploaded={(files) => {
              if (files[0]) {
                setForm((f) => ({
                  ...f,
                  videoUrl: files[0].url,
                  posterUrl: files[0].posterUrl || f.posterUrl,
                }));
                toast("Video yüklendi");
              }
            }}
          >
            Video dosyası yükle (sunucuda saklanır)
          </Uploader>
          <Field label="veya Video URL (mp4 / .m3u8 HLS / CDN)">
            <TextInput
              value={form.videoUrl}
              onChange={(e) => setForm({ ...form, videoUrl: e.target.value })}
              placeholder="https://cdn.../video.mp4 veya .m3u8"
            />
          </Field>
          <Field label="Başlık">
            <TextInput
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
            />
          </Field>
          <Field label="Açıklama">
            <TextArea
              value={form.description}
              onChange={(e) =>
                setForm({ ...form, description: e.target.value })
              }
            />
          </Field>
          <Field label="Kapak görseli URL">
            <TextInput
              value={form.posterUrl}
              onChange={(e) => setForm({ ...form, posterUrl: e.target.value })}
            />
          </Field>
          <Toggle
            checked={form.pinned}
            onChange={(v) => setForm({ ...form, pinned: v })}
            label="Üste sabitle"
          />
          <div className="flex gap-2">
            <GhostBtn className="flex-1" onClick={() => setModalOpen(false)}>
              Vazgeç
            </GhostBtn>
            <PrimaryBtn className="flex-1" onClick={submit} disabled={busy}>
              {busy ? "Kaydediliyor..." : editId ? "Güncelle" : "Yayınla"}
            </PrimaryBtn>
          </div>
        </div>
      </Modal>
    </div>
  );
}

/* ------------------------------ HİKAYELER ------------------------------ */

export function StoriesTab() {
  const [items, setItems] = useState<StoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [url, setUrl] = useState("");
  const [mtype, setMtype] = useState<"image" | "video">("image");
  const [busy, setBusy] = useState(false);
  const { toast, node } = useToast();

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/stories");
      const j = await r.json();
      if (r.ok) setItems(j.stories);
    } catch {
      // yoksay
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  async function add() {
    if (!url.trim()) return toast("Medya adresi gerekli");
    setBusy(true);
    const r = await fetch("/api/stories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mediaUrl: url, mediaType: mtype, hours: 24 }),
    });
    setBusy(false);
    if (r.ok) {
      setUrl("");
      toast("Hikaye eklendi — 24 saat yayında kalacak");
      load();
    } else toast("Eklenemedi");
  }

  async function remove(id: number) {
    const r = await fetch(`/api/stories?id=${id}`, { method: "DELETE" });
    if (r.ok) {
      toast("Hikaye silindi");
      load();
    }
  }

  return (
    <div className="flex flex-col gap-4">
      {node}
      <div className="rounded-2xl border border-[var(--line)] bg-[var(--card)] p-4">
        <p className="mb-3 flex items-center gap-2 text-[13px] font-extrabold">
          <Camera size={15} className="text-[var(--accent)]" /> Yeni Hikaye
          <span className="text-[10.5px] font-bold text-[var(--muted)]">
            (24 saat sonra otomatik silinir)
          </span>
        </p>
        <div className="flex flex-col gap-2.5 sm:flex-row">
          <Uploader
            accept="image/jpeg,image/png,image/webp,video/mp4,video/webm"
            className="inline-flex flex-1 items-center justify-center gap-2 rounded-xl border-2 border-dashed border-[var(--line)] px-4 py-3 text-[12.5px] font-bold text-[var(--muted)] transition hover:border-[var(--accent)] hover:text-[var(--accent)]"
            onUploaded={(files) => {
              if (files[0]) {
                setUrl(files[0].url);
                setMtype(files[0].mediaType === "video" ? "video" : "image");
                toast("Medya yüklendi");
              }
            }}
          >
            Medya yükle
          </Uploader>
          <TextInput
            value={url}
            onChange={(e) => {
              setUrl(e.target.value);
              if (/\.(mp4|webm|mov)(\?|$)/i.test(e.target.value))
                setMtype("video");
              else setMtype("image");
            }}
            placeholder="veya medya URL'si yapıştır"
            className="flex-[2]"
          />
          <PrimaryBtn onClick={add} disabled={busy}>
            {busy ? "Ekleniyor..." : "Hikaye Ekle"}
          </PrimaryBtn>
        </div>
      </div>

      {loading ? (
        <p className="py-8 text-center text-sm font-semibold text-[var(--muted)]">
          Yükleniyor...
        </p>
      ) : items.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-[var(--line)] py-12 text-center text-sm font-semibold text-[var(--muted)]">
          Aktif hikaye yok.
        </p>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {items.map((s) => {
            const left = Math.max(
              0,
              Math.round(
                (+new Date(s.expiresAt) - Date.now()) / (1000 * 60 * 60)
              )
            );
            return (
              <div
                key={s.id}
                className="group relative aspect-[9/16] overflow-hidden rounded-2xl border border-[var(--line)] bg-neutral-200"
              >
                {s.mediaType === "video" ? (
                  <video
                    src={s.mediaUrl}
                    className="h-full w-full object-cover"
                    muted
                    playsInline
                    preload="metadata"
                  />
                ) : (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={s.mediaUrl}
                    alt=""
                    className="h-full w-full object-cover"
                  />
                )}
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/70 to-transparent p-2.5 pt-8">
                  <p className="text-[10.5px] font-extrabold text-white">
                    {left} sa kaldı
                  </p>
                </div>
                <button
                  onClick={() => remove(s.id)}
                  className="absolute right-2 top-2 rounded-full bg-black/55 p-1.5 text-white opacity-0 backdrop-blur transition group-hover:opacity-100 hover:bg-rose-500"
                  aria-label="Sil"
                >
                  <Trash2 size={13} />
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ------------------------------ BANNERLAR ------------------------------ */

const EMPTY_BANNER: BannerItem = {
  id: "",
  imageUrl: "",
  title: "",
  linkUrl: "",
  active: true,
  position: "feed-top",
};

export function BannersTab({
  banners,
  onSave,
}: {
  banners: BannerItem[];
  onSave: (b: BannerItem[]) => Promise<boolean>;
}) {
  const [list, setList] = useState<BannerItem[]>(banners);
  const [form, setForm] = useState<BannerItem | null>(null);
  const { toast, node } = useToast();

  useEffect(() => setList(banners), [banners]);

  async function persist(next: BannerItem[]): Promise<boolean> {
    setList(next);
    return onSave(next);
  }

  async function saveForm() {
    if (!form) return;
    if (!form.imageUrl.trim()) return toast("Banner görseli gerekli");
    const exists = list.some((b) => b.id === form.id);
    const next = exists
      ? list.map((b) => (b.id === form.id ? form : b))
      : [...list, form];
    const ok = await persist(next);
    if (ok) setForm(null);
  }

  return (
    <div className="flex flex-col gap-3">
      {node}
      <div className="flex items-center justify-between">
        <p className="text-[13px] font-bold text-[var(--muted)]">
          {list.length} banner · konumlarına göre sitede gösterilir
        </p>
        <PrimaryBtn
          onClick={() =>
            setForm({
              ...EMPTY_BANNER,
              id: "bnr-" + Math.random().toString(36).slice(2, 9),
            })
          }
          className="!py-2"
        >
          <Plus size={15} /> Yeni Banner
        </PrimaryBtn>
      </div>

      {list.length === 0 ? (
        <p className="rounded-2xl border border-dashed border-[var(--line)] py-12 text-center text-sm font-semibold text-[var(--muted)]">
          Banner yok — reklam ve duyuru alanları için ekleyin.
        </p>
      ) : (
        <div className="flex flex-col gap-2.5">
          {list.map((b) => (
            <div
              key={b.id}
              className="flex items-center gap-3 rounded-2xl border border-[var(--line)] bg-[var(--card)] p-3"
            >
              <div className="h-14 w-24 shrink-0 overflow-hidden rounded-lg bg-neutral-200">
                {b.imageUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={b.imageUrl}
                    alt=""
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <span className="flex h-full w-full items-center justify-center text-[var(--muted)]">
                    <ImageIcon size={18} />
                  </span>
                )}
              </div>
              <div className="min-w-0 flex-1">
                <p className="line-clamp-1 text-[13px] font-extrabold tracking-tight">
                  {b.title || "(Başlıksız banner)"}
                </p>
                <p className="mt-0.5 text-[10.5px] font-bold text-[var(--muted)]">
                  {POSITION_LABEL[b.position] || b.position} ·{" "}
                  {b.active ? "Aktif" : "Pasif"} · {b.linkUrl || "linksiz"}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-1">
                <button
                  onClick={() =>
                    persist(
                      list.map((x) =>
                        x.id === b.id ? { ...x, active: !x.active } : x
                      )
                    )
                  }
                  className={`rounded-full px-3 py-1.5 text-[10.5px] font-extrabold transition active:scale-95 ${
                    b.active
                      ? "bg-emerald-500/10 text-emerald-600"
                      : "bg-[var(--bg)] text-[var(--muted)]"
                  }`}
                >
                  {b.active ? "AKTİF" : "PASİF"}
                </button>
                <button
                  onClick={() => setForm({ ...b })}
                  className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--bg)] hover:text-[var(--ink)]"
                >
                  <Pencil size={16} />
                </button>
                <button
                  onClick={() => {
                    if (confirm("Banner silinsin mi?"))
                      persist(list.filter((x) => x.id !== b.id));
                  }}
                  className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-rose-500/10 hover:text-rose-500"
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal
        open={!!form}
        onClose={() => setForm(null)}
        title={form && list.some((b) => b.id === form.id) ? "Bannerı Düzenle" : "Yeni Banner"}
      >
        {form && (
          <div className="space-y-3.5">
            <Uploader
              accept="image/jpeg,image/png,image/webp"
              onUploaded={(files) => {
                if (files[0]) {
                  setForm({ ...form, imageUrl: files[0].url });
                  toast("Görsel yüklendi");
                }
              }}
            >
              Banner görseli yükle
            </Uploader>
            <Field label="veya Görsel URL">
              <TextInput
                value={form.imageUrl}
                onChange={(e) =>
                  setForm({ ...form, imageUrl: e.target.value })
                }
                placeholder="https://.../banner.jpg"
              />
            </Field>
            <Field label="Başlık">
              <TextInput
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="Banner üzerinde görünen metin"
              />
            </Field>
            <Field label="Bağlantı (tıklanınca gidilecek adres)">
              <TextInput
                value={form.linkUrl}
                onChange={(e) => setForm({ ...form, linkUrl: e.target.value })}
                placeholder="/emlak veya https://..."
              />
            </Field>
            <Field label="Konum">
              <Select
                value={form.position}
                onChange={(e) =>
                  setForm({
                    ...form,
                    position: e.target.value as BannerItem["position"],
                  })
                }
              >
                <option value="feed-top">Akış üstü (hikayelerin altı)</option>
                <option value="feed-inline">Akış içi (gönderiler arası)</option>
                <option value="emlak-top">Emlak sayfası üstü</option>
              </Select>
            </Field>
            <Toggle
              checked={form.active}
              onChange={(v) => setForm({ ...form, active: v })}
              label="Banner aktif"
            />
            <div className="flex gap-2">
              <GhostBtn className="flex-1" onClick={() => setForm(null)}>
                Vazgeç
              </GhostBtn>
              <PrimaryBtn className="flex-1" onClick={saveForm}>
                Kaydet
              </PrimaryBtn>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
