import { isAdminAuthed } from "@/lib/auth";
import { loadSiteData } from "@/lib/settings";
import { themeVars } from "@/lib/types";
import { redirect } from "next/navigation";
import type { CSSProperties } from "react";
import AdminApp from "./AdminApp";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Yönetim Paneli",
  robots: { index: false, follow: false },
};

export default async function AdminPage() {
  if (!(await isAdminAuthed())) redirect("/admin/login");
  const site = await loadSiteData();
  return (
    <div
      style={themeVars(site.theme) as CSSProperties}
      className="min-h-dvh bg-[var(--bg)] text-[var(--ink)]"
    >
      <AdminApp site={site} />
    </div>
  );
}
