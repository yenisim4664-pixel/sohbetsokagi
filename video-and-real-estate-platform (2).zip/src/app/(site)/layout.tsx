import type { Metadata } from "next";
import type { CSSProperties } from "react";
import Link from "next/link";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureSeed } from "@/lib/seed";
import { loadSiteData } from "@/lib/settings";
import { getClientIp, isIpBanned } from "@/lib/ip";
import { canManageSite } from "@/lib/auth";
import { themeVars, cssVarBlock, DEFAULT_THEME, waLink } from "@/lib/types";
import Header from "@/components/site/Header";
import BottomNav from "@/components/site/BottomNav";
import Tracker from "@/components/site/Tracker";
import OwnerPost from "@/components/site/OwnerPost";
import { Eye, MapPin, ShieldX } from "lucide-react";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const site = await loadSiteData();
  return {
    title: {
      default: site.seo.title,
      template: `%s | ${site.siteName}`,
    },
    description: site.seo.description,
    keywords: site.seo.keywords
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean),
    openGraph: {
      type: "website",
      locale: "tr_TR",
      siteName: site.siteName,
      title: site.seo.title,
      description: site.seo.description,
      images: [site.seo.ogImage || "/icons/icon-512.png"],
    },
  };
}

export default async function SiteLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  await ensureSeed();
  const site = await loadSiteData();
  const ip = await getClientIp();
  const banned = await isIpBanned(ip);

  if (banned) {
    return (
      <div
        style={themeVars(DEFAULT_THEME) as CSSProperties}
        className="flex min-h-dvh flex-col items-center justify-center bg-[var(--bg)] px-6 text-center text-[var(--ink)]"
      >
        <span className="rounded-full bg-rose-500/10 p-5 text-rose-500">
          <ShieldX size={40} />
        </span>
        <h1 className="mt-4 text-xl font-extrabold tracking-tight">
          Erişiminiz Kısıtlandı
        </h1>
        <p className="mt-2 max-w-sm text-sm font-medium text-[var(--muted)]">
          Bu siteye erişiminiz yönetici tarafından engellenmiştir. Bir hata
          olduğunu düşünüyorsanız bizimle iletişime geçebilirsiniz.
        </p>
        <a
          href={waLink(site.owner.whatsapp, "Merhaba, site erişimim hakkında bilgi almak istiyorum.")}
          className="mt-5 rounded-full bg-[var(--accent)] px-5 py-2.5 text-sm font-bold text-[var(--accent-ink)]"
        >
          İletişime Geç
        </a>
      </div>
    );
  }

  const canManage = await canManageSite();
  let visitsToday = 0;
  let uniqueToday = 0;
  try {
    const r = await db.execute(
      sql`SELECT COUNT(*)::int AS c, COUNT(DISTINCT ip)::int AS u FROM visits WHERE created_at >= date_trunc('day', NOW())`
    );
    const row = (r.rows?.[0] || {}) as { c?: number; u?: number };
    visitsToday = row.c ?? 0;
    uniqueToday = row.u ?? 0;
  } catch {
    // yoksay
  }

  const orgJsonLd = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: site.siteName,
    description: site.seo.description,
    logo: site.seo.ogImage || "/icons/icon-512.png",
    sameAs: [site.owner.instagram].filter(Boolean),
    address: {
      "@type": "PostalAddress",
      addressLocality: "Elbistan",
      addressRegion: "Kahramanmaraş",
      addressCountry: "TR",
    },
  };

  const modeScript = site.darkEnabled
    ? `(function(){try{var m=localStorage.getItem('ss_mode');if(m==='dark'){document.documentElement.setAttribute('data-ss-mode','dark');}}catch(e){}})();`
    : "";

  return (
    <div className="min-h-dvh bg-[var(--bg)] text-[var(--ink)]">
      <style
        dangerouslySetInnerHTML={{
          __html: cssVarBlock(site.theme, site.darkTheme),
        }}
      />
      {site.darkEnabled && (
        <script dangerouslySetInnerHTML={{ __html: modeScript }} />
      )}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(orgJsonLd) }}
      />
      <Tracker />
      <Header
        siteName={site.siteName}
        tagline={site.tagline}
        logoUrl={site.logoUrl}
        darkEnabled={site.darkEnabled}
      />
      <main className="pb-32">{children}</main>
      <footer className="border-t border-[var(--line)] pb-28 pt-8">
        <div className="mx-auto flex max-w-[520px] flex-col items-center gap-2 px-4 text-center">
          <p className="text-[14px] font-extrabold tracking-tight">
            {site.siteName}
          </p>
          <p className="flex items-center gap-1 text-[11.5px] font-bold text-[var(--muted)]">
            <MapPin size={12} /> Elbistan / Kahramanmaraş
          </p>
          <nav className="mt-1 flex gap-4 text-[12px] font-bold text-[var(--muted)]">
            <Link href="/" className="hover:text-[var(--accent)]">
              Akış
            </Link>
            <Link href="/emlak" className="hover:text-[var(--accent)]">
              Emlak
            </Link>
            <Link href="/profil" className="hover:text-[var(--accent)]">
              Profil
            </Link>
            {site.complaintsEnabled && (
              <Link href="/sikayetler" className="hover:text-[var(--accent)]">
                Şikayet
              </Link>
            )}
          </nav>
          <p className="mt-2 flex items-center gap-1.5 rounded-full border border-[var(--line)] bg-[var(--card)] px-3.5 py-1.5 text-[10.5px] font-extrabold text-[var(--muted)]">
            <Eye size={12} className="text-[var(--accent)]" />
            Bugün {uniqueToday.toLocaleString("tr-TR")} tekil ziyaretçi ·{" "}
            {visitsToday.toLocaleString("tr-TR")} gezinme
          </p>
          <p className="mt-2 text-[10.5px] font-semibold text-[var(--muted)]">
            {site.footerText}
          </p>
        </div>
      </footer>
      <BottomNav complaintsEnabled={site.complaintsEnabled} />
      {canManage && <OwnerPost />}
    </div>
  );
}
