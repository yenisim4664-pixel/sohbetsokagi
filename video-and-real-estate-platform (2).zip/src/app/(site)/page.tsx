import { and, asc, desc, eq, gt, lt } from "drizzle-orm";
import { db } from "@/db";
import { polls, stories, videos } from "@/db/schema";
import { loadSiteData } from "@/lib/settings";
import { canManageSite } from "@/lib/auth";
import { pollToJson, storyToItem, videoToPost } from "@/lib/serialize";
import StoriesBar from "@/components/site/StoriesBar";
import VideoFeed, { BannerCard } from "@/components/site/VideoFeed";
import PollCard from "@/components/site/PollCard";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const site = await loadSiteData();
  const canManage = await canManageSite();

  // Süresi dolan hikayeleri temizle (24 saat kuralı)
  try {
    await db.delete(stories).where(lt(stories.expiresAt, new Date()));
  } catch {
    // yoksay
  }

  const storyRows = await db
    .select()
    .from(stories)
    .where(gt(stories.expiresAt, new Date()))
    .orderBy(asc(stories.createdAt));
  const videoRows = await db
    .select()
    .from(videos)
    .orderBy(desc(videos.pinned), desc(videos.createdAt))
    .limit(4);

  const pollRows = await db
    .select()
    .from(polls)
    .where(eq(polls.active, true))
    .orderBy(desc(polls.pinned), desc(polls.createdAt))
    .limit(20);
  const allPolls = pollRows.map(pollToJson);
  const topPolls = allPolls.filter((p) => p.position === "feed-top");
  const inlinePolls = allPolls.filter((p) => p.position === "feed-inline");

  const vids = videoRows.map(videoToPost);
  const activeBanners = site.banners.filter((b) => b.active);
  const topBanners = activeBanners.filter((b) => b.position === "feed-top");
  const inlineBanners = activeBanners.filter(
    (b) => b.position === "feed-inline"
  );

  const videosJsonLd = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    itemListElement: vids.map((v, i) => ({
      "@type": "ListItem",
      position: i + 1,
      item: {
        "@type": "VideoObject",
        name: v.title || "Sohbet Sokağı videosu",
        description: v.description || v.title,
        thumbnailUrl: v.posterUrl || undefined,
        uploadDate: v.createdAt,
        contentUrl: v.videoUrl,
        interactionStatistic: [
          {
            "@type": "InteractionCounter",
            interactionType: { "@type": "WatchAction" },
            userInteractionCount: v.views,
          },
          {
            "@type": "InteractionCounter",
            interactionType: { "@type": "LikeAction" },
            userInteractionCount: v.likes,
          },
        ],
        author: {
          "@type": "Person",
          name: site.owner.name,
        },
      },
    })),
  };

  return (
    <div className="mx-auto w-full max-w-[480px]">
      <h1 className="sr-only">{site.seo.title}</h1>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(videosJsonLd) }}
      />
      <StoriesBar
        stories={storyRows.map(storyToItem)}
        owner={site.owner}
        canManage={canManage}
      />
      {(topBanners.length > 0 || topPolls.length > 0) && (
        <div className="flex flex-col gap-4 px-4 pt-4">
          {topBanners.map((b) => (
            <BannerCard key={b.id} banner={b} />
          ))}
          {topPolls.map((p) => (
            <PollCard key={p.id} poll={p} />
          ))}
        </div>
      )}
      <div className="px-4 pt-5">
        <VideoFeed
          initial={vids}
          owner={site.owner}
          canManage={canManage}
          inlineBanners={inlineBanners}
          inlinePolls={inlinePolls}
        />
      </div>
    </div>
  );
}
