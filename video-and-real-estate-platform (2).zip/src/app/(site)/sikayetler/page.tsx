import type { Metadata } from "next";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { complaints, polls } from "@/db/schema";
import { loadSiteData } from "@/lib/settings";
import { canManageSite } from "@/lib/auth";
import { complaintToJson, pollToJson } from "@/lib/serialize";
import ComplaintsClient from "@/components/site/ComplaintsClient";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Şikayetler — Elbistan Vatandaş Bildirimleri",
  description:
    "Elbistan'da mahallendeki sorunu fotoğraf veya video ile bildir. Sohbet Sokağı Şikayet hattı: gönderiler yönetici onayından sonra yayınlanır.",
};

export default async function SikayetlerPage() {
  const site = await loadSiteData();
  const canManage = await canManageSite();

  const rows = await db
    .select()
    .from(complaints)
    .where(eq(complaints.status, "onaylandi"))
    .orderBy(desc(complaints.pinned), desc(complaints.createdAt))
    .limit(100);

  const pollRows = await db
    .select()
    .from(polls)
    .where(eq(polls.active, true))
    .orderBy(desc(polls.pinned), desc(polls.createdAt))
    .limit(20);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "WebPage",
    name: "Şikayetler — " + site.siteName,
    description:
      "Elbistan vatandaş şikayet ve bildirim akışı. Gönderiler yönetici onayıyla yayınlanır.",
  };

  return (
    <div className="mx-auto w-full max-w-[520px]">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <ComplaintsClient
        initial={rows.map(complaintToJson)}
        watermark={site.watermark}
        canManage={canManage}
        intro={site.complaintIntro}
        polls={pollRows.map(pollToJson)}
      />
    </div>
  );
}
