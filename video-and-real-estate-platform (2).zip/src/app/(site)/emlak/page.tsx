import type { Metadata } from "next";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { listings, polls } from "@/db/schema";
import { loadSiteData } from "@/lib/settings";
import { canManageSite } from "@/lib/auth";
import { listingToListing, pollToJson } from "@/lib/serialize";
import EmlakClient from "@/components/site/EmlakClient";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Emlak İlanları — Elbistan Satılık & Kiralık",
  description:
    "Sohbet Sokağı Emlak: Elbistan'da satılık daire, kiralık ev, dükkan ve müstakil ev ilanları. Güncel fiyatlar, mahalle bazlı arama, WhatsApp ile anında iletişim.",
  openGraph: {
    title: "Sohbet Sokağı Emlak — Elbistan İlanları",
    description:
      "Elbistan'da satılık & kiralık güncel emlak ilanları.",
  },
};

export default async function EmlakPage() {
  const site = await loadSiteData();
  const canManage = await canManageSite();
  const rows = await db
    .select()
    .from(listings)
    .orderBy(desc(listings.pinned), desc(listings.createdAt))
    .limit(200);
  const list = rows.map(listingToListing);
  const banners = site.banners.filter(
    (b) => b.active && b.position === "emlak-top"
  );
  const pollRows = await db
    .select()
    .from(polls)
    .where(eq(polls.active, true))
    .orderBy(desc(polls.pinned), desc(polls.createdAt))
    .limit(10);
  const emlakPolls = pollRows
    .map(pollToJson)
    .filter((p) => p.position === "emlak-top");

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "RealEstateAgent",
    name: `${site.siteName} Emlak`,
    description:
      "Elbistan merkezli emlak danışmanlığı — satılık ve kiralık ilanlar.",
    areaServed: "Elbistan, Kahramanmaraş",
    telephone: `+${site.owner.whatsapp}`,
    address: {
      "@type": "PostalAddress",
      addressLocality: "Elbistan",
      addressRegion: "Kahramanmaraş",
      addressCountry: "TR",
    },
  };

  const listJsonLd = {
    "@context": "https://schema.org",
    "@type": "ItemList",
    itemListElement: list.slice(0, 20).map((l, i) => ({
      "@type": "ListItem",
      position: i + 1,
      item: {
        "@type": "RealEstateListing",
        name: l.title,
        description: l.description,
        image: l.images[0],
        datePosted: l.createdAt,
        url: `/emlak#ilan-${l.id}`,
      },
    })),
  };

  return (
    <div className="mx-auto w-full max-w-[700px]">
      <h1 className="sr-only">
        Elbistan Emlak İlanları — Satılık ve Kiralık | {site.siteName} Emlak
      </h1>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(listJsonLd) }}
      />
      <EmlakClient
        listings={list}
        owner={site.owner}
        banners={banners}
        canManage={canManage}
        polls={emlakPolls}
      />
    </div>
  );
}
