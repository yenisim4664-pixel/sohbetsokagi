import type { Metadata } from "next";
import { desc, sql } from "drizzle-orm";
import { db } from "@/db";
import { videos } from "@/db/schema";
import { loadSiteData } from "@/lib/settings";
import { canManageSite } from "@/lib/auth";
import { videoToPost } from "@/lib/serialize";
import ProfileClient from "@/components/site/ProfileClient";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const site = await loadSiteData();
  return {
    title: `${site.owner.name} (@${site.owner.username})`,
    description: site.owner.bio.slice(0, 160),
    openGraph: {
      title: `${site.owner.name} (@${site.owner.username})`,
      description: site.owner.bio.slice(0, 160),
      images: [site.owner.avatar],
    },
  };
}

export default async function ProfilePage() {
  const site = await loadSiteData();
  const canManage = await canManageSite();
  const rows = await db
    .select()
    .from(videos)
    .orderBy(desc(videos.pinned), desc(videos.createdAt))
    .limit(60);
  const agg = await db.execute(
    sql`SELECT COUNT(*)::int AS c, COALESCE(SUM(views),0)::int AS sv, COALESCE(SUM(likes),0)::int AS sl FROM videos`
  );
  const a = (agg.rows?.[0] || {}) as {
    c?: number;
    sv?: number;
    sl?: number;
  };

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "ProfilePage",
    mainEntity: {
      "@type": "Person",
      name: site.owner.name,
      alternateName: site.owner.username,
      image: site.owner.avatar,
      description: site.owner.bio,
      sameAs: [site.owner.instagram].filter(Boolean),
      address: {
        "@type": "PostalAddress",
        addressLocality: "Elbistan",
        addressCountry: "TR",
      },
    },
  };

  return (
    <div className="mx-auto w-full max-w-[520px]">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <ProfileClient
        owner={site.owner}
        posts={rows.map(videoToPost)}
        totalViews={a.sv ?? 0}
        totalLikes={a.sl ?? 0}
        canManage={canManage}
      />
    </div>
  );
}
