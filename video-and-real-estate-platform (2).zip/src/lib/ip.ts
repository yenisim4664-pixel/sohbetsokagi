import { headers } from "next/headers";
import { db } from "@/db";
import { bannedIps, visits } from "@/db/schema";
import { eq, lt } from "drizzle-orm";

export async function getClientIp(): Promise<string> {
  const h = await headers();
  const xf = h.get("x-forwarded-for");
  let ip = xf ? xf.split(",")[0].trim() : h.get("x-real-ip") || "127.0.0.1";
  if (ip.startsWith("::ffff:")) ip = ip.slice(7);
  return ip || "127.0.0.1";
}

export async function isIpBanned(ip: string): Promise<boolean> {
  try {
    const rows = await db
      .select({ id: bannedIps.id })
      .from(bannedIps)
      .where(eq(bannedIps.ip, ip))
      .limit(1);
    return rows.length > 0;
  } catch {
    return false;
  }
}

export async function recordVisit(
  ip: string,
  path: string,
  ua: string
): Promise<void> {
  try {
    await db.insert(visits).values({ ip, path: path.slice(0, 200), ua: ua.slice(0, 300) });
    // Zaman zaman eski kayıtları temizle (7 gün)
    if (Math.random() < 0.05) {
      const cutoff = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      await db.delete(visits).where(lt(visits.createdAt, cutoff));
    }
  } catch {
    // Sessiz geç
  }
}
