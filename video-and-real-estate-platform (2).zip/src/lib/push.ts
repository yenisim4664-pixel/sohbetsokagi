import webpush from "web-push";
import { db } from "@/db";
import { pushSubs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { getSetting, setSetting } from "./settings";

type VapidKeys = { publicKey: string; privateKey: string };

export async function ensureVapidKeys(): Promise<VapidKeys> {
  let keys: VapidKeys | null = null;
  try {
    keys = JSON.parse((await getSetting("vapid")) || "null");
  } catch {
    keys = null;
  }
  if (!keys?.publicKey || !keys?.privateKey) {
    keys = webpush.generateVAPIDKeys();
    await setSetting("vapid", JSON.stringify(keys));
  }
  return keys;
}

export type PushPayload = {
  title: string;
  body: string;
  url?: string;
  icon?: string;
};

export async function sendPushToAll(payload: PushPayload): Promise<{
  sent: number;
  removed: number;
  total: number;
}> {
  const keys = await ensureVapidKeys();
  webpush.setVapidDetails(
    "mailto:info@sohbetsokagi.com",
    keys.publicKey,
    keys.privateKey
  );
  const subs = await db.select().from(pushSubs);
  let sent = 0;
  let removed = 0;
  await Promise.all(
    subs.map(async (s) => {
      try {
        const data = JSON.parse(s.data) as {
          keys?: { p256dh: string; auth: string };
        };
        await webpush.sendNotification(
          { endpoint: s.endpoint, keys: data.keys as { p256dh: string; auth: string } },
          JSON.stringify({
            title: payload.title,
            body: payload.body,
            url: payload.url || "/",
            icon: payload.icon || "/icons/icon-512.png",
          })
        );
        sent++;
      } catch (e) {
        const code = (e as { statusCode?: number })?.statusCode;
        if (code === 404 || code === 410) {
          await db.delete(pushSubs).where(eq(pushSubs.id, s.id));
          removed++;
        }
      }
    })
  );
  return { sent, removed, total: subs.length };
}

export async function pushSubCount(): Promise<number> {
  const rows = await db.select().from(pushSubs);
  return rows.length;
}
