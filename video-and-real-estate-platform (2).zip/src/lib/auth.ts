import crypto from "crypto";
import { cookies } from "next/headers";
import { getSetting, setSetting } from "./settings";
import { getClientIp } from "./ip";

const COOKIE_NAME = "ss_admin";
const SECRET =
  process.env.ADMIN_SECRET || "sohbet-sokagi-varsayilan-gizli-anahtar-2026";
const SESSION_DAYS = 7;

export function hashPassword(pw: string): string {
  return crypto.createHash("sha256").update("ss::" + pw).digest("hex");
}

export async function verifyAdminPassword(pw: string): Promise<boolean> {
  let stored = await getSetting("admin_password_hash");
  if (!stored) {
    stored = hashPassword("admin123");
    await setSetting("admin_password_hash", stored);
  }
  const a = Buffer.from(stored);
  const b = Buffer.from(hashPassword(pw));
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function sign(value: string): string {
  return crypto.createHmac("sha256", SECRET).update(value).digest("hex");
}

export async function createAdminSession(): Promise<void> {
  const exp = Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000;
  const token = `${exp}.${sign(String(exp))}`;
  const store = await cookies();
  store.set(COOKIE_NAME, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: SESSION_DAYS * 24 * 60 * 60,
    path: "/",
  });
}

export async function destroyAdminSession(): Promise<void> {
  const store = await cookies();
  store.delete(COOKIE_NAME);
}

export async function isAdminAuthed(): Promise<boolean> {
  try {
    const store = await cookies();
    const token = store.get(COOKIE_NAME)?.value;
    if (!token) return false;
    const [expStr, sig] = token.split(".");
    const exp = Number(expStr);
    if (!exp || exp < Date.now()) return false;
    const a = Buffer.from(sig || "");
    const b = Buffer.from(sign(expStr));
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch {
    return false;
  }
}

export async function getOwnerIps(): Promise<string[]> {
  const raw = (await getSetting("owner_ips")) || "";
  return raw
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

export async function isOwnerIp(): Promise<boolean> {
  const ip = await getClientIp();
  const list = await getOwnerIps();
  return list.length > 0 && list.includes(ip);
}

/** Admin paneli oturumu VEYA kayıtlı sahip IP'si — site içi hızlı paylaşım için. */
export async function canManageSite(): Promise<boolean> {
  if (await isAdminAuthed()) return true;
  return isOwnerIp();
}
