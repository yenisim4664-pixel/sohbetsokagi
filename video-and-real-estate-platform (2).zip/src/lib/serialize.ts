import type { Listing, StoryItem, VideoPost } from "./types";

function iso(d: unknown): string {
  try {
    return new Date(d as string).toISOString();
  } catch {
    return new Date().toISOString();
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function videoToPost(v: any): VideoPost {
  return {
    id: v.id,
    title: v.title || "",
    description: v.description || "",
    videoUrl: v.videoUrl,
    posterUrl: v.posterUrl || "",
    views: v.views ?? 0,
    likes: v.likes ?? 0,
    pinned: !!v.pinned,
    createdAt: iso(v.createdAt),
  };
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function storyToItem(s: any): StoryItem {
  return {
    id: s.id,
    mediaUrl: s.mediaUrl,
    mediaType: s.mediaType === "video" ? "video" : "image",
    createdAt: iso(s.createdAt),
    expiresAt: iso(s.expiresAt),
  };
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function listingToListing(l: any): Listing {
  let images: string[] = [];
  try {
    images = JSON.parse(l.images || "[]");
    if (!Array.isArray(images)) images = [];
  } catch {
    images = [];
  }
  return {
    id: l.id,
    title: l.title || "",
    description: l.description || "",
    price: l.price ?? 0,
    type: l.type === "kiralik" ? "kiralik" : "satilik",
    status: ["satildi", "kiralandi"].includes(l.status) ? l.status : "aktif",
    rooms: l.rooms || "",
    area: l.area ?? 0,
    floor: l.floor || "",
    heating: l.heating || "",
    district: l.district || "",
    images,
    phone: l.phone || "",
    pinned: !!l.pinned,
    views: l.views ?? 0,
    createdAt: iso(l.createdAt),
  };
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function pollToJson(p: any): import("./types").Poll {
  let options: { id: string; text: string; votes: number }[] = [];
  try {
    const raw = JSON.parse(p.options || "[]");
    if (Array.isArray(raw)) {
      options = raw.map((o, i) => ({
        id: String(o?.id ?? i),
        text: String(o?.text ?? ""),
        votes: Number(o?.votes ?? 0),
      }));
    }
  } catch {
    options = [];
  }
  return {
    id: p.id,
    question: p.question || "",
    description: p.description || "",
    options,
    position: ["feed-top", "feed-inline", "emlak-top", "sikayet-top"].includes(p.position)
      ? p.position
      : "feed-top",
    active: !!p.active,
    pinned: !!p.pinned,
    multi: !!p.multi,
    showResults: p.showResults !== false,
    totalVotes: options.reduce((a, b) => a + b.votes, 0),
    createdAt: iso(p.createdAt),
  };
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function complaintToJson(c: any): import("./types").Complaint {
  return {
    id: c.id,
    name: c.name || "",
    district: c.district || "",
    title: c.title || "",
    body: c.body || "",
    mediaUrl: c.mediaUrl || "",
    mediaType: c.mediaType === "video" ? "video" : "image",
    posterUrl: c.posterUrl || "",
    status: ["onaylandi", "reddedildi"].includes(c.status) ? c.status : "beklemede",
    adminNote: c.adminNote || "",
    ticket: c.ticket || "",
    views: c.views ?? 0,
    pinned: !!c.pinned,
    createdAt: iso(c.createdAt),
  };
}
