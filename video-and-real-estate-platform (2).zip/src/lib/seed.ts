import { db } from "@/db";
import { complaints, listings, polls, stories, videos } from "@/db/schema";
import { getSetting, setSetting, setSettingJson } from "./settings";
import {
  DEFAULT_OWNER,
  DEFAULT_SEO,
  DEFAULT_SITE,
  type BannerItem,
} from "./types";
import { ensureVapidKeys } from "./push";

const H = 60 * 60 * 1000;

function ago(hours: number): Date {
  return new Date(Date.now() - hours * H);
}

const VIDEO_SEED = [
  {
    title: "Elbistan sokaklarından herkese merhaba!",
    description:
      "Sohbet Sokağı artık yayında. Şehrin nabzı burada atıyor — videolar, hikayeler ve emlak ilanlarıyla takipte kalın.",
    videoUrl:
      "https://videos.pexels.com/video-files/33567764/14271284_1920_1080_60fps.mp4",
    posterUrl:
      "https://images.pexels.com/videos/33567764/pexels-photo-33567764.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    views: 1284,
    likes: 342,
    pinned: true,
    createdAt: ago(31),
  },
  {
    title: "Elbistan ovasında sisli bir sabah",
    description:
      "Gün doğumunda ovanın üzerinde süzülen sis... Bazen şehrin en güzel hali sessiz halidir.",
    videoUrl:
      "https://videos.pexels.com/video-files/6062828/6062828-uhd_2560_1440_30fps.mp4",
    posterUrl:
      "https://images.pexels.com/videos/6062828/pexels-photo-6062828.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    views: 2143,
    likes: 587,
    pinned: false,
    createdAt: ago(22),
  },
  {
    title: "Çarşıda hafta sonu bereketi",
    description:
      "Elbistan çarşısı yine capcanlı. Esnafımıza hayırlı işler, hemşehrilerimize keyifli alışverişler.",
    videoUrl:
      "https://videos.pexels.com/video-files/39571015/16865430_2160_3840_60fps.mp4",
    posterUrl:
      "https://images.pexels.com/videos/39571015/pexels-photo-39571015.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    views: 864,
    likes: 219,
    pinned: false,
    createdAt: ago(14),
  },
  {
    title: "Akşam üzeri sokak turu",
    description:
      "Gün batarken sokaklarda kısa bir gezinti. Bu şehirde her köşe ayrı bir hikaye.",
    videoUrl:
      "https://videos.pexels.com/video-files/16668257/16668257-uhd_2160_3840_24fps.mp4",
    posterUrl:
      "https://images.pexels.com/videos/16668257/pexels-photo-16668257.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630",
    views: 697,
    likes: 180,
    pinned: false,
    createdAt: ago(7),
  },
  {
    title: "Sokakta hayat var",
    description:
      "Sabahın erken saatlerinden itibaren şehir uyanıyor. Sohbet Sokağı ile anı yakala.",
    videoUrl:
      "https://videos.pexels.com/video-files/5044654/5044654-hd_1920_1080_25fps.mp4",
    posterUrl:
      "https://images.pexels.com/videos/5044654/pexels-photo-5044654.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
    views: 512,
    likes: 143,
    pinned: false,
    createdAt: ago(2),
  },
];

const STORY_SEED = [
  {
    mediaUrl:
      "https://images.pexels.com/photos/8815915/pexels-photo-8815915.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    mediaType: "image",
    createdAt: ago(6),
  },
  {
    mediaUrl:
      "https://images.pexels.com/photos/8470800/pexels-photo-8470800.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
    mediaType: "image",
    createdAt: ago(4),
  },
  {
    mediaUrl:
      "https://images.pexels.com/photos/7587828/pexels-photo-7587828.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    mediaType: "image",
    createdAt: ago(2),
  },
  {
    mediaUrl:
      "https://videos.pexels.com/video-files/16668257/16668257-uhd_2160_3840_24fps.mp4",
    mediaType: "video",
    createdAt: ago(1),
  },
];

const LISTING_SEED = [
  {
    title: "Cumhuriyet Mah. 3+1 Satılık Daire",
    description:
      "Elbistan merkezde, okul ve çarşıya yürüme mesafesinde, geniş ve ferah 3+1 daire. Güney cepheli, gün boyu güneş alır. Binada asansör ve otopark mevcuttur. Krediye uygundur.",
    price: 3450000,
    type: "satilik",
    status: "aktif",
    rooms: "3+1",
    area: 145,
    floor: "3. Kat",
    heating: "Doğalgaz Kombi",
    district: "Cumhuriyet",
    images: JSON.stringify([
      "https://images.pexels.com/photos/11631278/pexels-photo-11631278.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/8089172/pexels-photo-8089172.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/6585598/pexels-photo-6585598.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ]),
    pinned: true,
    views: 342,
    createdAt: ago(50),
  },
  {
    title: "Pınarbaşı'nda 2+1 Kiralık Eşyalı Daire",
    description:
      "Tam eşyalı, temiz ve bakımlı 2+1 daire. Öğrenci ve memur için ideal. Merkezi konum, ulaşım sorunu yok. Depozito 2 kiradır.",
    price: 22500,
    type: "kiralik",
    status: "aktif",
    rooms: "2+1",
    area: 95,
    floor: "5. Kat",
    heating: "Doğalgaz Kombi",
    district: "Pınarbaşı",
    images: JSON.stringify([
      "https://images.pexels.com/photos/16110999/pexels-photo-16110999.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/19916712/pexels-photo-19916712.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/6580396/pexels-photo-6580396.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ]),
    pinned: true,
    views: 511,
    createdAt: ago(40),
  },
  {
    title: "Güneşli Mah. Müstakil Bahçeli Ev",
    description:
      "210 m² kullanım alanlı, 400 m² bahçe içerisinde müstakil ev. Meyve ağaçları, kiler ve otopark mevcut. Sessiz, sakin bir mahallede aile yaşamına uygun.",
    price: 5750000,
    type: "satilik",
    status: "aktif",
    rooms: "4+1",
    area: 210,
    floor: "Müstakil",
    heating: "Kat Kaloriferi",
    district: "Güneşli",
    images: JSON.stringify([
      "https://images.pexels.com/photos/5674684/pexels-photo-5674684.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/6920439/pexels-photo-6920439.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/27459248/pexels-photo-27459248.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ]),
    pinned: false,
    views: 289,
    createdAt: ago(30),
  },
  {
    title: "Orhangazi'de Satılık Dükkan — Cadde Üzeri",
    description:
      "Ana cadde üzerinde, yüksek yaya trafiğine sahip 120 m² dükkan. Her türlü ticari faaliyete uygun. Yatırım için kaçırılmayacak fırsat.",
    price: 8250000,
    type: "satilik",
    status: "aktif",
    rooms: "Dükkan",
    area: 120,
    floor: "Zemin Kat",
    heating: "Klima",
    district: "Orhangazi",
    images: JSON.stringify([
      "https://images.pexels.com/photos/31656156/pexels-photo-31656156.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/31656143/pexels-photo-31656143.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ]),
    pinned: false,
    views: 176,
    createdAt: ago(26),
  },
  {
    title: "Tepebaşı 1+1 Kiralık Rezidans",
    description:
      "Yeni binada, modern tasarımlı 1+1 rezidans dairesi. Eşyalı teslim. Site içerisinde güvenlik ve otopark mevcut.",
    price: 18000,
    type: "kiralik",
    status: "kiralandi",
    rooms: "1+1",
    area: 62,
    floor: "7. Kat",
    heating: "Merkezi Isıtma",
    district: "Tepebaşı",
    images: JSON.stringify([
      "https://images.pexels.com/photos/37224965/pexels-photo-37224965.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/19916712/pexels-photo-19916712.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ]),
    pinned: false,
    views: 420,
    createdAt: ago(70),
  },
  {
    title: "Yunus Emre Mah. 4+1 Lüks Dubleks",
    description:
      "Geniş aileler için 4+1 dubleks. Teraslı, ebeveyn banyolu, ankastre mutfaklı. Elbistan'ın en nezih mahallelerinden birinde.",
    price: 6900000,
    type: "satilik",
    status: "satildi",
    rooms: "4+1",
    area: 240,
    floor: "6-7. Kat (Dubleks)",
    heating: "Doğalgaz Kombi",
    district: "Yunus Emre",
    images: JSON.stringify([
      "https://images.pexels.com/photos/31656143/pexels-photo-31656143.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/8089172/pexels-photo-8089172.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
      "https://images.pexels.com/photos/6580396/pexels-photo-6580396.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
    ]),
    pinned: false,
    views: 638,
    createdAt: ago(90),
  },
];

export async function ensureSeed(): Promise<void> {
  if (await getSetting("seeded_v1")) return;
  try {
    // Varsayılan site ayarları
    if (!(await getSetting("site_name")))
      await setSetting("site_name", DEFAULT_SITE.siteName);
    if (!(await getSetting("tagline")))
      await setSetting("tagline", DEFAULT_SITE.tagline);
    if (!(await getSetting("footer_text")))
      await setSetting("footer_text", DEFAULT_SITE.footerText);
    if (!(await getSetting("theme")))
      await setSettingJson("theme", DEFAULT_SITE.theme);
    if (!(await getSetting("owner")))
      await setSettingJson("owner", DEFAULT_OWNER);
    if (!(await getSetting("seo")))
      await setSettingJson("seo", DEFAULT_SEO);
    if (!(await getSetting("banners"))) {
      const banners: BannerItem[] = [
        {
          id: "bnr-emlak",
          imageUrl:
            "https://images.pexels.com/photos/6920439/pexels-photo-6920439.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          title: "Sohbet Sokağı Emlak — Aradığın ev burada",
          linkUrl: "/emlak",
          active: true,
          position: "feed-top",
        },
        {
          id: "bnr-ilan",
          imageUrl:
            "https://images.pexels.com/photos/8089172/pexels-photo-8089172.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          title: "Kiralık mı arıyorsun? Güncel ilanlara göz at",
          linkUrl: "/emlak",
          active: true,
          position: "feed-inline",
        },
        {
          id: "bnr-isbirligi",
          imageUrl:
            "https://images.pexels.com/photos/6585598/pexels-photo-6585598.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200",
          title: "İşletmeni binlerce Elbistanlıya tanıt — Reklam ver",
          linkUrl: "https://wa.me/905551112233?text=Merhaba,%20reklam%20vermek%20istiyorum.",
          active: true,
          position: "emlak-top",
        },
      ];
      await setSettingJson("banners", banners);
    }
    await ensureVapidKeys();

    // Videolar
    await db.insert(videos).values(VIDEO_SEED);
    // Hikayeler (24 saat ömürlü)
    await db.insert(stories).values(
      STORY_SEED.map((s) => ({
        ...s,
        expiresAt: new Date(s.createdAt.getTime() + 24 * H),
      }))
    );
    // İlanlar
    await db.insert(listings).values(
      LISTING_SEED.map((l) => ({ ...l, updatedAt: l.createdAt }))
    );

    // Örnek anket
    await db.insert(polls).values({
      question: "Elbistan'da en acil çözülmesi gereken sorun hangisi?",
      description: "Oyunu kullan, sonuçları anında gör. Her IP bir kez oy verebilir.",
      options: JSON.stringify([
        { id: "o1", text: "Yol ve kaldırımlar", votes: 42 },
        { id: "o2", text: "Trafik ve otopark", votes: 28 },
        { id: "o3", text: "Çöp ve temizlik", votes: 19 },
        { id: "o4", text: "Park ve yeşil alan", votes: 11 },
      ]),
      position: "feed-top",
      active: true,
      pinned: true,
      showResults: true,
    });

    // Örnek şikayet (onaylı)
    await db.insert(complaints).values({
      name: "Mehmet K.",
      district: "Cumhuriyet",
      title: "Sokak lambaları üç gündür yanmıyor",
      body: "Cumhuriyet Mahallesi 12. sokakta lambalar üç gündür yanmıyor. Akşamları yürümek tehlikeli hale geldi. İlgililerin dikkatine sunulur.",
      mediaUrl:
        "https://images.pexels.com/photos/13577422/pexels-photo-13577422.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200",
      mediaType: "image",
      status: "onaylandi",
      ticket: "SS-A1B2C3",
      views: 164,
      ip: "0.0.0.0",
      createdAt: ago(12),
      reviewedAt: ago(10),
    });

    await setSetting("seeded_v1", new Date().toISOString());
  } catch (e) {
    // Yarım kalan tohum bir sonraki istekte tekrar denenebilir
    console.error("Seed hatası:", e);
  }
}
