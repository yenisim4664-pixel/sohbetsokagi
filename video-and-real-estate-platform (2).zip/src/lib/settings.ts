import { db } from "@/db";
import { settings } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  DEFAULT_SITE,
  DEFAULT_DARK_THEME,
  DEFAULT_WATERMARK,
  type BannerItem,
  type OwnerProfile,
  type SeoConfig,
  type SiteData,
  type ThemeConfig,
  type WatermarkConfig,
} from "./types";

export function safeParse<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export async function getSetting(key: string): Promise<string | null> {
  try {
    const rows = await db
      .select()
      .from(settings)
      .where(eq(settings.key, key))
      .limit(1);
    return rows[0]?.value ?? null;
  } catch {
    return null;
  }
}

export async function setSetting(key: string, value: string): Promise<void> {
  await db
    .insert(settings)
    .values({ key, value })
    .onConflictDoUpdate({ target: settings.key, set: { value } });
}

export async function setSettingJson(key: string, value: unknown) {
  await setSetting(key, JSON.stringify(value));
}

export async function loadSiteData(): Promise<SiteData> {
  let rows: { key: string; value: string }[] = [];
  try {
    rows = await db.select().from(settings);
  } catch {
    rows = [];
  }
  const map = new Map(rows.map((r) => [r.key, r.value]));

  const theme = {
    ...DEFAULT_SITE.theme,
    ...safeParse<Partial<ThemeConfig>>(map.get("theme"), {}),
  };
  const owner = {
    ...DEFAULT_SITE.owner,
    ...safeParse<Partial<OwnerProfile>>(map.get("owner"), {}),
  };
  const seo = {
    ...DEFAULT_SITE.seo,
    ...safeParse<Partial<SeoConfig>>(map.get("seo"), {}),
  };
  const banners = safeParse<BannerItem[]>(map.get("banners"), []);
  const darkTheme = {
    ...DEFAULT_DARK_THEME,
    ...safeParse<Partial<ThemeConfig>>(map.get("dark_theme"), {}),
  };
  const watermark = {
    ...DEFAULT_WATERMARK,
    ...safeParse<Partial<WatermarkConfig>>(map.get("watermark"), {}),
  };

  return {
    siteName: map.get("site_name") || DEFAULT_SITE.siteName,
    tagline: map.get("tagline") || DEFAULT_SITE.tagline,
    logoUrl: map.get("logo_url") || "",
    footerText: map.get("footer_text") || DEFAULT_SITE.footerText,
    theme,
    owner,
    banners,
    seo,
    ownerIps: map.get("owner_ips") || "",
    pushOnPost: map.get("push_on_post") !== "0",
    darkTheme,
    watermark,
    darkEnabled: map.get("dark_enabled") !== "0",
    complaintsEnabled: map.get("complaints_enabled") !== "0",
    complaintIntro:
      map.get("complaint_intro") ||
      "Mahallendeki sorunu, bozuk yolu, çöpü veya aksaklığı fotoğraf/video ile bildir. Gönderin yöneticinin onayından sonra yayınlanır.",
  };
}
