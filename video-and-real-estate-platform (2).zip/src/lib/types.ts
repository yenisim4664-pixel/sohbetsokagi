// Paylaşılan (client + server) tip tanımları, varsayılanlar ve yardımcılar.

export type VideoPost = {
  id: number;
  title: string;
  description: string;
  videoUrl: string;
  posterUrl: string;
  views: number;
  likes: number;
  pinned: boolean;
  createdAt: string; // ISO
};

export type StoryItem = {
  id: number;
  mediaUrl: string;
  mediaType: "image" | "video";
  createdAt: string;
  expiresAt: string;
};

export type Listing = {
  id: number;
  title: string;
  description: string;
  price: number;
  type: "satilik" | "kiralik";
  status: "aktif" | "satildi" | "kiralandi";
  rooms: string;
  area: number;
  floor: string;
  heating: string;
  district: string;
  images: string[];
  phone: string;
  pinned: boolean;
  views: number;
  createdAt: string;
};

export type BannerItem = {
  id: string;
  imageUrl: string;
  title: string;
  linkUrl: string;
  active: boolean;
  position: "feed-top" | "feed-inline" | "emlak-top";
};

export type OwnerProfile = {
  name: string;
  username: string;
  avatar: string;
  bio: string;
  verified: boolean;
  instagram: string;
  whatsapp: string; // 905xxxxxxxxx
  email: string;
};

export type ThemeConfig = {
  accent: string;
  accentInk: string;
  gradientFrom: string;
  gradientTo: string;
  bg: string;
  card: string;
  ink: string;
  muted: string;
  line: string;
  radius: string;
};

export type SeoConfig = {
  title: string;
  description: string;
  keywords: string;
  ogImage: string;
};

export type SiteData = {
  siteName: string;
  tagline: string;
  logoUrl: string;
  footerText: string;
  theme: ThemeConfig;
  owner: OwnerProfile;
  banners: BannerItem[];
  seo: SeoConfig;
  ownerIps: string;
  pushOnPost: boolean;
  darkTheme: ThemeConfig;
  watermark: WatermarkConfig;
  darkEnabled: boolean;
  complaintsEnabled: boolean;
  complaintIntro: string;
};

// ---------------- Varsayılanlar ----------------

export const DEFAULT_THEME: ThemeConfig = {
  accent: "#FF5A3C",
  accentInk: "#FFFFFF",
  gradientFrom: "#FF8A00",
  gradientTo: "#E1306C",
  bg: "#FAF7F3",
  card: "#FFFFFF",
  ink: "#1C1611",
  muted: "#98897B",
  line: "#F0E8E0",
  radius: "20px",
};

export type WatermarkConfig = {
  enabled: boolean;
  text: string;
  opacity: number; // 0-100
  size: number; // px
  position: "center" | "tile" | "bottom-right" | "top-left";
  color: string;
  rotate: number;
};

export const DEFAULT_WATERMARK: WatermarkConfig = {
  enabled: true,
  text: "Sohbet Sokağı",
  opacity: 22,
  size: 26,
  position: "tile",
  color: "#FFFFFF",
  rotate: -24,
};

export const DEFAULT_DARK_THEME: ThemeConfig = {
  accent: "#FF6A4D",
  accentInk: "#16110D",
  gradientFrom: "#FF8A00",
  gradientTo: "#E1306C",
  bg: "#100E0C",
  card: "#1A1714",
  ink: "#F5EFE8",
  muted: "#9C8E80",
  line: "#2B2620",
  radius: "20px",
};

export const THEME_PRESETS: { id: string; name: string; theme: ThemeConfig }[] = [
  {
    id: "acik",
    name: "Açık Sıcak",
    theme: { ...DEFAULT_THEME },
  },
  {
    id: "gece",
    name: "Gece",
    theme: {
      accent: "#FF6A4D",
      accentInk: "#16110D",
      gradientFrom: "#FF8A00",
      gradientTo: "#E1306C",
      bg: "#12100E",
      card: "#1C1915",
      ink: "#F4EEE6",
      muted: "#8D8073",
      line: "#2C2721",
      radius: "20px",
    },
  },
  {
    id: "okyanus",
    name: "Okyanus",
    theme: {
      ...DEFAULT_THEME,
      accent: "#0E8FD6",
      gradientFrom: "#19B3F0",
      gradientTo: "#0E5FD6",
      bg: "#F4F8FB",
      line: "#E4EDF4",
      muted: "#7E93A3",
    },
  },
  {
    id: "yosun",
    name: "Yosun",
    theme: {
      ...DEFAULT_THEME,
      accent: "#1C9E57",
      gradientFrom: "#3BC476",
      gradientTo: "#0E7A45",
      bg: "#F5F9F4",
      line: "#E5EEE3",
      muted: "#82997F",
    },
  },
  {
    id: "mor",
    name: "Gece Moru",
    theme: {
      ...DEFAULT_THEME,
      accent: "#7C4DFF",
      gradientFrom: "#A265FF",
      gradientTo: "#5A2ED6",
      bg: "#F6F4FB",
      line: "#EAE5F6",
      muted: "#8E84A6",
    },
  },
];

export const DEFAULT_OWNER: OwnerProfile = {
  name: "Sohbet Sokağı",
  username: "sohbetsokagi",
  avatar: "/images/avatar.jpg",
  bio: "Elbistan'ın video ve emlak platformu.\nSokaktan kesitler, güncel ilanlar, şehrin nabzı.\nReklam ve iş birliği için WhatsApp.",
  verified: true,
  instagram: "https://instagram.com/sohbetsokagi",
  whatsapp: "905551112233",
  email: "info@sohbetsokagi.com",
};

export const DEFAULT_SEO: SeoConfig = {
  title: "Sohbet Sokağı — Elbistan Video Akışı ve Emlak Platformu",
  description:
    "Elbistan merkezli Sohbet Sokağı: şehirden akıcı videolar, 24 saatlik hikayeler ve Sohbet Sokağı Emlak ile kiralık & satılık ilanları. Giriş yok, üyelik yok — herkes izleyebilir.",
  keywords:
    "Elbistan, sohbet sokağı, elbistan emlak, elbistan kiralık daire, elbistan satılık ev, elbistan videoları, Kahramanmaraş Elbistan",
  ogImage: "/icons/icon-512.png",
};

export const DEFAULT_SITE: SiteData = {
  siteName: "Sohbet Sokağı",
  tagline: "Elbistan'ın sokak sokak video ve emlak platformu",
  logoUrl: "",
  footerText: "© Sohbet Sokağı — Elbistan. Tüm hakları saklıdır.",
  theme: DEFAULT_THEME,
  owner: DEFAULT_OWNER,
  banners: [],
  seo: DEFAULT_SEO,
  ownerIps: "",
  pushOnPost: true,
  darkTheme: DEFAULT_DARK_THEME,
  watermark: DEFAULT_WATERMARK,
  darkEnabled: true,
  complaintsEnabled: true,
  complaintIntro:
    "Mahallendeki sorunu, bozuk yolu, çöpü veya aksaklığı fotoğraf/video ile bildir. Gönderin yöneticinin onayından sonra yayınlanır.",
};

// ---------------- Etiketler ----------------

export const LISTING_TYPE_LABEL: Record<string, string> = {
  satilik: "Satılık",
  kiralik: "Kiralık",
};

export const LISTING_STATUS_LABEL: Record<string, string> = {
  aktif: "Yayında",
  satildi: "Satıldı",
  kiralandi: "Kiralandı",
};

export const DISTRICTS = [
  "Cumhuriyet",
  "Güneşli",
  "Pınarbaşı",
  "Tepebaşı",
  "Orhangazi",
  "Yunus Emre",
  "Bahçelievler",
  "Esentepe",
  "Kızılcaoba",
  "Taşoluk",
  "Ağcaşar",
  "Karaelbistan",
  "İğde",
  "Afsin Yolu",
];

export const HEATING_OPTIONS = [
  "Doğalgaz Kombi",
  "Merkezi Isıtma",
  "Kat Kaloriferi",
  "Soba",
  "Yerden Isıtma",
  "Klima",
  "Güneş Enerjisi",
];

// ---------------- Yardımcılar ----------------

export function timeAgo(iso: string): string {
  const d = new Date(iso).getTime();
  const s = Math.max(1, Math.floor((Date.now() - d) / 1000));
  if (s < 60) return "az önce";
  const m = Math.floor(s / 60);
  if (m < 60) return `${m} dk önce`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} sa önce`;
  const g = Math.floor(h / 24);
  if (g < 7) return `${g} gün önce`;
  const hf = Math.floor(g / 7);
  if (hf < 5) return `${hf} hf önce`;
  const ay = Math.floor(g / 30);
  if (ay < 12) return `${ay} ay önce`;
  return `${Math.floor(ay / 12)} yıl önce`;
}

export function fullDate(iso: string): string {
  return new Date(iso).toLocaleDateString("tr-TR", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

export function fullDateTime(iso: string): string {
  return new Date(iso).toLocaleString("tr-TR", {
    day: "numeric",
    month: "long",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function formatCount(n: number): string {
  if (n < 1000) return String(n);
  if (n < 1_000_000)
    return (
      (n / 1000).toLocaleString("tr-TR", { maximumFractionDigits: 1 }) + " B"
    );
  return (
    (n / 1_000_000).toLocaleString("tr-TR", { maximumFractionDigits: 1 }) +
    " Mn"
  );
}

export function formatPrice(n: number, type?: string): string {
  const base =
    "₺" + n.toLocaleString("tr-TR", { maximumFractionDigits: 0 });
  return type === "kiralik" ? base + "/ay" : base;
}

export function waLink(phone: string, text?: string): string {
  const clean = (phone || "").replace(/[^\d]/g, "");
  const t = text ? `?text=${encodeURIComponent(text)}` : "";
  return `https://wa.me/${clean}${t}`;
}

export function themeVars(t: ThemeConfig): Record<string, string> {
  return {
    "--accent": t.accent,
    "--accent-ink": t.accentInk,
    "--g-from": t.gradientFrom,
    "--g-to": t.gradientTo,
    "--bg": t.bg,
    "--card": t.card,
    "--ink": t.ink,
    "--muted": t.muted,
    "--line": t.line,
    "--radius": t.radius,
  };
}

/* ================= ANKET ================= */

export type PollOption = { id: string; text: string; votes: number };

export type Poll = {
  id: number;
  question: string;
  description: string;
  options: PollOption[];
  position: "feed-top" | "feed-inline" | "emlak-top" | "sikayet-top";
  active: boolean;
  pinned: boolean;
  multi: boolean;
  showResults: boolean;
  totalVotes: number;
  createdAt: string;
};

/* ================= ŞİKAYET ================= */

export type Complaint = {
  id: number;
  name: string;
  district: string;
  title: string;
  body: string;
  mediaUrl: string;
  mediaType: "image" | "video";
  posterUrl: string;
  status: "beklemede" | "onaylandi" | "reddedildi";
  adminNote: string;
  ticket: string;
  views: number;
  pinned: boolean;
  createdAt: string;
};

export const COMPLAINT_STATUS_LABEL: Record<string, string> = {
  beklemede: "Onay Bekliyor",
  onaylandi: "Yayında",
  reddedildi: "Reddedildi",
};

export function darkVars(t: ThemeConfig): Record<string, string> {
  return themeVars(t);
}

export function cssVarBlock(
  light: ThemeConfig,
  dark: ThemeConfig
): string {
  const toCss = (v: Record<string, string>) =>
    Object.entries(v)
      .map(([k, val]) => `${k}:${val}`)
      .join(";");
  return `:root{${toCss(themeVars(light))};color-scheme:light}
:root[data-ss-mode="dark"]{${toCss(themeVars(dark))};color-scheme:dark}`;
}
