"use client";

import { useEffect, useState } from "react";
import { Moon, Sun } from "lucide-react";

/** Aydınlık / Karanlık tema anahtarı — tercih tarayıcıda saklanır */
export default function ModeToggle() {
  const [dark, setDark] = useState(false);

  useEffect(() => {
    const current =
      document.documentElement.getAttribute("data-ss-mode") === "dark";
    setDark(current);
  }, []);

  function toggle() {
    const next = !dark;
    setDark(next);
    const root = document.documentElement;
    if (next) root.setAttribute("data-ss-mode", "dark");
    else root.removeAttribute("data-ss-mode");
    try {
      localStorage.setItem("ss_mode", next ? "dark" : "light");
    } catch {
      // yoksay
    }
    // Tarayıcı arayüz rengini de güncelle
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) {
      const bg = getComputedStyle(root).getPropertyValue("--bg").trim();
      if (bg) meta.setAttribute("content", bg);
    }
  }

  return (
    <button
      onClick={toggle}
      className="rounded-full p-2.5 transition active:scale-90"
      style={{ color: dark ? "var(--accent)" : "var(--muted)" }}
      aria-label={dark ? "Aydınlık temaya geç" : "Karanlık temaya geç"}
      title={dark ? "Aydınlık tema" : "Karanlık tema"}
    >
      {dark ? <Sun size={20} /> : <Moon size={20} />}
    </button>
  );
}
