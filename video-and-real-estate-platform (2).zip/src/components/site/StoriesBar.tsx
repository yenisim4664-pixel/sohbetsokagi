"use client";

import { useCallback, useEffect, useState } from "react";
import { createPortal } from "react-dom";
import type { OwnerProfile, StoryItem } from "@/lib/types";
import { timeAgo } from "@/lib/types";
import { Clock3, Play } from "lucide-react";
import { Trash2, X } from "lucide-react";
import { VerifiedBadge, useToast } from "./ui";
import { useRouter } from "next/navigation";

function StoryViewer({
  stories,
  index,
  owner,
  canManage,
  onClose,
  onIndex,
  onDeleted,
}: {
  stories: StoryItem[];
  index: number;
  owner: OwnerProfile;
  canManage: boolean;
  onClose: () => void;
  onIndex: (i: number) => void;
  onDeleted: (id: number) => void;
}) {
  const item = stories[index];
  const [vProgress, setVProgress] = useState(0);
  const { toast, node } = useToast();

  const next = useCallback(() => {
    if (index < stories.length - 1) onIndex(index + 1);
    else onClose();
  }, [index, stories.length, onIndex, onClose]);

  const prev = useCallback(() => {
    if (index > 0) onIndex(index - 1);
  }, [index, onIndex]);

  // Görseller için 5sn otomatik ilerleme
  useEffect(() => {
    if (!item || item.mediaType === "video") return;
    const t = setTimeout(next, 5000);
    return () => clearTimeout(t);
  }, [item, index, next]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") next();
      if (e.key === "ArrowLeft") prev();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [next, prev, onClose]);

  if (!item) return null;

  async function del() {
    const r = await fetch(`/api/stories?id=${item.id}`, { method: "DELETE" });
    if (r.ok) {
      toast("Hikaye silindi");
      onDeleted(item.id);
    } else toast("Silinemedi");
  }

  return createPortal(
    <div className="fixed inset-0 z-[95] flex items-center justify-center bg-black/95 backdrop-blur-sm">
      {node}
      <div className="animate-scale-in relative h-[100dvh] w-full overflow-hidden bg-black sm:h-[92dvh] sm:max-w-[410px] sm:rounded-2xl">
        {/* Medya */}
        {item.mediaType === "video" ? (
          <video
            key={item.id}
            src={item.mediaUrl}
            className="h-full w-full object-cover"
            autoPlay
            playsInline
            onEnded={next}
            onTimeUpdate={(e) => {
              const v = e.currentTarget;
              if (v.duration > 0)
                setVProgress((v.currentTime / v.duration) * 100);
            }}
          />
        ) : (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            key={item.id}
            src={item.mediaUrl}
            alt="Hikaye"
            className="h-full w-full object-cover"
          />
        )}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-black/70 to-transparent" />

        {/* İlerleme çubukları */}
        <div className="absolute inset-x-3 top-3 flex gap-1">
          {stories.map((s, i) => (
            <div
              key={s.id}
              className="h-[3px] flex-1 overflow-hidden rounded-full bg-white/30"
            >
              {i < index && <div className="h-full w-full bg-white" />}
              {i === index &&
                (item.mediaType === "video" ? (
                  <div
                    className="h-full bg-white"
                    style={{ width: `${vProgress}%` }}
                  />
                ) : (
                  <div
                    key={`p-${index}`}
                    className="story-progress-run h-full bg-white"
                  />
                ))}
            </div>
          ))}
        </div>

        {/* Üst bilgi */}
        <div className="absolute inset-x-0 top-7 flex items-center gap-2.5 px-4">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={owner.avatar}
            alt={owner.name}
            className="h-8 w-8 rounded-full border border-white/40 object-cover"
          />
          <span className="flex items-center gap-1 text-[13px] font-extrabold text-white drop-shadow">
            {owner.username}
            {owner.verified && <VerifiedBadge size={14} />}
          </span>
          <span className="text-[11.5px] font-semibold text-white/70">
            {timeAgo(item.createdAt)}
          </span>
          <div className="ml-auto flex items-center gap-1">
            {canManage && (
              <button
                onClick={del}
                className="rounded-full p-2 text-white/85 transition hover:bg-white/15"
                aria-label="Hikayeyi sil"
              >
                <Trash2 size={17} />
              </button>
            )}
            <button
              onClick={onClose}
              className="rounded-full p-2 text-white transition hover:bg-white/15"
              aria-label="Kapat"
            >
              <X size={19} />
            </button>
          </div>
        </div>

        {/* Dokunma bölgeleri */}
        <button
          className="absolute inset-y-0 left-0 w-1/3"
          onClick={prev}
          aria-label="Önceki hikaye"
        />
        <button
          className="absolute inset-y-0 right-0 w-2/3"
          onClick={next}
          aria-label="Sonraki hikaye"
        />
      </div>
    </div>,
    document.body
  );
}

export default function StoriesBar({
  stories: initialStories,
  owner,
  canManage,
}: {
  stories: StoryItem[];
  owner: OwnerProfile;
  canManage: boolean;
}) {
  const [stories, setStories] = useState(initialStories);
  const [openIdx, setOpenIdx] = useState<number | null>(null);
  const router = useRouter();

  if (stories.length === 0) return null;

  function onDeleted(id: number) {
    setStories((s) => {
      const next = s.filter((x) => x.id !== id);
      if (next.length === 0) {
        setOpenIdx(null);
        router.refresh();
      }
      return next;
    });
  }

  return (
    <section
      aria-label="Hikayeler"
      className="border-b border-[var(--line)] pb-1"
    >
      <div className="flex items-center justify-between px-4 pt-4">
        <h2 className="text-[13px] font-extrabold tracking-tight">
          Hikayeler
        </h2>
        <span className="flex items-center gap-1 text-[10.5px] font-bold text-[var(--muted)]">
          <Clock3 size={12} /> 24 saat sonra otomatik silinir
        </span>
      </div>
      <div className="no-scrollbar flex gap-4 overflow-x-auto px-4 py-3">
        {stories.map((s, i) => (
          <button
            key={s.id}
            onClick={() => setOpenIdx(i)}
            className="group flex w-[74px] shrink-0 flex-col items-center gap-1.5"
          >
            <span className="ring-gradient rounded-full p-[2.5px] transition group-hover:scale-105 group-active:scale-95">
              <span className="block h-[62px] w-[62px] overflow-hidden rounded-full border-[3px] border-[var(--bg)] bg-neutral-200">
                {s.mediaType === "video" ? (
                  <span className="relative flex h-full w-full items-center justify-center bg-neutral-800">
                    <video
                      src={s.mediaUrl}
                      className="absolute inset-0 h-full w-full object-cover"
                      muted
                      playsInline
                      preload="metadata"
                    />
                    <Play
                      size={20}
                      className="relative fill-white text-white drop-shadow"
                    />
                  </span>
                ) : (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={s.mediaUrl}
                    alt={`Hikaye ${i + 1}`}
                    loading="lazy"
                    className="h-full w-full object-cover"
                  />
                )}
              </span>
            </span>
            <span className="w-full truncate text-center text-[10.5px] font-bold text-[var(--ink)]/80">
              {i === 0 ? owner.username : timeAgo(s.createdAt)}
            </span>
          </button>
        ))}
      </div>
      {openIdx !== null && stories[openIdx] && (
        <StoryViewer
          stories={stories}
          index={openIdx}
          owner={owner}
          canManage={canManage}
          onClose={() => setOpenIdx(null)}
          onIndex={setOpenIdx}
          onDeleted={onDeleted}
        />
      )}
    </section>
  );
}
