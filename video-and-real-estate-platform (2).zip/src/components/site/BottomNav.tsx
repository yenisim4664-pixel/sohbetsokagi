"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { AlertCircle, Building2, Clapperboard, UserRound } from "lucide-react";

const ALL_ITEMS = [
  { href: "/", label: "Akış", icon: Clapperboard },
  { href: "/emlak", label: "Emlak", icon: Building2 },
  { href: "/profil", label: "Profil", icon: UserRound },
  { href: "/sikayetler", label: "Şikayet", icon: AlertCircle },
];

export default function BottomNav({
  complaintsEnabled = true,
}: {
  complaintsEnabled?: boolean;
}) {
  const pathname = usePathname();
  const ITEMS = complaintsEnabled
    ? ALL_ITEMS
    : ALL_ITEMS.filter((i) => i.href !== "/sikayetler");
  return (
    <nav className="pb-safe pointer-events-none fixed inset-x-0 bottom-0 z-40">
      <div className="flex justify-center pb-3">
        <div className="pointer-events-auto flex items-center gap-1 rounded-full border border-[var(--line)] bg-[var(--card)]/95 p-1.5 shadow-xl shadow-black/10 backdrop-blur-xl">
          {ITEMS.map((it) => {
            const active =
              it.href === "/" ? pathname === "/" : pathname.startsWith(it.href);
            const Icon = it.icon;
            return (
              <Link
                key={it.href}
                href={it.href}
                className={`flex items-center gap-1 rounded-full px-3 sm:px-4 py-2 text-[11.5px] font-extrabold transition active:scale-95 ${
                  active
                    ? "bg-[var(--ink)] text-[var(--bg)] shadow-sm"
                    : "text-[var(--muted)] hover:text-[var(--ink)]"
                }`}
              >
                <Icon size={16} strokeWidth={active ? 2.6 : 2} />
                {it.label}
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
