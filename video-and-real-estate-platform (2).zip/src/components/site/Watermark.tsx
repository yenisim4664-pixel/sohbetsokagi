"use client";

import type { WatermarkConfig } from "@/lib/types";

/** Şikayet medyalarının üzerine bindirilen şeffaf filigran katmanı */
export default function Watermark({ wm }: { wm: WatermarkConfig }) {
  if (!wm.enabled || !wm.text) return null;
  const common: React.CSSProperties = {
    color: wm.color,
    opacity: Math.min(100, Math.max(0, wm.opacity)) / 100,
    fontSize: `${wm.size}px`,
    fontWeight: 800,
    letterSpacing: "0.04em",
    textShadow: "0 1px 4px rgba(0,0,0,.35)",
    whiteSpace: "nowrap",
    userSelect: "none",
  };

  if (wm.position === "tile") {
    const rows = Array.from({ length: 6 });
    const cols = Array.from({ length: 3 });
    return (
      <div className="pointer-events-none absolute inset-0 z-10 overflow-hidden">
        <div
          className="absolute inset-[-25%] flex flex-col justify-around"
          style={{ transform: `rotate(${wm.rotate}deg)` }}
        >
          {rows.map((_, r) => (
            <div key={r} className="flex justify-around">
              {cols.map((__, c) => (
                <span key={c} style={common}>
                  {wm.text}
                </span>
              ))}
            </div>
          ))}
        </div>
      </div>
    );
  }

  const posCls =
    wm.position === "center"
      ? "items-center justify-center"
      : wm.position === "top-left"
        ? "items-start justify-start p-3"
        : "items-end justify-end p-3";

  return (
    <div
      className={`pointer-events-none absolute inset-0 z-10 flex ${posCls}`}
      aria-hidden="true"
    >
      <span
        style={{
          ...common,
          transform: wm.position === "center" ? `rotate(${wm.rotate}deg)` : undefined,
        }}
      >
        {wm.text}
      </span>
    </div>
  );
}
