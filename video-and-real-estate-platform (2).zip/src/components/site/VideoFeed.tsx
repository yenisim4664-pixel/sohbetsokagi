"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { BannerItem, OwnerProfile, Poll, VideoPost } from "@/lib/types";
import { Spinner } from "./ui";
import VideoCard from "./VideoCard";
import PollCard from "./PollCard";
import { Megaphone } from "lucide-react";

export function BannerCard({ banner }: { banner: BannerItem }) {
  const external = /^https?:\/\//.test(banner.linkUrl);
  return (
    <a
      href={banner.linkUrl || "#"}
      target={external ? "_blank" : undefined}
      rel={external ? "noopener noreferrer" : undefined}
      className="group animate-fade-up relative block h-44 overflow-hidden border border-[var(--line)] shadow-sm"
      style={{ borderRadius: "var(--radius)" }}
    >
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={banner.imageUrl}
        alt={banner.title}
        loading="lazy"
        className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/15 to-transparent" />
      <span className="absolute left-3 top-3 flex items-center gap-1 rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-extrabold text-neutral-800 shadow">
        <Megaphone size={11} /> ÖNE ÇIKAN
      </span>
      <p className="absolute bottom-3 left-4 right-4 text-[15px] font-extrabold leading-snug text-white drop-shadow">
        {banner.title}
      </p>
    </a>
  );
}

export default function VideoFeed({
  initial,
  owner,
  canManage,
  inlineBanners,
  inlinePolls = [],
}: {
  initial: VideoPost[];
  owner: OwnerProfile;
  canManage: boolean;
  inlineBanners: BannerItem[];
  inlinePolls?: Poll[];
}) {
  const [posts, setPosts] = useState<VideoPost[]>(initial);
  const [hasMore, setHasMore] = useState(initial.length >= 4);
  const [loading, setLoading] = useState(false);
  const offset = useRef(initial.length);
  const sentinel = useRef<HTMLDivElement>(null);

  const loadMore = useCallback(async () => {
    if (loading) return;
    setLoading(true);
    try {
      const r = await fetch(
        `/api/videos?offset=${offset.current}&limit=4`
      );
      const j = await r.json();
      if (r.ok) {
        offset.current += j.videos.length;
        setPosts((p) => {
          const ids = new Set(p.map((x) => x.id));
          return [...p, ...j.videos.filter((v: VideoPost) => !ids.has(v.id))];
        });
        setHasMore(j.hasMore);
      }
    } catch {
      setHasMore(false);
    }
    setLoading(false);
  }, [loading]);

  useEffect(() => {
    const el = sentinel.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loading) loadMore();
      },
      { rootMargin: "900px 0px" }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [hasMore, loading, loadMore]);

  const onUpdated = useCallback((v: VideoPost) => {
    setPosts((p) =>
      [...p.map((x) => (x.id === v.id ? v : x))].sort((a, b) => {
        if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
        return +new Date(b.createdAt) - +new Date(a.createdAt);
      })
    );
  }, []);

  const onDeleted = useCallback((id: number) => {
    setPosts((p) => p.filter((x) => x.id !== id));
  }, []);

  // Banner'ları akışa serpiştir (3. ve sonrası her 4 gönderide bir)
  const items: React.ReactNode[] = [];
  posts.forEach((p, i) => {
    if (inlineBanners.length > 0 && i > 0 && i % 3 === 0) {
      const b = inlineBanners[(i / 3 - 1) % inlineBanners.length];
      items.push(<BannerCard key={`b-${i}`} banner={b} />);
    }
    if (inlinePolls.length > 0 && i > 0 && i % 2 === 0) {
      const pl = inlinePolls[(i / 2 - 1) % inlinePolls.length];
      items.push(<PollCard key={`pl-${i}-${pl.id}`} poll={pl} />);
    }
    items.push(
      <VideoCard
        key={p.id}
        post={p}
        owner={owner}
        canManage={canManage}
        onUpdated={onUpdated}
        onDeleted={onDeleted}
      />
    );
  });

  return (
    <div className="flex flex-col gap-5">
      {items}
      <div ref={sentinel} className="h-1" />
      {loading && (
        <div className="flex justify-center py-6 text-[var(--muted)]">
          <Spinner size={22} />
        </div>
      )}
      {!hasMore && posts.length > 0 && (
        <p className="py-6 text-center text-[12px] font-bold text-[var(--muted)]">
          Sohbet Sokağı&apos;nın sonuna geldiniz — yenileri için takipte kalın
        </p>
      )}
      {posts.length === 0 && !loading && (
        <p className="py-12 text-center text-sm font-semibold text-[var(--muted)]">
          Henüz video paylaşılmadı.
        </p>
      )}
    </div>
  );
}
