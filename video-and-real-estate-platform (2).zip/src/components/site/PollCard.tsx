"use client";

import { useEffect, useState } from "react";
import type { Poll } from "@/lib/types";
import { formatCount } from "@/lib/types";
import { BarChart3, Check, Users } from "lucide-react";
import { useToast } from "./ui";

export default function PollCard({ poll: initial }: { poll: Poll }) {
  const [poll, setPoll] = useState(initial);
  const [voted, setVoted] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const { toast, node } = useToast();

  useEffect(() => {
    try {
      const map = JSON.parse(localStorage.getItem("ss_polls") || "{}");
      if (map[poll.id]) setVoted(map[poll.id]);
    } catch {
      setVoted(null);
    }
  }, [poll.id]);

  async function vote(optionId: string) {
    if (voted || busy || !poll.active) return;
    setBusy(true);
    try {
      const r = await fetch(`/api/polls/${poll.id}/vote`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ optionId }),
      });
      const j = await r.json();
      if (r.ok || j.already) {
        if (j.poll) setPoll(j.poll);
        setVoted(optionId);
        try {
          const map = JSON.parse(localStorage.getItem("ss_polls") || "{}");
          map[poll.id] = optionId;
          localStorage.setItem("ss_polls", JSON.stringify(map));
        } catch {
          // yoksay
        }
        toast(j.already ? "Bu ankete zaten oy verdiniz" : "Oyunuz kaydedildi, teşekkürler!");
      } else {
        toast(j.error || "Oy verilemedi");
      }
    } catch {
      toast("Bağlantı hatası");
    }
    setBusy(false);
  }

  const showResults = voted !== null || !poll.active || !poll.showResults === false;
  const reveal = voted !== null || !poll.active;
  const total = poll.options.reduce((a, b) => a + b.votes, 0);

  return (
    <section
      className="animate-fade-up overflow-hidden border p-5"
      style={{
        borderColor: "var(--line)",
        background: "var(--card)",
        borderRadius: "var(--radius)",
      }}
      aria-label="Anket"
    >
      {node}
      <div className="flex items-center gap-2">
        <span
          className="flex h-7 w-7 items-center justify-center rounded-lg"
          style={{
            background: "color-mix(in srgb, var(--accent) 12%, transparent)",
            color: "var(--accent)",
          }}
        >
          <BarChart3 size={15} />
        </span>
        <span
          className="text-[10.5px] font-extrabold uppercase tracking-wide"
          style={{ color: "var(--accent)" }}
        >
          Anket
        </span>
        {!poll.active && (
          <span className="ml-auto rounded-full bg-[var(--bg)] px-2.5 py-1 text-[10px] font-extrabold text-[var(--muted)]">
            KAPANDI
          </span>
        )}
      </div>

      <h3 className="mt-2.5 text-[15.5px] font-extrabold leading-snug tracking-tight">
        {poll.question}
      </h3>
      {poll.description && (
        <p className="mt-1 text-[12.5px] font-medium leading-relaxed text-[var(--muted)]">
          {poll.description}
        </p>
      )}

      <div className="mt-3.5 flex flex-col gap-2">
        {poll.options.map((o) => {
          const pct = total > 0 ? Math.round((o.votes / total) * 100) : 0;
          const mine = voted === o.id;
          return (
            <button
              key={o.id}
              onClick={() => vote(o.id)}
              disabled={reveal || busy}
              className="relative w-full overflow-hidden rounded-xl border px-3.5 py-2.5 text-left transition active:scale-[.99] disabled:cursor-default"
              style={{
                borderColor: mine ? "var(--accent)" : "var(--line)",
                background: "var(--bg)",
              }}
            >
              {reveal && poll.showResults && (
                <span
                  className="absolute inset-y-0 left-0 transition-all duration-700"
                  style={{
                    width: `${pct}%`,
                    background: mine
                      ? "color-mix(in srgb, var(--accent) 24%, transparent)"
                      : "color-mix(in srgb, var(--ink) 8%, transparent)",
                  }}
                />
              )}
              <span className="relative flex items-center gap-2">
                <span
                  className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full border-2"
                  style={{
                    borderColor: mine ? "var(--accent)" : "var(--muted)",
                    background: mine ? "var(--accent)" : "transparent",
                  }}
                >
                  {mine && <Check size={10} className="text-[var(--accent-ink)]" />}
                </span>
                <span className="flex-1 text-[13px] font-bold">{o.text}</span>
                {reveal && poll.showResults && (
                  <span className="shrink-0 text-[12px] font-extrabold tabular-nums">
                    %{pct}
                    <span className="ml-1.5 text-[10.5px] font-bold text-[var(--muted)]">
                      ({formatCount(o.votes)})
                    </span>
                  </span>
                )}
              </span>
            </button>
          );
        })}
      </div>

      <p className="mt-3 flex items-center gap-1.5 text-[11px] font-bold text-[var(--muted)]">
        <Users size={12} />
        {formatCount(total)} oy kullanıldı
        {!reveal && " · Sonuçları görmek için oy verin"}
      </p>
    </section>
  );
}
