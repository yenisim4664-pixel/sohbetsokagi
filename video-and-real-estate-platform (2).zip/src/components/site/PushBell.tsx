"use client";

import { useEffect, useState } from "react";
import { Bell, BellOff, BellRing } from "lucide-react";
import { useToast } from "./ui";

function urlB64ToUint8Array(base64String: string): Uint8Array {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) outputArray[i] = rawData.charCodeAt(i);
  return outputArray;
}

export default function PushBell() {
  const [state, setState] = useState<
    "idle" | "on" | "off" | "unsupported" | "busy"
  >("idle");
  const { toast, node } = useToast();

  useEffect(() => {
    if (
      typeof window === "undefined" ||
      !("serviceWorker" in navigator) ||
      !("PushManager" in window)
    ) {
      setState("unsupported");
      return;
    }
    if (Notification.permission === "denied") {
      setState("off");
      return;
    }
    navigator.serviceWorker
      .getRegistration("/sw.js")
      .then(async (reg) => {
        if (!reg) return setState("idle");
        const sub = await reg.pushManager.getSubscription();
        setState(sub ? "on" : "idle");
      })
      .catch(() => setState("idle"));
  }, []);

  async function enable() {
    try {
      setState("busy");
      const reg = await navigator.serviceWorker.register("/sw.js");
      const perm = await Notification.requestPermission();
      if (perm !== "granted") {
        setState("off");
        toast("Bildirim izni verilmedi");
        return;
      }
      const res = await fetch("/api/push");
      const { publicKey } = await res.json();
      const sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlB64ToUint8Array(publicKey) as BufferSource,
      });
      await fetch("/api/push", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subscription: sub.toJSON() }),
      });
      setState("on");
      toast("Bildirimler açıldı — yeni videoları kaçırmayın!");
    } catch {
      setState("idle");
      toast("Bildirimler açılamadı");
    }
  }

  if (state === "unsupported") return null;

  return (
    <>
      {node}
      <button
        onClick={enable}
        disabled={state === "busy" || state === "on"}
        className={`rounded-full p-2.5 transition active:scale-90 ${
          state === "on"
            ? "bg-[var(--accent)]/10 text-[var(--accent)]"
            : "text-[var(--muted)] hover:bg-[var(--card)] hover:text-[var(--ink)]"
        } disabled:cursor-default`}
        aria-label={
          state === "on" ? "Bildirimler açık" : "Bildirimleri aç"
        }
        title={
          state === "on"
            ? "Bildirimler açık"
            : "Yeni videolardan anında haberdar ol"
        }
      >
        {state === "on" ? (
          <BellRing size={20} />
        ) : state === "off" ? (
          <BellOff size={20} />
        ) : (
          <Bell size={20} className={state === "busy" ? "animate-pulse" : ""} />
        )}
      </button>
    </>
  );
}
