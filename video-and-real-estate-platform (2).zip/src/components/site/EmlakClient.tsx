"use client";

import { useMemo, useState } from "react";
import type { BannerItem, Listing, OwnerProfile, Poll } from "@/lib/types";
import {
  DISTRICTS,
  formatCount,
  formatPrice,
  fullDate,
  timeAgo,
  waLink,
} from "@/lib/types";
import {
  Bath,
  BedDouble,
  ChevronLeft,
  ChevronRight,
  Eye,
  Flame,
  KeyRound,
  Layers,
  MapPin,
  Megaphone,
  MessageCircle,
  Phone,
  Pin,
  Ruler,
  Search,
  Tag,
  Trash2,
  X,
} from "lucide-react";
import { InstagramIcon, VerifiedBadge, useToast } from "./ui";
import PollCard from "./PollCard";

const FILTERS = [
  { id: "all", label: "Tümü" },
  { id: "satilik", label: "Satılık" },
  { id: "kiralik", label: "Kiralık" },
  { id: "satildi", label: "Satıldı" },
  { id: "kiralandi", label: "Kiralandı" },
];

const STATUS_STYLE: Record<string, string> = {
  satildi: "bg-rose-600 text-white",
  kiralandi: "bg-amber-500 text-white",
};

const STATUS_LABEL: Record<string, string> = {
  aktif: "Yayında",
  satildi: "Satıldı",
  kiralandi: "Kiralandı",
};

function StatusBadge({ status }: { status: string }) {
  if (status === "aktif") return null;
  return (
    <span
      className={`rounded-full px-2.5 py-1 text-[10px] font-extrabold shadow ${STATUS_STYLE[status]}`}
    >
      {STATUS_LABEL[status]}
    </span>
  );
}

function TypeBadge({ type }: { type: string }) {
  return (
    <span
      className={`rounded-full px-2.5 py-1 text-[10px] font-extrabold shadow ${
        type === "kiralik" ? "bg-sky-600 text-white" : "bg-white/95 text-neutral-900"
      }`}
    >
      {type === "kiralik" ? "KİRALIK" : "SATILIK"}
    </span>
  );
}

function Carousel({
  images,
  title,
  h,
}: {
  images: string[];
  title: string;
  h: string;
}) {
  const [idx, setIdx] = useState(0);
  if (images.length === 0)
    return (
      <div
        className={`flex ${h} items-center justify-center bg-[var(--bg)] text-[var(--muted)]`}
      >
        <KeyRound size={28} />
      </div>
    );
  return (
    <div className={`relative ${h} overflow-hidden bg-neutral-200`}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={images[idx]}
        alt={title}
        loading="lazy"
        className="h-full w-full object-cover"
      />
      {images.length > 1 && (
        <>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIdx((i) => (i - 1 + images.length) % images.length);
            }}
            className="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-black/45 p-1.5 text-white backdrop-blur transition hover:bg-black/65"
            aria-label="Önceki fotoğraf"
          >
            <ChevronLeft size={16} />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIdx((i) => (i + 1) % images.length);
            }}
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-black/45 p-1.5 text-white backdrop-blur transition hover:bg-black/65"
            aria-label="Sonraki fotoğraf"
          >
            <ChevronRight size={16} />
          </button>
          <div className="absolute bottom-2 left-1/2 flex -translate-x-1/2 gap-1">
            {images.map((_, i) => (
              <span
                key={i}
                className={`h-1.5 rounded-full transition-all ${
                  i === idx ? "w-4 bg-white" : "w-1.5 bg-white/50"
                }`}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default function EmlakClient({
  listings: initial,
  owner,
  banners,
  canManage,
  polls = [],
}: {
  listings: Listing[];
  owner: OwnerProfile;
  banners: BannerItem[];
  canManage: boolean;
  polls?: Poll[];
}) {
  const [list, setList] = useState(initial);
  const [filter, setFilter] = useState("all");
  const [query, setQuery] = useState("");
  const [detail, setDetail] = useState<Listing | null>(null);
  const { toast, node } = useToast();

  const filtered = useMemo(() => {
    let out = list;
    if (filter === "satilik" || filter === "kiralik")
      out = out.filter((l) => l.type === filter);
    if (filter === "satildi" || filter === "kiralandi")
      out = out.filter((l) => l.status === filter);
    const q = query.trim().toLocaleLowerCase("tr");
    if (q)
      out = out.filter(
        (l) =>
          l.title.toLocaleLowerCase("tr").includes(q) ||
          l.district.toLocaleLowerCase("tr").includes(q) ||
          l.rooms.toLocaleLowerCase("tr").includes(q)
      );
    return out;
  }, [list, filter, query]);

  function openDetail(l: Listing) {
    setDetail(l);
    try {
      const arr: number[] = JSON.parse(
        sessionStorage.getItem("ss_lviewed") || "[]"
      );
      if (!arr.includes(l.id)) {
        arr.push(l.id);
        sessionStorage.setItem("ss_lviewed", JSON.stringify(arr));
        fetch(`/api/listings/${l.id}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ action: "view" }),
        }).catch(() => {});
        setList((ls) =>
          ls.map((x) => (x.id === l.id ? { ...x, views: x.views + 1 } : x))
        );
      }
    } catch {
      // yoksay
    }
  }

  async function patchListing(id: number, payload: Record<string, unknown>) {
    const r = await fetch(`/api/listings/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (r.ok) {
      const j = await r.json();
      setList((ls) => ls.map((x) => (x.id === id ? j.listing : x)));
      setDetail((d) => (d && d.id === id ? j.listing : d));
      return true;
    }
    return false;
  }

  async function deleteListing(id: number) {
    if (!confirm("Bu ilan kalıcı olarak silinsin mi?")) return;
    const r = await fetch(`/api/listings/${id}`, { method: "DELETE" });
    if (r.ok) {
      setList((ls) => ls.filter((x) => x.id !== id));
      setDetail(null);
      toast("İlan silindi");
    }
  }

  const activeCount = list.filter((l) => l.status === "aktif").length;
  const phone = detail?.phone || owner.whatsapp;

  return (
    <div className="flex flex-col gap-5 px-4 pt-4">
      {node}

      {/* Danışman kartı */}
      <section
        className="overflow-hidden border border-[var(--line)] bg-[var(--card)] p-5"
        style={{ borderRadius: "var(--radius)" }}
        aria-label="Emlak danışmanı"
      >
        <div className="flex items-center gap-3.5">
          <span className="ring-gradient rounded-full p-[3px]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={owner.avatar}
              alt={owner.name}
              className="h-16 w-16 rounded-full border-[3px] border-[var(--card)] object-cover"
            />
          </span>
          <div className="min-w-0">
            <h1 className="flex items-center gap-1.5 text-[17px] font-extrabold tracking-tight">
              {owner.name} Emlak
              {owner.verified && <VerifiedBadge size={17} />}
            </h1>
            <p className="text-[12px] font-semibold text-[var(--muted)]">
              Elbistan&apos;ın güvenilir emlak danışmanı · {activeCount} aktif
              ilan
            </p>
          </div>
        </div>
        <div className="mt-4 grid grid-cols-3 gap-2">
          <a
            href={waLink(
              owner.whatsapp,
              "Merhaba, emlak ilanlarınız hakkında bilgi almak istiyorum."
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 rounded-xl bg-[#25D366] px-2 py-2.5 text-[12px] font-extrabold text-white shadow-sm transition hover:opacity-90 active:scale-[.98]"
          >
            <MessageCircle size={15} /> WhatsApp
          </a>
          <a
            href={owner.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 rounded-xl border border-[var(--line)] bg-[var(--bg)] px-2 py-2.5 text-[12px] font-extrabold transition hover:border-[var(--accent)] hover:text-[var(--accent)] active:scale-[.98]"
          >
            <InstagramIcon size={15} /> Instagram
          </a>
          <a
            href={waLink(
              owner.whatsapp,
              "Merhaba, Sohbet Sokağı üzerinden reklam ve iş birliği için ulaşıyorum."
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-1.5 rounded-xl bg-[var(--accent)] px-2 py-2.5 text-[12px] font-extrabold text-[var(--accent-ink)] shadow-sm transition hover:opacity-90 active:scale-[.98]"
          >
            <Megaphone size={15} /> Reklam
          </a>
        </div>
      </section>

      {/* Emlak bannerları */}
      {banners.map((b) => (
        <a
          key={b.id}
          href={b.linkUrl || "#"}
          target={/^https?:/.test(b.linkUrl) ? "_blank" : undefined}
          rel="noopener noreferrer"
          className="group relative block h-36 overflow-hidden border border-[var(--line)]"
          style={{ borderRadius: "var(--radius)" }}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={b.imageUrl}
            alt={b.title}
            loading="lazy"
            className="h-full w-full object-cover transition duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/65 to-transparent" />
          <p className="absolute bottom-3 left-4 right-4 text-[14px] font-extrabold text-white drop-shadow">
            {b.title}
          </p>
        </a>
      ))}

      {polls.map((p) => (
        <PollCard key={p.id} poll={p} />
      ))}

      {/* Arama + filtreler */}
      <div className="sticky top-[60px] z-30 -mx-4 space-y-2.5 bg-[var(--bg)]/90 px-4 py-3 backdrop-blur-xl">
        <div className="relative">
          <Search
            size={16}
            className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-[var(--muted)]"
          />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Mahalle, oda sayısı veya başlık ara..."
            className="w-full rounded-full border border-[var(--line)] bg-[var(--card)] py-2.5 pl-10 pr-4 text-[13px] font-semibold placeholder:font-medium placeholder:text-[var(--muted)]/70 focus:border-[var(--accent)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)]/25"
          />
        </div>
        <div className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-0.5">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              onClick={() => setFilter(f.id)}
              className={`shrink-0 rounded-full px-4 py-2 text-[12px] font-extrabold transition active:scale-95 ${
                filter === f.id
                  ? "bg-[var(--ink)] text-[var(--bg)] shadow"
                  : "border border-[var(--line)] bg-[var(--card)] text-[var(--muted)] hover:text-[var(--ink)]"
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* İlan listesi */}
      <section className="grid grid-cols-1 gap-4 sm:grid-cols-2" aria-label="Emlak ilanları">
        {filtered.map((l) => (
          <article
            key={l.id}
            onClick={() => openDetail(l)}
            className="group cursor-pointer overflow-hidden border border-[var(--line)] bg-[var(--card)] shadow-[0_1px_2px_rgba(30,20,10,0.04)] transition hover:-translate-y-0.5 hover:shadow-lg"
            style={{ borderRadius: "var(--radius)" }}
          >
            <div className="relative">
              <Carousel images={l.images} title={l.title} h="h-52" />
              <div className="pointer-events-none absolute left-2.5 top-2.5 flex gap-1.5">
                <TypeBadge type={l.type} />
                <StatusBadge status={l.status} />
              </div>
              {l.pinned && (
                <span className="absolute right-2.5 top-2.5 rounded-full bg-[var(--accent)] p-1.5 text-[var(--accent-ink)] shadow">
                  <Pin size={12} className="fill-current" />
                </span>
              )}
            </div>
            <div className="p-4">
              <div className="flex items-baseline justify-between gap-2">
                <p className="text-[17px] font-extrabold tracking-tight text-[var(--accent)]">
                  {formatPrice(l.price, l.type)}
                </p>
                <span className="flex items-center gap-1 text-[10.5px] font-bold text-[var(--muted)]">
                  <Eye size={12} /> {formatCount(l.views)}
                </span>
              </div>
              <h2 className="mt-0.5 line-clamp-1 text-[13.5px] font-extrabold tracking-tight">
                {l.title}
              </h2>
              <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] font-bold text-[var(--muted)]">
                {l.rooms && (
                  <span className="flex items-center gap-1">
                    <BedDouble size={13} /> {l.rooms}
                  </span>
                )}
                {l.area > 0 && (
                  <span className="flex items-center gap-1">
                    <Ruler size={13} /> {l.area} m²
                  </span>
                )}
                {l.district && (
                  <span className="flex items-center gap-1">
                    <MapPin size={13} /> {l.district}
                  </span>
                )}
              </div>
              <p className="mt-2.5 border-t border-[var(--line)] pt-2 text-[10.5px] font-semibold text-[var(--muted)]">
                {timeAgo(l.createdAt)} · İlan №{l.id}
              </p>
            </div>
          </article>
        ))}
      </section>
      {filtered.length === 0 && (
        <p className="py-14 text-center text-sm font-semibold text-[var(--muted)]">
          Bu kriterlere uygun ilan bulunamadı.
        </p>
      )}

      {/* Detay modalı */}
      {detail && (
        <DetailModal
          listing={detail}
          ownerPhone={owner.whatsapp}
          canManage={canManage}
          phone={phone}
          onClose={() => setDetail(null)}
          onStatus={(s) => {
            patchListing(detail.id, { status: s }).then((ok) =>
              toast(ok ? "İlan durumu güncellendi" : "İşlem başarısız")
            );
          }}
          onPin={() => {
            patchListing(detail.id, { pinned: !detail.pinned }).then((ok) =>
              toast(ok ? (detail.pinned ? "Sabitleme kaldırıldı" : "Üste sabitlendi") : "İşlem başarısız")
            );
          }}
          onDelete={() => deleteListing(detail.id)}
        />
      )}
    </div>
  );
}

function DetailModal({
  listing: l,
  ownerPhone,
  phone,
  canManage,
  onClose,
  onStatus,
  onPin,
  onDelete,
}: {
  listing: Listing;
  ownerPhone: string;
  phone: string;
  canManage: boolean;
  onClose: () => void;
  onStatus: (s: string) => void;
  onPin: () => void;
  onDelete: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[90] flex items-end justify-center sm:items-center sm:p-4">
      <div
        className="animate-fade-in absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      <div
        className="animate-sheet-up no-scrollbar relative max-h-[94dvh] w-full overflow-y-auto rounded-t-3xl border border-[var(--line)] bg-[var(--card)] shadow-2xl sm:max-w-xl sm:rounded-3xl"
      >
        <div className="relative">
          <Carousel images={l.images} title={l.title} h="h-64 sm:h-72" />
          <div className="pointer-events-none absolute left-3 top-3 flex gap-1.5">
            <TypeBadge type={l.type} />
            <StatusBadge status={l.status} />
          </div>
          <button
            onClick={onClose}
            className="absolute right-3 top-3 rounded-full bg-black/50 p-2 text-white backdrop-blur transition hover:bg-black/70"
            aria-label="Kapat"
          >
            <X size={16} />
          </button>
        </div>
        <div className="p-5">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-2xl font-extrabold tracking-tight text-[var(--accent)]">
                {formatPrice(l.price, l.type)}
              </p>
              <h3 className="mt-1 text-[16px] font-extrabold tracking-tight">
                {l.title}
              </h3>
              <p className="mt-0.5 flex items-center gap-1 text-[12px] font-bold text-[var(--muted)]">
                <MapPin size={13} /> {l.district ? l.district + " · " : ""}
                Elbistan / Kahramanmaraş
              </p>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-4">
            {[
              { icon: BedDouble, label: "Oda", value: l.rooms || "—" },
              { icon: Ruler, label: "Brüt", value: l.area ? `${l.area} m²` : "—" },
              { icon: Layers, label: "Kat", value: l.floor || "—" },
              { icon: Flame, label: "Isıtma", value: l.heating || "—" },
              { icon: Tag, label: "Durum", value: STATUS_LABEL[l.status] },
              { icon: Eye, label: "Görüntülenme", value: formatCount(l.views) },
              { icon: Bath, label: "İlan No", value: `#${l.id}` },
              { icon: KeyRound, label: "Tarih", value: fullDate(l.createdAt) },
            ].map((s, i) => (
              <div
                key={i}
                className="rounded-xl border border-[var(--line)] bg-[var(--bg)] p-2.5"
              >
                <s.icon size={14} className="text-[var(--accent)]" />
                <p className="mt-1 text-[9.5px] font-extrabold uppercase tracking-wide text-[var(--muted)]">
                  {s.label}
                </p>
                <p className="truncate text-[11.5px] font-extrabold">{s.value}</p>
              </div>
            ))}
          </div>

          {l.description && (
            <p className="mt-4 whitespace-pre-line text-[13.5px] leading-relaxed text-[var(--ink)]/85">
              {l.description}
            </p>
          )}

          <div className="mt-5 flex gap-2">
            <a
              href={waLink(
                phone || ownerPhone,
                `Merhaba, "${l.title}" (İlan №${l.id}) hakkında bilgi almak istiyorum.`
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-[#25D366] px-4 py-3 text-[13.5px] font-extrabold text-white shadow transition hover:opacity-90 active:scale-[.98]"
            >
              <MessageCircle size={17} /> WhatsApp&apos;tan Sor
            </a>
            <a
              href={`tel:+${(phone || ownerPhone).replace(/[^\d]/g, "")}`}
              className="flex items-center justify-center gap-2 rounded-xl border border-[var(--line)] bg-[var(--bg)] px-4 py-3 text-[13.5px] font-extrabold transition hover:border-[var(--accent)] hover:text-[var(--accent)] active:scale-[.98]"
            >
              <Phone size={17} /> Ara
            </a>
          </div>

          {canManage && (
            <div className="mt-5 rounded-2xl border border-dashed border-[var(--accent)]/50 bg-[var(--accent)]/5 p-4">
              <p className="text-[11px] font-extrabold uppercase tracking-wide text-[var(--accent)]">
                Yönetici İşlemleri
              </p>
              <div className="mt-2.5 flex flex-wrap gap-2">
                {(["aktif", "satildi", "kiralandi"] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => onStatus(s)}
                    className={`rounded-full px-3.5 py-2 text-[11.5px] font-extrabold transition active:scale-95 ${
                      l.status === s
                        ? "bg-[var(--ink)] text-[var(--bg)]"
                        : "border border-[var(--line)] bg-[var(--card)] text-[var(--muted)] hover:text-[var(--ink)]"
                    }`}
                  >
                    {STATUS_LABEL[s]}
                  </button>
                ))}
                <button
                  onClick={onPin}
                  className="flex items-center gap-1 rounded-full border border-[var(--line)] bg-[var(--card)] px-3.5 py-2 text-[11.5px] font-extrabold text-[var(--muted)] transition hover:text-[var(--ink)] active:scale-95"
                >
                  <Pin size={12} /> {l.pinned ? "Sabitlemeyi Kaldır" : "Üste Sabitle"}
                </button>
                <button
                  onClick={onDelete}
                  className="flex items-center gap-1 rounded-full border border-rose-500/30 bg-rose-500/10 px-3.5 py-2 text-[11.5px] font-extrabold text-rose-500 transition hover:bg-rose-500/20 active:scale-95"
                >
                  <Trash2 size={12} /> İlanı Sil
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
