"use client";

import Link from "next/link";
import { Building2 } from "lucide-react";
import PushBell from "./PushBell";
import ModeToggle from "./ModeToggle";

export default function Header({
  siteName,
  tagline,
  logoUrl,
  darkEnabled = true,
}: {
  siteName: string;
  tagline: string;
  logoUrl: string;
  darkEnabled?: boolean;
}) {
  return (
    <header className="sticky top-0 z-40 border-b border-[var(--line)] bg-[var(--bg)]/85 backdrop-blur-xl">
      <div className="mx-auto flex h-[60px] max-w-[520px] items-center justify-between gap-3 px-4">
        <Link
          href="/"
          className="flex min-w-0 items-center gap-2.5"
          aria-label={siteName + " ana sayfa"}
        >
          {logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={logoUrl}
              alt={siteName}
              className="h-10 w-10 rounded-xl object-cover shadow-sm"
            />
          ) : (
            <div className="ring-gradient flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-[13px] font-extrabold tracking-tight text-white shadow-md">
              SS
            </div>
          )}
          <div className="min-w-0">
            <div className="truncate text-[16px] font-extrabold leading-tight tracking-tight">
              {siteName}
            </div>
            <div className="-mt-0.5 truncate text-[10.5px] font-medium text-[var(--muted)]">
              {tagline}
            </div>
          </div>
        </Link>
        <div className="flex shrink-0 items-center gap-2">
          {darkEnabled && <ModeToggle />}
          <PushBell />
          <Link
            href="/emlak"
            className="flex items-center gap-1.5 rounded-full bg-[var(--accent)] px-3.5 py-2 text-[12px] font-extrabold text-[var(--accent-ink)] shadow-md transition hover:opacity-90 active:scale-95"
          >
            <Building2 size={15} />
            <span className="hidden sm:inline">Sohbet Sokağı</span> Emlak
          </Link>
        </div>
      </div>
    </header>
  );
}
