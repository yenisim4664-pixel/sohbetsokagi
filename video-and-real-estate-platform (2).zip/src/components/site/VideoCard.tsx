"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import type { OwnerProfile, VideoPost } from "@/lib/types";
import { formatCount, fullDateTime, timeAgo } from "@/lib/types";
import {
  Eye,
  Heart,
  MessageCircleOff,
  MoreVertical,
  Pause,
  Pencil,
  Pin,
  PinOff,
  Play,
  Share2,
  Trash2,
  Volume2,
  VolumeX,
} from "lucide-react";
import {
  Field,
  GhostBtn,
  Modal,
  PrimaryBtn,
  TextArea,
  TextInput,
  Toggle,
  Uploader,
  VerifiedBadge,
  useToast,
} from "./ui";

export default function VideoCard({
  post,
  owner,
  canManage,
  onUpdated,
  onDeleted,
}: {
  post: VideoPost;
  owner: OwnerProfile;
  canManage: boolean;
  onUpdated?: (p: VideoPost) => void;
  onDeleted?: (id: number) => void;
}) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const wrapRef = useRef<HTMLDivElement>(null);
  const clickTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const viewTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const intersecting = useRef(false);
  const viewCounted = useRef(false);

  const [near, setNear] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(true);
  const [progress, setProgress] = useState(0);
  const [expanded, setExpanded] = useState(false);
  const [liked, setLiked] = useState(false);
  const [likeCount, setLikeCount] = useState(post.likes);
  const [viewCount, setViewCount] = useState(post.views);
  const [burst, setBurst] = useState(0);
  const [flash, setFlash] = useState<"play" | "pause" | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    title: post.title,
    description: post.description,
    videoUrl: post.videoUrl,
    posterUrl: post.posterUrl,
    pinned: post.pinned,
  });
  const { toast, node } = useToast();

  // Beğeni durumunu yerel depolamadan yükle
  useEffect(() => {
    try {
      const arr = JSON.parse(localStorage.getItem("ss_liked") || "[]");
      setLiked(arr.includes(post.id));
    } catch {
      setLiked(false);
    }
  }, [post.id]);

  // Yakınlık gözlemcisi: uzaktaki videoları bellekten boşalt (sanal kaydırma)
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        const e = entries[0];
        if (e.isIntersecting) {
          setNear(true);
        } else {
          setNear(false);
          const v = videoRef.current;
          if (v) {
            v.pause();
            setPlaying(false);
          }
        }
      },
      { rootMargin: "800px 0px", threshold: 0 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  // Kaynak bağlama (HLS veya MP4) — sadece görünüm alanına yaklaşınca
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !near) return;
    let cancelled = false;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let hls: any = null;
    const url = post.videoUrl;
    async function attach() {
      if (!video) return;
      if (url.includes(".m3u8")) {
        if (video.canPlayType("application/vnd.apple.mpegurl")) {
          video.src = url;
        } else {
          try {
            const mod = await import("hls.js");
            if (cancelled) return;
            const Hls = mod.default;
            if (Hls.isSupported()) {
              hls = new Hls({
                maxBufferLength: 12,
                maxMaxBufferLength: 30,
                backBufferLength: 6,
                startLevel: -1,
                capLevelToPlayerSize: true,
                enableWorker: true,
              });
              hls.loadSource(url);
              hls.attachMedia(video);
            }
          } catch {
            video.src = url;
          }
        }
      } else {
        video.src = url;
      }
    }
    attach();
    return () => {
      cancelled = true;
      if (hls) hls.destroy();
      if (video) {
        video.pause();
        video.removeAttribute("src");
        video.load();
      }
    };
  }, [near, post.videoUrl]);

  // Görünürlük gözlemcisi: %55 görünürken otomatik oynat, çıkınca durdur
  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        const e = entries[0];
        intersecting.current = e.isIntersecting && e.intersectionRatio >= 0.55;
        const v = videoRef.current;
        if (!v) return;
        if (intersecting.current) {
          v.muted = muted;
          v.play()
            .then(() => setPlaying(true))
            .catch(() => {
              v.muted = true;
              setMuted(true);
              v.play()
                .then(() => setPlaying(true))
                .catch(() => setPlaying(false));
            });
          // Görüntülenme sayacı: 1.8 sn izlendiyse + session başına bir kez
          if (viewTimer.current) clearTimeout(viewTimer.current);
          viewTimer.current = setTimeout(() => {
            if (!intersecting.current || viewCounted.current) return;
            try {
              const key = "ss_viewed";
              const arr: number[] = JSON.parse(
                sessionStorage.getItem(key) || "[]"
              );
              if (arr.includes(post.id)) {
                viewCounted.current = true;
                return;
              }
              arr.push(post.id);
              sessionStorage.setItem(key, JSON.stringify(arr));
            } catch {
              // yoksay
            }
            viewCounted.current = true;
            setViewCount((c) => c + 1);
            fetch(`/api/videos/${post.id}/engage`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ kind: "view" }),
            }).catch(() => {});
          }, 1800);
        } else {
          v.pause();
          setPlaying(false);
          if (viewTimer.current) clearTimeout(viewTimer.current);
        }
      },
      { threshold: [0, 0.55, 1] }
    );
    obs.observe(el);
    return () => {
      obs.disconnect();
      if (viewTimer.current) clearTimeout(viewTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [post.id, near]);

  useEffect(() => {
    if (videoRef.current) videoRef.current.muted = muted;
  }, [muted]);

  function togglePlay() {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) {
      v.play()
        .then(() => setPlaying(true))
        .catch(() => {});
      setFlash("play");
    } else {
      v.pause();
      setPlaying(false);
      setFlash("pause");
    }
    setTimeout(() => setFlash(null), 650);
  }

  function handleTap() {
    if (clickTimer.current) {
      clearTimeout(clickTimer.current);
      clickTimer.current = null;
      handleDoubleTap();
    } else {
      clickTimer.current = setTimeout(() => {
        togglePlay();
        clickTimer.current = null;
      }, 260);
    }
  }

  function handleDoubleTap() {
    setBurst((b) => b + 1);
    if (!liked) doLike();
  }

  async function doLike() {
    try {
      const r = await fetch(`/api/videos/${post.id}/engage`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ kind: "like" }),
      });
      const j = await r.json();
      if (r.ok) {
        setLiked(j.liked);
        setLikeCount(j.likes);
        try {
          const arr: number[] = JSON.parse(
            localStorage.getItem("ss_liked") || "[]"
          );
          const next = j.liked
            ? [...new Set([...arr, post.id])]
            : arr.filter((x) => x !== post.id);
          localStorage.setItem("ss_liked", JSON.stringify(next));
        } catch {
          // yoksay
        }
      }
    } catch {
      toast("Bağlantı hatası");
    }
  }

  async function share() {
    const url = `${location.origin}/#v${post.id}`;
    const data = {
      title: owner.name,
      text: post.title || "Sohbet Sokağı'nda bu videoyu izle",
      url,
    };
    if (navigator.share) {
      try {
        await navigator.share(data);
      } catch {
        // iptal edildi
      }
    } else {
      try {
        await navigator.clipboard.writeText(url);
        toast("Bağlantı kopyalandı");
      } catch {
        toast("Kopyalanamadı");
      }
    }
  }

  async function patch(payload: Record<string, unknown>) {
    const r = await fetch(`/api/videos/${post.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (r.ok) {
      const j = await r.json();
      onUpdated?.(j.video);
    }
    return r.ok;
  }

  async function saveEdit() {
    setSaving(true);
    const ok = await patch(form);
    setSaving(false);
    if (ok) {
      setEditOpen(false);
      toast("Video güncellendi");
    } else toast("Güncelleme başarısız");
  }

  async function remove() {
    if (!confirm("Bu video kalıcı olarak silinsin mi?")) return;
    const r = await fetch(`/api/videos/${post.id}`, { method: "DELETE" });
    if (r.ok) {
      onDeleted?.(post.id);
      toast("Video silindi");
    }
  }

  return (
    <article
      id={`v${post.id}`}
      className="animate-fade-up overflow-hidden border border-[var(--line)] bg-[var(--card)] shadow-[0_1px_2px_rgba(30,20,10,0.04)]"
      style={{ borderRadius: "var(--radius)" }}
    >
      {node}
      {/* Başlık: sahip profili + mavi tik + Profili Gör */}
      <header className="flex items-center gap-3 px-4 py-3">
        <Link href="/profil" className="flex min-w-0 items-center gap-2.5">
          <span className="ring-gradient rounded-full p-[2px]">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={owner.avatar}
              alt={owner.name}
              className="h-9 w-9 rounded-full border-2 border-[var(--card)] object-cover"
            />
          </span>
          <span className="min-w-0">
            <span className="flex items-center gap-1">
              <span className="truncate text-[13.5px] font-extrabold tracking-tight">
                {owner.username}
              </span>
              {owner.verified && <VerifiedBadge size={15} />}
              {post.pinned && (
                <span className="ml-1 inline-flex items-center gap-0.5 rounded-full bg-[var(--accent)]/10 px-1.5 py-0.5 text-[9.5px] font-extrabold text-[var(--accent)]">
                  <Pin size={9} /> SABİTLENDİ
                </span>
              )}
            </span>
            <span className="block truncate text-[11px] text-[var(--muted)]">
              {timeAgo(post.createdAt)} · Elbistan
            </span>
          </span>
        </Link>
        <div className="ml-auto flex shrink-0 items-center gap-1.5">
          <Link
            href="/profil"
            className="rounded-full border border-[var(--line)] bg-[var(--bg)] px-3 py-1.5 text-[11px] font-extrabold text-[var(--ink)] transition hover:border-[var(--accent)] hover:text-[var(--accent)]"
          >
            Profili Gör
          </Link>
          {canManage && (
            <div className="relative">
              <button
                onClick={() => setMenuOpen((o) => !o)}
                className="rounded-full p-1.5 text-[var(--muted)] transition hover:bg-[var(--bg)] hover:text-[var(--ink)]"
                aria-label="Video seçenekleri"
              >
                <MoreVertical size={17} />
              </button>
              {menuOpen && (
                <>
                  <div
                    className="fixed inset-0 z-20"
                    onClick={() => setMenuOpen(false)}
                  />
                  <div className="animate-scale-in absolute right-0 top-9 z-30 w-48 overflow-hidden rounded-2xl border border-[var(--line)] bg-[var(--card)] py-1.5 shadow-xl">
                    <button
                      onClick={async () => {
                        setMenuOpen(false);
                        const ok = await patch({ pinned: !post.pinned });
                        toast(
                          ok
                            ? post.pinned
                              ? "Sabitleme kaldırıldı"
                              : "Video üste sabitlendi"
                            : "İşlem başarısız"
                        );
                      }}
                      className="flex w-full items-center gap-2.5 px-4 py-2.5 text-left text-[13px] font-semibold hover:bg-[var(--bg)]"
                    >
                      {post.pinned ? <PinOff size={15} /> : <Pin size={15} />}
                      {post.pinned ? "Sabitlemeyi Kaldır" : "Üste Sabitle"}
                    </button>
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        setEditOpen(true);
                      }}
                      className="flex w-full items-center gap-2.5 px-4 py-2.5 text-left text-[13px] font-semibold hover:bg-[var(--bg)]"
                    >
                      <Pencil size={15} /> Düzenle
                    </button>
                    <button
                      onClick={() => {
                        setMenuOpen(false);
                        remove();
                      }}
                      className="flex w-full items-center gap-2.5 px-4 py-2.5 text-left text-[13px] font-semibold text-rose-500 hover:bg-rose-500/10"
                    >
                      <Trash2 size={15} /> Sil
                    </button>
                  </div>
                </>
              )}
            </div>
          )}
        </div>
      </header>

      {/* Medya alanı */}
      <div
        ref={wrapRef}
        className="relative aspect-[4/5] max-h-[74vh] w-full cursor-pointer select-none overflow-hidden bg-black"
        onClick={handleTap}
        onDoubleClick={(e) => e.preventDefault()}
      >
        <video
          ref={videoRef}
          className="video-ease h-full w-full object-cover"
          poster={post.posterUrl || undefined}
          playsInline
          loop
          muted={muted}
          preload="metadata"
          onTimeUpdate={(e) => {
            const v = e.currentTarget;
            if (v.duration > 0)
              setProgress((v.currentTime / v.duration) * 100);
          }}
        />
        {/* Çift dokun kalp animasyonu */}
        {burst > 0 && (
          <div
            key={burst}
            className="pointer-events-none absolute inset-0 flex items-center justify-center"
          >
            <Heart
              size={110}
              className="animate-heart-pop fill-white text-white drop-shadow-2xl"
            />
          </div>
        )}
        {flash && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <span className="animate-flash rounded-full bg-black/45 p-5 text-white">
              {flash === "play" ? (
                <Play size={36} className="fill-white" />
              ) : (
                <Pause size={36} className="fill-white" />
              )}
            </span>
          </div>
        )}
        {/* İlerleme çubuğu */}
        <div className="absolute inset-x-0 bottom-0 h-[3px] bg-white/20">
          <div
            className="h-full bg-[var(--accent)] transition-[width] duration-150"
            style={{ width: `${progress}%` }}
          />
        </div>
        {/* Ses düğmesi */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            setMuted((m) => !m);
          }}
          className="absolute bottom-4 right-3 rounded-full bg-black/50 p-2.5 text-white backdrop-blur transition hover:bg-black/70 active:scale-90"
          aria-label={muted ? "Sesi aç" : "Sesi kapat"}
        >
          {muted ? <VolumeX size={16} /> : <Volume2 size={16} />}
        </button>
        {!playing && !flash && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <span className="rounded-full bg-black/35 p-4 text-white/95 backdrop-blur-sm">
              <Play size={30} className="fill-current" />
            </span>
          </div>
        )}
      </div>

      {/* Etkileşim satırı */}
      <div className="flex items-center gap-1 px-3 pt-2.5">
        <button
          onClick={doLike}
          className="group flex items-center gap-1.5 rounded-full px-2 py-1.5 transition active:scale-90"
          aria-label={liked ? "Beğenmekten vazgeç" : "Beğen"}
        >
          <Heart
            size={23}
            className={`transition ${
              liked
                ? "fill-[var(--accent)] text-[var(--accent)]"
                : "text-[var(--ink)] group-hover:text-[var(--accent)]"
            }`}
          />
          <span className="text-[13px] font-extrabold">
            {formatCount(likeCount)}
          </span>
        </button>
        <span className="flex items-center gap-1.5 rounded-full px-2 py-1.5 text-[var(--muted)]">
          <Eye size={21} />
          <span className="text-[13px] font-bold">
            {formatCount(viewCount)}
          </span>
        </span>
        <button
          onClick={share}
          className="rounded-full px-2 py-1.5 text-[var(--ink)] transition hover:text-[var(--accent)] active:scale-90"
          aria-label="Paylaş"
        >
          <Share2 size={21} />
        </button>
        <span className="ml-auto pr-1 text-[11px] font-semibold text-[var(--muted)]">
          {fullDateTime(post.createdAt)}
        </span>
      </div>

      {/* Açıklama */}
      {(post.title || post.description) && (
        <div className="px-4 pb-1.5 pt-1">
          {post.title && (
            <h2 className="text-[14px] font-extrabold tracking-tight">
              {post.title}
            </h2>
          )}
          {post.description && (
            <p
              className={`mt-0.5 whitespace-pre-line text-[13px] leading-relaxed text-[var(--ink)]/80 ${
                expanded ? "" : "line-clamp-2"
              }`}
              onClick={() => setExpanded((e) => !e)}
            >
              {post.description}
            </p>
          )}
        </div>
      )}

      {/* Yorumlar kapalı bilgisi */}
      <div className="flex items-center gap-1.5 px-4 pb-3.5 pt-1 text-[11.5px] font-semibold text-[var(--muted)]">
        <MessageCircleOff size={13} />
        Yorumlar bu platformda kapalıdır
      </div>

      {/* Düzenleme modalı */}
      <Modal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        title="Videoyu Düzenle"
      >
        <div className="space-y-3.5">
          <Field label="Başlık">
            <TextInput
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="Video başlığı"
            />
          </Field>
          <Field label="Açıklama">
            <TextArea
              value={form.description}
              onChange={(e) =>
                setForm({ ...form, description: e.target.value })
              }
              placeholder="Video açıklaması"
            />
          </Field>
          <Field label="Video URL (mp4 veya .m3u8 HLS)">
            <TextInput
              value={form.videoUrl}
              onChange={(e) => setForm({ ...form, videoUrl: e.target.value })}
            />
          </Field>
          <Uploader
            accept="video/mp4,video/webm,video/quicktime"
            onUploaded={(files) => {
              if (files[0])
                setForm((f) => ({
                  ...f,
                  videoUrl: files[0].url,
                  posterUrl: files[0].posterUrl || f.posterUrl,
                }));
            }}
          >
            Yeni video dosyası yükle (ffmpeg ile kapak otomatik)
          </Uploader>
          <Field label="Kapak görseli URL">
            <TextInput
              value={form.posterUrl}
              onChange={(e) => setForm({ ...form, posterUrl: e.target.value })}
            />
          </Field>
          <Toggle
            checked={form.pinned}
            onChange={(v) => setForm({ ...form, pinned: v })}
            label="Üste sabitle"
          />
          <div className="flex gap-2 pt-1">
            <GhostBtn className="flex-1" onClick={() => setEditOpen(false)}>
              Vazgeç
            </GhostBtn>
            <PrimaryBtn className="flex-1" onClick={saveEdit} disabled={saving}>
              {saving ? "Kaydediliyor..." : "Kaydet"}
            </PrimaryBtn>
          </div>
        </div>
      </Modal>
    </article>
  );
}
