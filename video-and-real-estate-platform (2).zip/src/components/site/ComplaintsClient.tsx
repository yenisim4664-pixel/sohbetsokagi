"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { Complaint, Poll, WatermarkConfig } from "@/lib/types";
import { COMPLAINT_STATUS_LABEL, formatCount, timeAgo } from "@/lib/types";
import {
  AlertCircle,
  CheckCircle2,
  Clock3,
  Eye,
  ImagePlus,
  MapPin,
  MegaphoneOff,
  Pencil,
  Pin,
  Send,
  ShieldCheck,
  Trash2,
  UserRound,
  XCircle,
} from "lucide-react";
import {
  Field,
  GhostBtn,
  Modal,
  PrimaryBtn,
  Select,
  Spinner,
  TextArea,
  TextInput,
  useToast,
} from "./ui";
import Watermark from "./Watermark";
import PollCard from "./PollCard";
import { DISTRICTS } from "@/lib/types";

const STATUS_STYLE: Record<string, string> = {
  beklemede: "bg-amber-500/15 text-amber-600",
  onaylandi: "bg-emerald-500/15 text-emerald-600",
  reddedildi: "bg-rose-500/15 text-rose-500",
};

function MediaBox({
  item,
  wm,
}: {
  item: { mediaUrl: string; mediaType: string; posterUrl?: string };
  wm: WatermarkConfig;
}) {
  if (!item.mediaUrl) return null;
  return (
    <div className="relative aspect-[4/3] w-full overflow-hidden bg-black">
      {item.mediaType === "video" ? (
        <video
          src={item.mediaUrl}
          poster={item.posterUrl || undefined}
          className="h-full w-full object-cover"
          controls
          playsInline
          preload="metadata"
        />
      ) : (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={item.mediaUrl}
          alt="Şikayet görseli"
          loading="lazy"
          className="h-full w-full object-cover"
        />
      )}
      <Watermark wm={wm} />
    </div>
  );
}

export default function ComplaintsClient({
  initial,
  watermark,
  canManage,
  intro,
  polls,
}: {
  initial: Complaint[];
  watermark: WatermarkConfig;
  canManage: boolean;
  intro: string;
  polls: Poll[];
}) {
  const [list, setList] = useState(initial);
  const [mine, setMine] = useState<Complaint[]>([]);
  const [open, setOpen] = useState(false);
  const [sent, setSent] = useState<{ ticket: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [preview, setPreview] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const { toast, node } = useToast();

  const [form, setForm] = useState({
    name: "",
    district: DISTRICTS[0],
    title: "",
    body: "",
    mediaUrl: "",
    mediaType: "image" as "image" | "video",
    posterUrl: "",
  });

  const loadMine = useCallback(async () => {
    try {
      const r = await fetch("/api/complaints?scope=mine");
      const j = await r.json();
      if (r.ok) setMine(j.complaints || []);
    } catch {
      // yoksay
    }
  }, []);

  useEffect(() => {
    loadMine();
  }, [loadMine]);

  async function upload(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    setUploading(true);
    const fd = new FormData();
    fd.append("file", f);
    try {
      const r = await fetch("/api/complaints/upload", { method: "POST", body: fd });
      const j = await r.json();
      if (r.ok && j.url) {
        setForm((s) => ({
          ...s,
          mediaUrl: j.url,
          mediaType: j.mediaType === "video" ? "video" : "image",
          posterUrl: j.posterUrl || "",
        }));
        toast("Medya yüklendi");
      } else toast(j.error || "Yükleme başarısız");
    } catch {
      toast("Yükleme başarısız");
    }
    setUploading(false);
    if (fileRef.current) fileRef.current.value = "";
  }

  async function submit() {
    if (form.body.trim().length < 15)
      return toast("Şikayet metni en az 15 karakter olmalı");
    setBusy(true);
    try {
      const r = await fetch("/api/complaints", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const j = await r.json();
      if (r.ok) {
        setOpen(false);
        setPreview(false);
        setSent({ ticket: j.ticket });
        setForm({
          name: "",
          district: DISTRICTS[0],
          title: "",
          body: "",
          mediaUrl: "",
          mediaType: "image",
          posterUrl: "",
        });
        loadMine();
      } else toast(j.error || "Gönderilemedi");
    } catch {
      toast("Bağlantı hatası");
    }
    setBusy(false);
  }

  async function patch(id: number, payload: Record<string, unknown>) {
    const r = await fetch(`/api/complaints/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (r.ok) {
      const j = await r.json();
      setList((ls) =>
        j.complaint.status === "onaylandi"
          ? ls.map((x) => (x.id === id ? j.complaint : x))
          : ls.filter((x) => x.id !== id)
      );
      toast("Güncellendi");
    } else toast("İşlem başarısız");
  }

  async function remove(id: number) {
    if (!confirm("Bu şikayet kalıcı olarak silinsin mi?")) return;
    const r = await fetch(`/api/complaints/${id}`, { method: "DELETE" });
    if (r.ok) {
      setList((ls) => ls.filter((x) => x.id !== id));
      toast("Silindi");
    }
  }

  const topPolls = polls.filter((p) => p.position === "sikayet-top");

  return (
    <div className="flex flex-col gap-5 px-4 pt-4">
      {node}

      {/* Başlık + gönder butonu */}
      <section
        className="border p-5"
        style={{
          borderColor: "var(--line)",
          background: "var(--card)",
          borderRadius: "var(--radius)",
        }}
      >
        <h1 className="flex items-center gap-2 text-[17px] font-extrabold tracking-tight">
          <span
            className="flex h-8 w-8 items-center justify-center rounded-xl"
            style={{
              background: "color-mix(in srgb, var(--accent) 12%, transparent)",
              color: "var(--accent)",
            }}
          >
            <AlertCircle size={17} />
          </span>
          Şikayetler
        </h1>
        <p className="mt-2 text-[12.5px] font-medium leading-relaxed text-[var(--muted)]">
          {intro}
        </p>
        <PrimaryBtn className="mt-3.5 w-full" onClick={() => setOpen(true)}>
          <Send size={15} /> Şikayetini Gönder
        </PrimaryBtn>
        <p className="mt-2 flex items-center gap-1.5 text-[11px] font-bold text-[var(--muted)]">
          <ShieldCheck size={12} /> Tüm gönderiler yayınlanmadan önce yönetici
          onayından geçer
        </p>
      </section>

      {topPolls.map((p) => (
        <PollCard key={p.id} poll={p} />
      ))}

      {/* Kendi gönderilerimin durumu */}
      {mine.length > 0 && (
        <section
          className="border p-4"
          style={{
            borderColor: "var(--line)",
            background: "var(--card)",
            borderRadius: "var(--radius)",
          }}
        >
          <h2 className="mb-2.5 flex items-center gap-1.5 text-[13px] font-extrabold tracking-tight">
            <Clock3 size={14} style={{ color: "var(--accent)" }} /> Gönderilerimin
            Durumu
          </h2>
          <div className="flex flex-col gap-2">
            {mine.map((m) => (
              <div
                key={m.id}
                className="flex items-center gap-2.5 rounded-xl px-3 py-2"
                style={{ background: "var(--bg)" }}
              >
                <span
                  className={`rounded-full px-2 py-0.5 text-[10px] font-extrabold ${STATUS_STYLE[m.status]}`}
                >
                  {COMPLAINT_STATUS_LABEL[m.status]}
                </span>
                <span className="min-w-0 flex-1 truncate text-[12px] font-bold">
                  {m.title || m.body.slice(0, 50)}
                </span>
                <span className="shrink-0 font-mono text-[10px] font-bold text-[var(--muted)]">
                  {m.ticket}
                </span>
              </div>
            ))}
            {mine.some((m) => m.status === "reddedildi" && m.adminNote) && (
              <p className="text-[11px] font-semibold text-rose-500">
                Not:{" "}
                {mine.find((m) => m.status === "reddedildi" && m.adminNote)?.adminNote}
              </p>
            )}
          </div>
        </section>
      )}

      {/* Onaylı şikayet akışı */}
      {list.length === 0 ? (
        <p className="py-14 text-center text-sm font-semibold text-[var(--muted)]">
          Henüz yayınlanmış şikayet yok — ilk gönderen sen ol.
        </p>
      ) : (
        <div className="flex flex-col gap-4">
          {list.map((c) => (
            <article
              key={c.id}
              className="animate-fade-up overflow-hidden border"
              style={{
                borderColor: "var(--line)",
                background: "var(--card)",
                borderRadius: "var(--radius)",
              }}
            >
              <header className="flex items-center gap-2.5 px-4 py-3">
                <span
                  className="flex h-9 w-9 items-center justify-center rounded-full"
                  style={{
                    background: "color-mix(in srgb, var(--accent) 12%, transparent)",
                    color: "var(--accent)",
                  }}
                >
                  <UserRound size={17} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="flex items-center gap-1.5 truncate text-[13px] font-extrabold tracking-tight">
                    {c.name || "Anonim Vatandaş"}
                    {c.pinned && (
                      <Pin
                        size={11}
                        className="fill-[var(--accent)] text-[var(--accent)]"
                      />
                    )}
                  </p>
                  <p className="flex items-center gap-1 truncate text-[10.5px] font-bold text-[var(--muted)]">
                    {c.district && (
                      <>
                        <MapPin size={10} /> {c.district} ·{" "}
                      </>
                    )}
                    {timeAgo(c.createdAt)}
                  </p>
                </div>
                <span className="flex shrink-0 items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-1 text-[9.5px] font-extrabold text-emerald-600">
                  <CheckCircle2 size={10} /> ONAYLI
                </span>
              </header>

              <MediaBox item={c} wm={watermark} />

              <div className="px-4 py-3">
                {c.title && (
                  <h3 className="text-[14px] font-extrabold tracking-tight">
                    {c.title}
                  </h3>
                )}
                <p className="mt-1 whitespace-pre-line text-[13px] leading-relaxed text-[var(--ink)]/85">
                  {c.body}
                </p>
                <p className="mt-2.5 flex items-center gap-3 border-t pt-2 text-[10.5px] font-semibold text-[var(--muted)]" style={{ borderColor: "var(--line)" }}>
                  <span className="flex items-center gap-1">
                    <Eye size={11} /> {formatCount(c.views)}
                  </span>
                  <span className="font-mono">{c.ticket}</span>
                  <span className="ml-auto flex items-center gap-1">
                    <MegaphoneOff size={11} /> Yorumlar kapalı
                  </span>
                </p>

                {canManage && (
                  <div className="mt-3 flex flex-wrap gap-1.5 border-t pt-3" style={{ borderColor: "var(--line)" }}>
                    <button
                      onClick={() => patch(c.id, { pinned: !c.pinned })}
                      className="rounded-full border px-3 py-1.5 text-[11px] font-extrabold"
                      style={{ borderColor: "var(--line)", background: "var(--bg)" }}
                    >
                      {c.pinned ? "Sabitlemeyi Kaldır" : "Üste Sabitle"}
                    </button>
                    <button
                      onClick={() => patch(c.id, { status: "beklemede" })}
                      className="rounded-full border px-3 py-1.5 text-[11px] font-extrabold"
                      style={{ borderColor: "var(--line)", background: "var(--bg)" }}
                    >
                      Yayından Kaldır
                    </button>
                    <button
                      onClick={() => remove(c.id)}
                      className="rounded-full border border-rose-500/30 bg-rose-500/10 px-3 py-1.5 text-[11px] font-extrabold text-rose-500"
                    >
                      <Trash2 size={11} className="mr-1 inline" /> Sil
                    </button>
                  </div>
                )}
              </div>
            </article>
          ))}
        </div>
      )}

      {/* Gönderim modalı */}
      <Modal
        open={open}
        onClose={() => {
          setOpen(false);
          setPreview(false);
        }}
        title={preview ? "Gönderi Önizleme" : "Şikayetini Gönder"}
        wide
      >
        {preview ? (
          <div className="space-y-4">
            <p className="rounded-xl px-3.5 py-2.5 text-[11.5px] font-semibold leading-relaxed" style={{ background: "var(--bg)", color: "var(--muted)" }}>
              Gönderin aşağıdaki gibi görünecek. Onayladıktan sonra yöneticiye
              iletilecek — yayınlanması onay sonrası olur.
            </p>
            <article
              className="overflow-hidden border"
              style={{ borderColor: "var(--line)", borderRadius: "var(--radius)" }}
            >
              <header className="flex items-center gap-2.5 px-4 py-3">
                <span
                  className="flex h-9 w-9 items-center justify-center rounded-full"
                  style={{
                    background: "color-mix(in srgb, var(--accent) 12%, transparent)",
                    color: "var(--accent)",
                  }}
                >
                  <UserRound size={17} />
                </span>
                <div>
                  <p className="text-[13px] font-extrabold">
                    {form.name || "Anonim Vatandaş"}
                  </p>
                  <p className="text-[10.5px] font-bold text-[var(--muted)]">
                    {form.district} · az önce
                  </p>
                </div>
              </header>
              {form.mediaUrl && (
                <MediaBox
                  item={{
                    mediaUrl: form.mediaUrl,
                    mediaType: form.mediaType,
                    posterUrl: form.posterUrl,
                  }}
                  wm={watermark}
                />
              )}
              <div className="px-4 py-3">
                {form.title && (
                  <h3 className="text-[14px] font-extrabold">{form.title}</h3>
                )}
                <p className="mt-1 whitespace-pre-line text-[13px] leading-relaxed">
                  {form.body}
                </p>
              </div>
            </article>
            <div className="flex gap-2">
              <GhostBtn className="flex-1" onClick={() => setPreview(false)}>
                Geri Dön
              </GhostBtn>
              <PrimaryBtn className="flex-1" onClick={submit} disabled={busy}>
                {busy ? "Gönderiliyor..." : "Onaya Gönder"}
              </PrimaryBtn>
            </div>
          </div>
        ) : (
          <div className="space-y-3.5">
            <div className="grid grid-cols-2 gap-3">
              <Field label="Adın (boş bırakırsan anonim)">
                <TextInput
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  placeholder="Anonim Vatandaş"
                />
              </Field>
              <Field label="Mahalle">
                <Select
                  value={form.district}
                  onChange={(e) => setForm({ ...form, district: e.target.value })}
                >
                  {DISTRICTS.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
            <Field label="Başlık">
              <TextInput
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                placeholder="Örn: Sokak lambaları 3 gündür yanmıyor"
              />
            </Field>
            <Field label="Şikayetin *">
              <TextArea
                rows={4}
                value={form.body}
                onChange={(e) => setForm({ ...form, body: e.target.value })}
                placeholder="Sorunu detaylıca anlat (en az 15 karakter)..."
              />
            </Field>

            <input
              ref={fileRef}
              type="file"
              accept="image/jpeg,image/png,image/webp,video/mp4,video/webm,video/quicktime"
              className="hidden"
              onChange={upload}
            />
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              disabled={uploading}
              className="inline-flex w-full items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-5 text-sm font-bold transition hover:border-[var(--accent)] hover:text-[var(--accent)] disabled:opacity-60"
              style={{ borderColor: "var(--line)", color: "var(--muted)" }}
            >
              {uploading ? <Spinner /> : <ImagePlus size={18} />}
              {uploading ? "Yükleniyor..." : "Fotoğraf veya video ekle (max 60MB)"}
            </button>

            {form.mediaUrl && (
              <div className="relative overflow-hidden rounded-xl border" style={{ borderColor: "var(--line)" }}>
                {form.mediaType === "video" ? (
                  <video src={form.mediaUrl} className="max-h-52 w-full object-cover" muted />
                ) : (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={form.mediaUrl} alt="" className="max-h-52 w-full object-cover" />
                )}
                <button
                  onClick={() => setForm({ ...form, mediaUrl: "", posterUrl: "" })}
                  className="absolute right-2 top-2 rounded-full bg-rose-500 px-2.5 py-1 text-[11px] font-extrabold text-white"
                >
                  Kaldır
                </button>
              </div>
            )}

            <p className="rounded-xl px-3.5 py-2.5 text-[11px] font-semibold leading-relaxed" style={{ background: "var(--bg)", color: "var(--muted)" }}>
              Gönderin yayınlandığında üzerine <b>&quot;{watermark.text}&quot;</b>{" "}
              filigranı eklenecektir. Hakaret, iftira ve kişisel veri içeren
              gönderiler reddedilir.
            </p>

            <div className="flex gap-2 pt-1">
              <GhostBtn className="flex-1" onClick={() => setOpen(false)}>
                Vazgeç
              </GhostBtn>
              <PrimaryBtn
                className="flex-1"
                onClick={() => {
                  if (form.body.trim().length < 15)
                    return toast("Şikayet metni en az 15 karakter olmalı");
                  setPreview(true);
                }}
              >
                Önizle
              </PrimaryBtn>
            </div>
          </div>
        )}
      </Modal>

      {/* Gönderildi bilgisi */}
      <Modal open={!!sent} onClose={() => setSent(null)} title="Gönderin Alındı">
        <div className="flex flex-col items-center gap-3 text-center">
          <span className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/10 text-emerald-600">
            <CheckCircle2 size={34} />
          </span>
          <h3 className="text-[16px] font-extrabold tracking-tight">
            Şikayetin yönetici onayına gönderildi
          </h3>
          <p className="text-[13px] font-medium leading-relaxed text-[var(--muted)]">
            Yönetici incelemesinden sonra onaylanırsa Şikayetler akışında
            yayınlanacak. Durumunu bu sayfadaki{" "}
            <b>&quot;Gönderilerimin Durumu&quot;</b> bölümünden takip edebilirsin.
          </p>
          <p className="rounded-xl px-4 py-2 font-mono text-[14px] font-extrabold" style={{ background: "var(--bg)", color: "var(--accent)" }}>
            {sent?.ticket}
          </p>
          <PrimaryBtn className="w-full" onClick={() => setSent(null)}>
            Tamam
          </PrimaryBtn>
        </div>
      </Modal>
    </div>
  );
}

export { XCircle, Pencil };
