"use client";

import { useState } from "react";
import type { OwnerProfile, VideoPost } from "@/lib/types";
import { formatCount, waLink } from "@/lib/types";
import { Eye, Heart, Megaphone, MessageCircle, Pin } from "lucide-react";
import { InstagramIcon, Modal, VerifiedBadge } from "./ui";
import VideoCard from "./VideoCard";

export default function ProfileClient({
  owner,
  posts: initialPosts,
  totalViews,
  totalLikes,
  canManage,
}: {
  owner: OwnerProfile;
  posts: VideoPost[];
  totalViews: number;
  totalLikes: number;
  canManage: boolean;
}) {
  const [posts, setPosts] = useState(initialPosts);
  const [active, setActive] = useState<VideoPost | null>(null);

  return (
    <div className="flex flex-col px-4 pt-6">
      {/* Profil başlığı */}
      <div className="flex items-center gap-6">
        <span className="ring-gradient shrink-0 rounded-full p-[3px]">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={owner.avatar}
            alt={owner.name}
            className="h-[84px] w-[84px] rounded-full border-4 border-[var(--bg)] object-cover"
          />
        </span>
        <div className="grid flex-1 grid-cols-3 gap-1 text-center">
          {[
            { n: formatCount(posts.length), l: "Gönderi" },
            { n: formatCount(totalViews), l: "İzlenme" },
            { n: formatCount(totalLikes), l: "Beğeni" },
          ].map((s) => (
            <div key={s.l}>
              <p className="text-[17px] font-extrabold tracking-tight">{s.n}</p>
              <p className="text-[10.5px] font-bold text-[var(--muted)]">
                {s.l}
              </p>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4">
        <h1 className="flex items-center gap-1.5 text-[19px] font-extrabold tracking-tight">
          {owner.name}
          {owner.verified && <VerifiedBadge size={19} />}
        </h1>
        <p className="text-[12.5px] font-bold text-[var(--muted)]">
          @{owner.username} · Elbistan
        </p>
        {owner.bio && (
          <p className="mt-2 whitespace-pre-line text-[13.5px] leading-relaxed text-[var(--ink)]/85">
            {owner.bio}
          </p>
        )}
      </div>

      {/* İletişim butonları */}
      <div className="mt-4 flex flex-col gap-2">
        <div className="grid grid-cols-2 gap-2">
          <a
            href={waLink(
              owner.whatsapp,
              "Merhaba, Sohbet Sokağı profilinizden ulaşıyorum."
            )}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 rounded-xl bg-[#25D366] px-3 py-3 text-[13px] font-extrabold text-white shadow-sm transition hover:opacity-90 active:scale-[.98]"
          >
            <MessageCircle size={16} /> WhatsApp
          </a>
          <a
            href={owner.instagram}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 rounded-xl border border-[var(--line)] bg-[var(--card)] px-3 py-3 text-[13px] font-extrabold transition hover:border-[var(--accent)] hover:text-[var(--accent)] active:scale-[.98]"
          >
            <InstagramIcon size={16} /> Instagram
          </a>
        </div>
        <a
          href={waLink(
            owner.whatsapp,
            "Merhaba, Sohbet Sokağı üzerinden reklam ve iş birliği için ulaşıyorum."
          )}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-2 rounded-xl bg-[var(--accent)] px-3 py-3 text-[13px] font-extrabold text-[var(--accent-ink)] shadow-md shadow-[var(--accent)]/25 transition hover:opacity-90 active:scale-[.98]"
        >
          <Megaphone size={16} /> Reklam ve İş Birliği
        </a>
      </div>

      {/* Gönderi ızgarası */}
      <div className="mt-6 border-t border-[var(--line)] pt-1.5">
        {posts.length === 0 ? (
          <p className="py-14 text-center text-sm font-semibold text-[var(--muted)]">
            Henüz gönderi yok.
          </p>
        ) : (
          <div className="grid grid-cols-3 gap-1.5">
            {posts.map((p) => (
              <button
                key={p.id}
                onClick={() => setActive(p)}
                className="group relative aspect-square overflow-hidden rounded-lg bg-neutral-200"
                aria-label={p.title || "Video gönderisi"}
              >
                {p.posterUrl ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={p.posterUrl}
                    alt={p.title || "Video"}
                    loading="lazy"
                    className="h-full w-full object-cover transition duration-300 group-hover:scale-105"
                  />
                ) : (
                  <video
                    src={p.videoUrl}
                    className="h-full w-full object-cover"
                    muted
                    playsInline
                    preload="metadata"
                  />
                )}
                {p.pinned && (
                  <Pin
                    size={14}
                    className="absolute right-1.5 top-1.5 fill-white text-white drop-shadow-md"
                  />
                )}
                <span className="absolute inset-0 flex items-center justify-center gap-3.5 bg-black/40 opacity-0 transition group-hover:opacity-100">
                  <span className="flex items-center gap-1 text-[12.5px] font-extrabold text-white">
                    <Heart size={15} className="fill-white" />
                    {formatCount(p.likes)}
                  </span>
                  <span className="flex items-center gap-1 text-[12.5px] font-extrabold text-white">
                    <Eye size={15} />
                    {formatCount(p.views)}
                  </span>
                </span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Gönderi modalı */}
      <Modal
        open={!!active}
        onClose={() => setActive(null)}
        title={active?.title || "Gönderi"}
      >
        {active && (
          <VideoCard
            post={active}
            owner={owner}
            canManage={canManage}
            onUpdated={(v) => {
              setPosts((ps) => ps.map((x) => (x.id === v.id ? v : x)));
              setActive(v);
            }}
            onDeleted={(id) => {
              setPosts((ps) => ps.filter((x) => x.id !== id));
              setActive(null);
            }}
          />
        )}
      </Modal>
    </div>
  );
}
