"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  Building2,
  Camera,
  Clapperboard,
  Plus,
  ShieldCheck,
} from "lucide-react";
import {
  Field,
  GhostBtn,
  Modal,
  PrimaryBtn,
  Select,
  TextArea,
  TextInput,
  Toggle,
  Uploader,
  useToast,
} from "./ui";
import { DISTRICTS, HEATING_OPTIONS } from "@/lib/types";

const EMPTY_LISTING = {
  title: "",
  type: "satilik",
  status: "aktif",
  price: "",
  rooms: "",
  area: "",
  floor: "",
  heating: "Doğalgaz Kombi",
  district: DISTRICTS[0],
  phone: "",
  description: "",
  images: [] as string[],
  pinned: false,
};

export default function OwnerPost() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [dialog, setDialog] = useState<null | "video" | "story" | "listing">(
    null
  );
  const [busy, setBusy] = useState(false);
  const router = useRouter();
  const { toast, node } = useToast();

  // Video formu
  const [vTitle, setVTitle] = useState("");
  const [vDesc, setVDesc] = useState("");
  const [vUrl, setVUrl] = useState("");
  const [vPoster, setVPoster] = useState("");
  const [vPinned, setVPinned] = useState(false);

  // Hikaye formu
  const [sUrl, setSUrl] = useState("");
  const [sType, setSType] = useState<"image" | "video">("image");

  // İlan formu
  const [lf, setLf] = useState(EMPTY_LISTING);

  function openDialog(d: "video" | "story" | "listing") {
    setMenuOpen(false);
    setDialog(d);
  }

  async function submitVideo() {
    if (!vUrl.trim()) return toast("Önce video ekleyin (URL veya yükleme)");
    setBusy(true);
    const r = await fetch("/api/videos", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title: vTitle,
        description: vDesc,
        videoUrl: vUrl,
        posterUrl: vPoster,
        pinned: vPinned,
      }),
    });
    setBusy(false);
    if (r.ok) {
      setDialog(null);
      setVTitle("");
      setVDesc("");
      setVUrl("");
      setVPoster("");
      setVPinned(false);
      toast("Video yayınlandı — abonelere bildirim gönderiliyor");
      router.refresh();
    } else {
      const j = await r.json().catch(() => ({}));
      toast(j.error || "Yayınlanamadı");
    }
  }

  async function submitStory() {
    if (!sUrl.trim()) return toast("Önce medya ekleyin");
    setBusy(true);
    const r = await fetch("/api/stories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mediaUrl: sUrl, mediaType: sType, hours: 24 }),
    });
    setBusy(false);
    if (r.ok) {
      setDialog(null);
      setSUrl("");
      setSType("image");
      toast("Hikaye paylaşıldı — 24 saat sonra otomatik silinecek");
      router.refresh();
    } else toast("Paylaşılamadı");
  }

  async function submitListing() {
    if (!lf.title.trim()) return toast("İlan başlığı gerekli");
    setBusy(true);
    const r = await fetch("/api/listings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        ...lf,
        price: Number(String(lf.price).replace(/[^\d]/g, "")) || 0,
        area: Number(lf.area) || 0,
      }),
    });
    setBusy(false);
    if (r.ok) {
      setDialog(null);
      setLf(EMPTY_LISTING);
      toast("İlan yayınlandı");
      router.refresh();
    } else {
      const j = await r.json().catch(() => ({}));
      toast(j.error || "Yayınlanamadı");
    }
  }

  return (
    <>
      {node}
      {/* Yüzen hızlı paylaşım butonu (sadece site sahibi IP'si / admin oturumu) */}
      <div className="fixed bottom-[86px] right-4 z-40 flex flex-col items-end gap-2.5">
        {menuOpen && (
          <div className="animate-fade-up flex flex-col items-end gap-2">
            <button
              onClick={() => openDialog("video")}
              className="flex items-center gap-2 rounded-full border border-[var(--line)] bg-[var(--card)] px-4 py-2.5 text-[12.5px] font-extrabold shadow-lg transition hover:border-[var(--accent)] hover:text-[var(--accent)]"
            >
              <Clapperboard size={16} className="text-[var(--accent)]" />
              Video Paylaş
            </button>
            <button
              onClick={() => openDialog("story")}
              className="flex items-center gap-2 rounded-full border border-[var(--line)] bg-[var(--card)] px-4 py-2.5 text-[12.5px] font-extrabold shadow-lg transition hover:border-[var(--accent)] hover:text-[var(--accent)]"
            >
              <Camera size={16} className="text-[var(--accent)]" />
              Hikaye Ekle (24s)
            </button>
            <button
              onClick={() => openDialog("listing")}
              className="flex items-center gap-2 rounded-full border border-[var(--line)] bg-[var(--card)] px-4 py-2.5 text-[12.5px] font-extrabold shadow-lg transition hover:border-[var(--accent)] hover:text-[var(--accent)]"
            >
              <Building2 size={16} className="text-[var(--accent)]" />
              Emlak İlanı Ekle
            </button>
            <a
              href="/admin"
              className="flex items-center gap-2 rounded-full border border-[var(--line)] bg-[var(--card)] px-4 py-2.5 text-[12.5px] font-extrabold shadow-lg transition hover:border-[var(--accent)] hover:text-[var(--accent)]"
            >
              <ShieldCheck size={16} className="text-[var(--accent)]" />
              Admin Paneli
            </a>
          </div>
        )}
        <button
          onClick={() => setMenuOpen((o) => !o)}
          className="flex h-14 w-14 items-center justify-center rounded-full bg-[var(--accent)] text-[var(--accent-ink)] shadow-xl shadow-[var(--accent)]/30 transition hover:scale-105 active:scale-95"
          aria-label="Hızlı paylaşım menüsü"
        >
          <Plus
            size={26}
            className={`transition-transform duration-300 ${
              menuOpen ? "rotate-45" : ""
            }`}
          />
        </button>
      </div>

      {/* Video paylaşma */}
      <Modal
        open={dialog === "video"}
        onClose={() => setDialog(null)}
        title="Yeni Video Paylaş"
      >
        <div className="space-y-3.5">
          <Uploader
            accept="video/mp4,video/webm,video/quicktime"
            onUploaded={(files) => {
              if (files[0]) {
                setVUrl(files[0].url);
                if (files[0].posterUrl) setVPoster(files[0].posterUrl!);
                toast("Video yüklendi");
              }
            }}
          >
            Cihazdan video yükle (mp4 — ffmpeg kapak üretir)
          </Uploader>
          <Field label="veya Video URL (mp4 / .m3u8 HLS / CDN)">
            <TextInput
              value={vUrl}
              onChange={(e) => setVUrl(e.target.value)}
              placeholder="https://.../video.mp4 veya https://cdn.../playlist.m3u8"
            />
          </Field>
          <Field label="Kapak görseli URL (opsiyonel)">
            <TextInput
              value={vPoster}
              onChange={(e) => setVPoster(e.target.value)}
              placeholder="https://.../kapak.jpg"
            />
          </Field>
          <Field label="Başlık">
            <TextInput
              value={vTitle}
              onChange={(e) => setVTitle(e.target.value)}
              placeholder="Elbistan'dan bir kesit..."
            />
          </Field>
          <Field label="Açıklama">
            <TextArea
              value={vDesc}
              onChange={(e) => setVDesc(e.target.value)}
              placeholder="Video açıklaması..."
            />
          </Field>
          <Toggle checked={vPinned} onChange={setVPinned} label="Üste sabitle" />
          <div className="flex gap-2 pt-1">
            <GhostBtn className="flex-1" onClick={() => setDialog(null)}>
              Vazgeç
            </GhostBtn>
            <PrimaryBtn
              className="flex-1"
              onClick={submitVideo}
              disabled={busy}
            >
              {busy ? "Yayınlanıyor..." : "Yayınla"}
            </PrimaryBtn>
          </div>
        </div>
      </Modal>

      {/* Hikaye ekleme */}
      <Modal
        open={dialog === "story"}
        onClose={() => setDialog(null)}
        title="Hikaye Ekle — 24 Saat"
      >
        <div className="space-y-3.5">
          <Uploader
            accept="image/jpeg,image/png,image/webp,video/mp4,video/webm"
            onUploaded={(files) => {
              if (files[0]) {
                setSUrl(files[0].url);
                setSType(files[0].mediaType === "video" ? "video" : "image");
                toast("Medya yüklendi");
              }
            }}
          >
            Görsel veya kısa video yükle
          </Uploader>
          <Field label="veya Medya URL">
            <TextInput
              value={sUrl}
              onChange={(e) => {
                setSUrl(e.target.value);
                if (/\.(mp4|webm|mov)(\?|$)/i.test(e.target.value))
                  setSType("video");
              }}
              placeholder="https://.../hikaye.jpg"
            />
          </Field>
          {sUrl && (
            <div className="overflow-hidden rounded-xl border border-[var(--line)]">
              {sType === "video" ? (
                <video src={sUrl} className="max-h-48 w-full object-cover" muted />
              ) : (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={sUrl} alt="Önizleme" className="max-h-48 w-full object-cover" />
              )}
            </div>
          )}
          <p className="text-[11.5px] font-semibold text-[var(--muted)]">
            Hikaye yayınlandıktan 24 saat sonra otomatik olarak silinir.
          </p>
          <div className="flex gap-2 pt-1">
            <GhostBtn className="flex-1" onClick={() => setDialog(null)}>
              Vazgeç
            </GhostBtn>
            <PrimaryBtn
              className="flex-1"
              onClick={submitStory}
              disabled={busy}
            >
              {busy ? "Paylaşılıyor..." : "Paylaş"}
            </PrimaryBtn>
          </div>
        </div>
      </Modal>

      {/* Emlak ilanı ekleme */}
      <Modal
        open={dialog === "listing"}
        onClose={() => setDialog(null)}
        title="Yeni Emlak İlanı"
        wide
      >
        <div className="space-y-3.5">
          <Field label="İlan Başlığı *">
            <TextInput
              value={lf.title}
              onChange={(e) => setLf({ ...lf, title: e.target.value })}
              placeholder="Örn: Cumhuriyet Mah. 3+1 Satılık Daire"
            />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Tür">
              <Select
                value={lf.type}
                onChange={(e) => setLf({ ...lf, type: e.target.value })}
              >
                <option value="satilik">Satılık</option>
                <option value="kiralik">Kiralık</option>
              </Select>
            </Field>
            <Field label="Durum">
              <Select
                value={lf.status}
                onChange={(e) => setLf({ ...lf, status: e.target.value })}
              >
                <option value="aktif">Yayında</option>
                <option value="satildi">Satıldı</option>
                <option value="kiralandi">Kiralandı</option>
              </Select>
            </Field>
            <Field label="Fiyat (₺)">
              <TextInput
                value={lf.price}
                inputMode="numeric"
                onChange={(e) => setLf({ ...lf, price: e.target.value })}
                placeholder="3450000"
              />
            </Field>
            <Field label="Oda Sayısı">
              <TextInput
                value={lf.rooms}
                onChange={(e) => setLf({ ...lf, rooms: e.target.value })}
                placeholder="3+1"
              />
            </Field>
            <Field label="Brüt m²">
              <TextInput
                value={lf.area}
                inputMode="numeric"
                onChange={(e) => setLf({ ...lf, area: e.target.value })}
                placeholder="145"
              />
            </Field>
            <Field label="Kat">
              <TextInput
                value={lf.floor}
                onChange={(e) => setLf({ ...lf, floor: e.target.value })}
                placeholder="3. Kat"
              />
            </Field>
            <Field label="Isıtma">
              <Select
                value={lf.heating}
                onChange={(e) => setLf({ ...lf, heating: e.target.value })}
              >
                {HEATING_OPTIONS.map((h) => (
                  <option key={h} value={h}>
                    {h}
                  </option>
                ))}
              </Select>
            </Field>
            <Field label="Mahalle / Konum">
              <Select
                value={lf.district}
                onChange={(e) => setLf({ ...lf, district: e.target.value })}
              >
                {DISTRICTS.map((d) => (
                  <option key={d} value={d}>
                    {d}
                  </option>
                ))}
              </Select>
            </Field>
          </div>
          <Field label="Telefon (boş bırakılırsa profil numarası kullanılır)">
            <TextInput
              value={lf.phone}
              onChange={(e) => setLf({ ...lf, phone: e.target.value })}
              placeholder="905551112233"
            />
          </Field>
          <Field label="Açıklama">
            <TextArea
              value={lf.description}
              onChange={(e) => setLf({ ...lf, description: e.target.value })}
              placeholder="İlan detayları..."
            />
          </Field>
          <Uploader
            accept="image/jpeg,image/png,image/webp"
            multiple
            onUploaded={(files) => {
              if (files.length)
                setLf((f) => ({
                  ...f,
                  images: [...f.images, ...files.map((x) => x.url)].slice(0, 10),
                }));
            }}
          >
            İlan fotoğrafları yükle (çoklu seçim)
          </Uploader>
          {lf.images.length > 0 && (
            <div className="flex flex-wrap gap-2">
              {lf.images.map((img, i) => (
                <div key={i} className="group relative">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={img}
                    alt=""
                    className="h-16 w-16 rounded-lg border border-[var(--line)] object-cover"
                  />
                  <button
                    onClick={() =>
                      setLf((f) => ({
                        ...f,
                        images: f.images.filter((_, x) => x !== i),
                      }))
                    }
                    className="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white opacity-90"
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}
          <Toggle
            checked={lf.pinned}
            onChange={(v) => setLf({ ...lf, pinned: v })}
            label="Üste sabitle"
          />
          <div className="flex gap-2 pt-1">
            <GhostBtn className="flex-1" onClick={() => setDialog(null)}>
              Vazgeç
            </GhostBtn>
            <PrimaryBtn
              className="flex-1"
              onClick={submitListing}
              disabled={busy}
            >
              {busy ? "Yayınlanıyor..." : "İlanı Yayınla"}
            </PrimaryBtn>
          </div>
        </div>
      </Modal>
    </>
  );
}
