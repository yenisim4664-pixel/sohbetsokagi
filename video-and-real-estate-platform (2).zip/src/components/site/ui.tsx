"use client";

import { createPortal } from "react-dom";
import { useCallback, useRef, useState } from "react";
import { BadgeCheck, Loader2, UploadCloud, X } from "lucide-react";

export function VerifiedBadge({ size = 16 }: { size?: number }) {
  return (
    <BadgeCheck
      size={size}
      className="shrink-0 fill-[#0095F6] text-[var(--card)]"
      aria-label="Doğrulanmış hesap"
    />
  );
}

export function InstagramIcon({
  size = 16,
  className,
}: {
  size?: number;
  className?: string;
}) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  );
}

export function useToast() {
  const [msg, setMsg] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const toast = useCallback((m: string) => {
    if (timer.current) clearTimeout(timer.current);
    setMsg(m);
    timer.current = setTimeout(() => setMsg(null), 2800);
  }, []);
  const node =
    msg && typeof document !== "undefined"
      ? createPortal(
          <div className="animate-toast-in fixed bottom-28 left-1/2 z-[110] max-w-[86vw] -translate-x-1/2 rounded-full border border-[var(--line)] bg-[var(--ink)] px-4 py-2.5 text-center text-[13px] font-semibold text-[var(--bg)] shadow-xl">
            {msg}
          </div>,
          document.body
        )
      : null;
  return { toast, node };
}

export function Modal({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title?: string;
  children: React.ReactNode;
  wide?: boolean;
}) {
  if (!open || typeof document === "undefined") return null;
  return createPortal(
    <div className="fixed inset-0 z-[90] flex items-end justify-center sm:items-center sm:p-4">
      <div
        className="animate-fade-in absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />
      <div
        className={`animate-sheet-up no-scrollbar relative max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl border border-[var(--line)] bg-[var(--card)] shadow-2xl sm:rounded-3xl ${
          wide ? "sm:max-w-xl" : "sm:max-w-md"
        }`}
      >
        {title && (
          <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[var(--line)] bg-[var(--card)]/95 px-5 py-4 backdrop-blur">
            <h3 className="text-[15px] font-extrabold tracking-tight">
              {title}
            </h3>
            <button
              onClick={onClose}
              className="rounded-full p-1.5 text-[var(--muted)] transition hover:bg-[var(--bg)] hover:text-[var(--ink)]"
              aria-label="Kapat"
            >
              <X size={18} />
            </button>
          </div>
        )}
        <div className="p-5">{children}</div>
      </div>
    </div>,
    document.body
  );
}

export function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold text-[var(--muted)]">
        {label}
      </span>
      {children}
    </label>
  );
}

export const inputCls =
  "w-full rounded-xl border border-[var(--line)] bg-[var(--bg)] px-3.5 py-2.5 text-sm text-[var(--ink)] placeholder:text-[var(--muted)]/70 transition focus:border-[var(--accent)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)]/30";

export function TextInput(
  props: React.InputHTMLAttributes<HTMLInputElement>
) {
  return (
    <input {...props} className={inputCls + " " + (props.className || "")} />
  );
}

export function TextArea(
  props: React.TextareaHTMLAttributes<HTMLTextAreaElement>
) {
  return (
    <textarea
      rows={3}
      {...props}
      className={inputCls + " resize-none " + (props.className || "")}
    />
  );
}

export function Select(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return (
    <select {...props} className={inputCls + " " + (props.className || "")} />
  );
}

export function PrimaryBtn({
  children,
  className,
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...rest}
      className={
        "inline-flex items-center justify-center gap-2 rounded-xl bg-[var(--accent)] px-4 py-2.5 text-sm font-bold text-[var(--accent-ink)] shadow-sm transition hover:opacity-90 active:scale-[.98] disabled:pointer-events-none disabled:opacity-50 " +
        (className || "")
      }
    >
      {children}
    </button>
  );
}

export function GhostBtn({
  children,
  className,
  ...rest
}: React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button
      {...rest}
      className={
        "inline-flex items-center justify-center gap-2 rounded-xl border border-[var(--line)] bg-[var(--card)] px-4 py-2.5 text-sm font-bold text-[var(--ink)] transition hover:bg-[var(--bg)] active:scale-[.98] disabled:pointer-events-none disabled:opacity-50 " +
        (className || "")
      }
    >
      {children}
    </button>
  );
}

export function Spinner({ size = 16 }: { size?: number }) {
  return <Loader2 size={size} className="animate-spin" />;
}

export type UploadedFile = {
  url: string;
  posterUrl?: string;
  mediaType: string;
  name?: string;
};

export function Uploader({
  accept,
  multiple,
  onUploaded,
  children,
  className,
}: {
  accept: string;
  multiple?: boolean;
  onUploaded: (files: UploadedFile[]) => void;
  children: React.ReactNode;
  className?: string;
}) {
  const [busy, setBusy] = useState(false);
  const ref = useRef<HTMLInputElement>(null);
  async function handle(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    setBusy(true);
    const out: UploadedFile[] = [];
    for (const f of files) {
      const fd = new FormData();
      fd.append("file", f);
      try {
        const r = await fetch("/api/upload", { method: "POST", body: fd });
        const j = await r.json();
        if (r.ok && j.url) out.push(j);
      } catch {
        // sıradaki dosyaya geç
      }
    }
    setBusy(false);
    if (ref.current) ref.current.value = "";
    onUploaded(out);
  }
  return (
    <>
      <input
        ref={ref}
        type="file"
        accept={accept}
        multiple={multiple}
        className="hidden"
        onChange={handle}
      />
      <button
        type="button"
        disabled={busy}
        onClick={() => ref.current?.click()}
        className={
          className ||
          "inline-flex w-full items-center justify-center gap-2 rounded-xl border-2 border-dashed border-[var(--line)] px-4 py-5 text-sm font-bold text-[var(--muted)] transition hover:border-[var(--accent)] hover:text-[var(--accent)] disabled:opacity-60"
        }
      >
        {busy ? <Spinner /> : <UploadCloud size={18} />}
        {busy ? "Yükleniyor..." : children}
      </button>
    </>
  );
}

export function Toggle({
  checked,
  onChange,
  label,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={() => onChange(!checked)}
      className="flex w-full items-center justify-between gap-3 rounded-xl border border-[var(--line)] bg-[var(--bg)] px-3.5 py-2.5"
    >
      <span className="text-sm font-semibold">{label}</span>
      <span
        className={`relative h-6 w-11 rounded-full transition ${
          checked ? "bg-[var(--accent)]" : "bg-[var(--line)]"
        }`}
      >
        <span
          className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all ${
            checked ? "left-[22px]" : "left-0.5"
          }`}
        />
      </span>
    </button>
  );
}
