import {
  pgTable,
  serial,
  text,
  integer,
  boolean,
  timestamp,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
});

export const videos = pgTable("videos", {
  id: serial("id").primaryKey(),
  title: text("title").notNull().default(""),
  description: text("description").notNull().default(""),
  videoUrl: text("video_url").notNull(),
  posterUrl: text("poster_url").notNull().default(""),
  views: integer("views").notNull().default(0),
  likes: integer("likes").notNull().default(0),
  pinned: boolean("pinned").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const stories = pgTable("stories", {
  id: serial("id").primaryKey(),
  mediaUrl: text("media_url").notNull(),
  mediaType: text("media_type").notNull().default("image"), // image | video
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

export const listings = pgTable("listings", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  price: integer("price").notNull().default(0),
  type: text("type").notNull().default("satilik"), // satilik | kiralik
  status: text("status").notNull().default("aktif"), // aktif | satildi | kiralandi
  rooms: text("rooms").notNull().default(""),
  area: integer("area").notNull().default(0),
  floor: text("floor").notNull().default(""),
  heating: text("heating").notNull().default(""),
  district: text("district").notNull().default(""),
  images: text("images").notNull().default("[]"), // JSON string array
  phone: text("phone").notNull().default(""),
  pinned: boolean("pinned").notNull().default(false),
  views: integer("views").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const likes = pgTable(
  "likes",
  {
    id: serial("id").primaryKey(),
    videoId: integer("video_id").notNull(),
    ip: text("ip").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("likes_video_ip_idx").on(t.videoId, t.ip)]
);

export const visits = pgTable(
  "visits",
  {
    id: serial("id").primaryKey(),
    ip: text("ip").notNull(),
    path: text("path").notNull().default("/"),
    ua: text("ua").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [
    index("visits_created_idx").on(t.createdAt),
    index("visits_ip_idx").on(t.ip),
  ]
);

export const bannedIps = pgTable(
  "banned_ips",
  {
    id: serial("id").primaryKey(),
    ip: text("ip").notNull(),
    reason: text("reason").notNull().default(""),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("banned_ip_idx").on(t.ip)]
);

export const pushSubs = pgTable(
  "push_subscriptions",
  {
    id: serial("id").primaryKey(),
    endpoint: text("endpoint").notNull(),
    data: text("data").notNull().default("{}"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (t) => [uniqueIndex("push_endpoint_idx").on(t.endpoint)]
);

export const polls = pgTable("polls", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  description: text("description").notNull().default(""),
  options: text("options").notNull().default("[]"), // JSON: [{id,text,votes}]
  position: text("position").notNull().default("feed-top"), // feed-top | feed-inline | emlak-top | sikayet-top
  active: boolean("active").notNull().default(true),
  pinned: boolean("pinned").notNull().default(false),
  multi: boolean("multi").notNull().default(false),
  showResults: boolean("show_results").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const pollVotes = pgTable(
  "poll_votes",
  {
    id: serial("id").primaryKey(),
    pollId: integer("poll_id").notNull(),
    optionId: text("option_id").notNull(),
    ip: text("ip").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [uniqueIndex("poll_vote_ip_idx").on(t.pollId, t.ip)]
);

export const complaints = pgTable(
  "complaints",
  {
    id: serial("id").primaryKey(),
    name: text("name").notNull().default(""),
    district: text("district").notNull().default(""),
    title: text("title").notNull().default(""),
    body: text("body").notNull().default(""),
    mediaUrl: text("media_url").notNull().default(""),
    mediaType: text("media_type").notNull().default("image"), // image | video
    posterUrl: text("poster_url").notNull().default(""),
    status: text("status").notNull().default("beklemede"), // beklemede | onaylandi | reddedildi
    adminNote: text("admin_note").notNull().default(""),
    ip: text("ip").notNull().default(""),
    ticket: text("ticket").notNull().default(""),
    views: integer("views").notNull().default(0),
    pinned: boolean("pinned").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  },
  (t) => [index("complaints_status_idx").on(t.status), index("complaints_ip_idx").on(t.ip)]
);
