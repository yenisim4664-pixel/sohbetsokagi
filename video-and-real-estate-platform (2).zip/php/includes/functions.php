<?php
/**
 * SOHBET SOKAĞI — Ortak yardımcı fonksiyonlar
 * Ayarlar, oturum, IP güvenliği, ziyaretçi takibi, biçimlendirme, şablonlar.
 */

require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_name('ss_admin');
    session_start();
}

/* ---------------------------------------------------------------
 * AYARLAR
 * ------------------------------------------------------------- */

function getSetting(string $key, ?string $default = null): ?string
{
    if (!isset($GLOBALS['ss_settings_cache']) || !is_array($GLOBALS['ss_settings_cache'])) {
        $cache = [];
        try {
            foreach (dbAll('SELECT `key`, `value` FROM settings') as $row) {
                $cache[$row['key']] = $row['value'];
            }
        } catch (Throwable $e) {
            $cache = [];
        }
        $GLOBALS['ss_settings_cache'] = $cache;
    }
    $cache = $GLOBALS['ss_settings_cache'];
    return array_key_exists($key, $cache) ? $cache[$key] : $default;
}

function setSetting(string $key, string $value): void
{
    dbRun(
        'INSERT INTO settings (`key`, `value`) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE `value` = VALUES(`value`)',
        [$key, $value]
    );
    // İstek içi önbelleği geçersiz kıl
    $GLOBALS['ss_settings_cache'] = null;
    unset($GLOBALS['ss_settings_cache']);
}

function getSettingJson(string $key, array $default = []): array
{
    $raw = getSetting($key);
    if (!$raw) return $default;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $default;
}

const DEFAULT_THEME = [
    'accent' => '#FF5A3C', 'accentInk' => '#FFFFFF',
    'gradientFrom' => '#FF8A00', 'gradientTo' => '#E1306C',
    'bg' => '#FAF7F3', 'card' => '#FFFFFF', 'ink' => '#1C1611',
    'muted' => '#98897B', 'line' => '#F0E8E0', 'radius' => '20px',
];

const DEFAULT_OWNER = [
    'name' => 'Sohbet Sokağı', 'username' => 'sohbetsokagi',
    'avatar' => 'assets/img/avatar.jpg',
    'bio' => "Elbistan'ın video ve emlak platformu.",
    'verified' => true,
    'instagram' => 'https://instagram.com/sohbetsokagi',
    'whatsapp' => '905551112233', 'email' => 'info@sohbetsokagi.com',
];

const DEFAULT_SEO = [
    'title' => 'Sohbet Sokağı — Elbistan Video Akışı ve Emlak Platformu',
    'description' => 'Elbistan merkezli Sohbet Sokağı.',
    'keywords' => 'Elbistan, sohbet sokağı, elbistan emlak',
    'ogImage' => 'assets/img/icon-512.png',
];

/** Tüm site ayarlarını tek dizide toplar */
function siteData(): array
{
    static $site = null;
    if ($site !== null) return $site;
    $site = [
        'siteName'   => getSetting('site_name') ?: 'Sohbet Sokağı',
        'tagline'    => getSetting('tagline') ?: "Elbistan'ın sokak sokak video ve emlak platformu",
        'logoUrl'    => getSetting('logo_url') ?: '',
        'footerText' => getSetting('footer_text') ?: '© Sohbet Sokağı — Elbistan. Tüm hakları saklıdır.',
        'theme'      => array_merge(DEFAULT_THEME, getSettingJson('theme')),
        'owner'      => array_merge(DEFAULT_OWNER, getSettingJson('owner')),
        'seo'        => array_merge(DEFAULT_SEO, getSettingJson('seo')),
        'banners'    => getSettingJson('banners', []),
        'ownerIps'   => getSetting('owner_ips') ?: '',
        'pushOnPost' => getSetting('push_on_post', '1') !== '0',
    ];
    return $site;
}

/** Tema değişkenlerini CSS olarak döndürür */
function themeStyle(array $t): string
{
    return "--accent:{$t['accent']};--accent-ink:{$t['accentInk']};--g-from:{$t['gradientFrom']};--g-to:{$t['gradientTo']};--bg:{$t['bg']};--card:{$t['card']};--ink:{$t['ink']};--muted:{$t['muted']};--line:{$t['line']};--radius:{$t['radius']};";
}

/* ---------------------------------------------------------------
 * YETKİ & GÜVENLİK
 * ------------------------------------------------------------- */

function clientIp(): string
{
    $ip = '';
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = trim(explode(',', $_SERVER['HTTP_X_FORWARDED_FOR'])[0]);
    } elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    }
    if (strpos($ip, '::ffff:') === 0) $ip = substr($ip, 7);
    return $ip ?: '127.0.0.1';
}

function isBanned(string $ip): bool
{
    return dbOne('SELECT id FROM banned_ips WHERE ip = ? LIMIT 1', [$ip]) !== null;
}

function recordVisit(string $ip, string $path, string $ua): void
{
    try {
        dbRun('INSERT INTO visits (ip, path, ua) VALUES (?, ?, ?)', [
            $ip,
            mb_substr($path, 0, 200),
            mb_substr($ua, 0, 300),
        ]);
        // Zaman zaman eski kayıtları temizle (7 gün)
        if (mt_rand(1, 100) <= 5) {
            dbRun('DELETE FROM visits WHERE created_at < NOW() - INTERVAL 7 DAY');
        }
    } catch (Throwable $e) {
        // sessiz geç
    }
}

function isAdmin(): bool
{
    return !empty($_SESSION['ss_admin_ok'])
        && hash_equals(SESSION_SECRET . '::ok', (string) $_SESSION['ss_admin_ok']);
}

function grantAdmin(): void
{
    $_SESSION['ss_admin_ok'] = substr(SESSION_SECRET . '::ok', 0);
    // tam değeri sakla
    $_SESSION['ss_admin_ok'] = SESSION_SECRET . '::ok';
}

function revokeAdmin(): void
{
    $_SESSION = [];
    session_destroy();
}

function hashPassword(string $pw): string
{
    return hash('sha256', 'ss::' . $pw);
}

function verifyAdminPassword(string $pw): bool
{
    $stored = getSetting('admin_password_hash');
    if (!$stored) {
        $stored = hashPassword('admin123');
        setSetting('admin_password_hash', $stored);
    }
    return hash_equals($stored, hashPassword($pw));
}

function ownerIps(): array
{
    $raw = getSetting('owner_ips') ?: '';
    return array_values(array_filter(array_map('trim', explode(',', $raw))));
}

function isOwnerIp(): bool
{
    $ips = ownerIps();
    return count($ips) > 0 && in_array(clientIp(), $ips, true);
}

/** Admin paneli oturumu VEYA kayıtlı sahip IP'si → site içi yönetim */
function canManage(string $base = ''): bool
{
    return isAdmin() || isOwnerIp();
}

function baseUrl(): string
{
    // php/ klasörünün web köküne göre göreli yolu (örn. "/" veya "/sohbet/")
    $script = $_SERVER['SCRIPT_NAME'] ?? '/index.php';
    $dir = rtrim(str_replace('\\', '/', dirname($script)), '/');
    // api/ veya admin/ altındaysak bir üst dizine çık
    $dir = preg_replace('#/(api|admin)$#', '', $dir);
    return $dir === '' ? '' : $dir;
}

/* ---------------------------------------------------------------
 * API YARDIMCILARI
 * ------------------------------------------------------------- */

function jsonResponse($data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonBody(): array
{
    $raw = file_get_contents('php://input');
    $data = json_decode($raw ?: '', true);
    return is_array($data) ? $data : [];
}

function requireAdminApi(): void
{
    if (!isAdmin()) {
        jsonResponse(['error' => 'Yetkisiz erişim'], 401);
    }
}

function requireManageApi(): void
{
    if (!canManage()) {
        jsonResponse(['error' => 'Yetkisiz erişim'], 401);
    }
}

/* ---------------------------------------------------------------
 * BİÇİMLENDİRME (Türkçe)
 * ------------------------------------------------------------- */

function e(?string $s): string
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function timeAgo(string $datetime): string
{
    $ts = strtotime($datetime);
    $s = max(1, time() - $ts);
    if ($s < 60) return 'az önce';
    $m = (int) floor($s / 60);
    if ($m < 60) return "$m dk önce";
    $h = (int) floor($m / 60);
    if ($h < 24) return "$h sa önce";
    $g = (int) floor($h / 24);
    if ($g < 7) return "$g gün önce";
    $hf = (int) floor($g / 7);
    if ($hf < 5) return "$hf hf önce";
    $ay = (int) floor($g / 30);
    if ($ay < 12) return "$ay ay önce";
    return ((int) floor($ay / 12)) . ' yıl önce';
}

function fullDateTime(string $datetime): string
{
    $ts = strtotime($datetime);
    $aylar = [1=>'Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
    return date('j', $ts) . ' ' . $aylar[(int) date('n', $ts)] . ' ' . date('Y, H:i', $ts);
}

function fullDate(string $datetime): string
{
    $ts = strtotime($datetime);
    $aylar = [1=>'Ocak','Şubat','Mart','Nisan','Mayıs','Haziran','Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık'];
    return date('j', $ts) . ' ' . $aylar[(int) date('n', $ts)] . ' ' . date('Y', $ts);
}

function formatCount($n): string
{
    $n = (int) $n;
    if ($n < 1000) return (string) $n;
    if ($n < 1000000) {
        $v = round($n / 1000, 1);
        return rtrim(rtrim(number_format($v, 1, ',', ''), '0'), ',') . ' B';
    }
    $v = round($n / 1000000, 1);
    return rtrim(rtrim(number_format($v, 1, ',', ''), '0'), ',') . ' Mn';
}

function formatPrice($n, string $type = 'satilik'): string
{
    $base = '₺' . number_format((float) $n, 0, ',', '.');
    return $type === 'kiralik' ? $base . '/ay' : $base;
}

function waLink(string $phone, string $text = ''): string
{
    $clean = preg_replace('/[^\d]/', '', $phone);
    return 'https://wa.me/' . $clean . ($text ? '?text=' . rawurlencode($text) : '');
}

function isoDate(string $datetime): string
{
    return date('c', strtotime($datetime));
}

/* ---------------------------------------------------------------
 * MODEL DÖNÜŞÜMLERİ (API çıktıları)
 * ------------------------------------------------------------- */

function videoToJson(array $v): array
{
    return [
        'id'          => (int) $v['id'],
        'title'       => $v['title'],
        'description' => $v['description'],
        'videoUrl'    => $v['video_url'],
        'posterUrl'   => $v['poster_url'],
        'views'       => (int) $v['views'],
        'likes'       => (int) $v['likes'],
        'pinned'      => (bool) $v['pinned'],
        'createdAt'   => isoDate($v['created_at']),
    ];
}

function storyToJson(array $s): array
{
    return [
        'id'        => (int) $s['id'],
        'mediaUrl'  => $s['media_url'],
        'mediaType' => $s['media_type'] === 'video' ? 'video' : 'image',
        'createdAt' => isoDate($s['created_at']),
        'expiresAt' => isoDate($s['expires_at']),
    ];
}

function listingToJson(array $l): array
{
    $images = json_decode($l['images'] ?: '[]', true);
    if (!is_array($images)) $images = [];
    return [
        'id'          => (int) $l['id'],
        'title'       => $l['title'],
        'description' => $l['description'],
        'price'       => (int) $l['price'],
        'type'        => $l['type'] === 'kiralik' ? 'kiralik' : 'satilik',
        'status'      => in_array($l['status'], ['satildi', 'kiralandi'], true) ? $l['status'] : 'aktif',
        'rooms'       => $l['rooms'],
        'area'        => (int) $l['area'],
        'floor'       => $l['floor'],
        'heating'     => $l['heating'],
        'district'    => $l['district'],
        'images'      => $images,
        'phone'       => $l['phone'],
        'pinned'      => (bool) $l['pinned'],
        'views'       => (int) $l['views'],
        'createdAt'   => isoDate($l['created_at']),
    ];
}

/* ---------------------------------------------------------------
 * ORTAK BİLEŞENLER (HTML)
 * ------------------------------------------------------------- */

function verifiedBadge(int $size = 16): string
{
    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="#0095F6" stroke="var(--card)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="shrink-0"><path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><path d="m9 12 2 2 4-4" stroke="var(--card)" fill="none"/></svg>';
}

function instagramIcon(int $size = 16): string
{
    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="20" x="2" y="2" rx="5" ry="5"/><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"/><line x1="17.5" x2="17.51" y1="6.5" y2="6.5"/></svg>';
}

/** Aktif (süresi geçmemiş) hikayeleri döndürür, süresi geçenleri siler */
function activeStories(): array
{
    try {
        dbRun('DELETE FROM stories WHERE expires_at < NOW()');
    } catch (Throwable $e) {
        // yoksay
    }
    return dbAll('SELECT * FROM stories WHERE expires_at > NOW() ORDER BY created_at ASC');
}

const POSITION_LABELS = [
    'feed-top' => 'Akış üstü',
    'feed-inline' => 'Akış içi',
    'emlak-top' => 'Emlak üstü',
];

const DISTRICTS = [
    'Cumhuriyet', 'Güneşli', 'Pınarbaşı', 'Tepebaşı', 'Orhangazi', 'Yunus Emre',
    'Bahçelievler', 'Esentepe', 'Kızılcaoba', 'Taşoluk', 'Ağcaşar', 'Karaelbistan',
    'İğde', 'Afsin Yolu',
];

const HEATING_OPTIONS = [
    'Doğalgaz Kombi', 'Merkezi Isıtma', 'Kat Kaloriferi', 'Soba',
    'Yerden Isıtma', 'Klima', 'Güneş Enerjisi',
];

const LISTING_STATUS_LABELS = [
    'aktif' => 'Yayında', 'satildi' => 'Satıldı', 'kiralandi' => 'Kiralandı',
];
