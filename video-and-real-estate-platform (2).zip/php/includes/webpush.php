<?php
/**
 * SOHBET SOKAĞI — Saf PHP Web Push Motoru
 * Harici kütüphane YOK. VAPID (RFC 8292) + aes128gcm (RFC 8291)
 * tamamen PHP openssl/gmp'siz standart fonksiyonlarla uygulanmıştır.
 *
 * Gereksinimler: PHP 7.4+ (8.x önerilir), openssl eklentisi.
 * Şifreli gönderim için openssl_pkey_derive (PHP 7.3+) gerekir;
 * yoksa bildirim yükü olmadan (varsayılan metinle) gönderilir.
 */

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';

/* --------------------- Base64URL --------------------- */

function b64url_encode(string $data): string
{
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function b64url_decode(string $data): string
{
    $pad = strlen($data) % 4;
    if ($pad) $data .= str_repeat('=', 4 - $pad);
    return base64_decode(strtr($data, '-_', '+/')) ?: '';
}

/* --------------------- VAPID Anahtarları --------------------- */

function ensureVapidKeys(): array
{
    $public = getSetting('vapid_public');
    $privatePem = getSetting('vapid_private_pem');
    if ($public && $privatePem) {
        return ['publicKey' => $public, 'privatePem' => $privatePem];
    }
    // Yeni P-256 anahtar çifti üret
    $res = openssl_pkey_new([
        'curve_name'       => 'prime256v1',
        'private_key_type' => OPENSSL_KEYTYPE_EC,
    ]);
    if (!$res) {
        throw new RuntimeException('VAPID anahtarı üretilemedi (openssl gerekli).');
    }
    openssl_pkey_export($res, $pem);
    $details = openssl_pkey_get_details($res);
    $x = str_pad($details['ec']['x'], 32, "\0", STR_PAD_LEFT);
    $y = str_pad($details['ec']['y'], 32, "\0", STR_PAD_LEFT);
    $public = b64url_encode("\x04" . $x . $y);
    setSetting('vapid_public', $public);
    setSetting('vapid_private_pem', $pem);
    return ['publicKey' => $public, 'privatePem' => $pem];
}

/* --------------------- ES256 İmzalama --------------------- */

/** openssl DER imzasını JWS raw (R||S, 64 bayt) biçimine çevirir */
function derSignatureToRaw(string $der): string
{
    $offset = 0;
    if (ord($der[$offset++]) !== 0x30) return str_pad('', 64, "\0");
    // uzunluk (kısa veya uzun form)
    $len = ord($der[$offset++]);
    if ($len & 0x80) {
        $n = $len & 0x7F;
        $len = 0;
        for ($i = 0; $i < $n; $i++) $len = ($len << 8) | ord($der[$offset++]);
    }
    $out = '';
    for ($i = 0; $i < 2; $i++) {
        if (ord($der[$offset++]) !== 0x02) return str_pad('', 64, "\0");
        $ilen = ord($der[$offset++]);
        $int = substr($der, $offset, $ilen);
        $offset += $ilen;
        $int = ltrim($int, "\0"); // işaret baytını at
        $out .= str_pad($int, 32, "\0", STR_PAD_LEFT);
    }
    return $out;
}

function vapidJwt(string $aud, string $sub, string $privatePem): string
{
    $header = b64url_encode(json_encode(['typ' => 'JWT', 'alg' => 'ES256']));
    $payload = b64url_encode(json_encode([
        'aud' => $aud,
        'exp' => time() + 12 * 3600,
        'sub' => $sub,
    ]));
    $data = $header . '.' . $payload;
    $der = '';
    openssl_sign($data, $der, $privatePem, OPENSSL_ALGO_SHA256);
    return $data . '.' . b64url_encode(derSignatureToRaw($der));
}

/* --------------------- aes128gcm Şifreleme (RFC 8291) --------------------- */

function hkdfExtract(string $salt, string $ikm): string
{
    return hash_hmac('sha256', $ikm, $salt, true);
}

function hkdfExpand(string $prk, string $info, int $length): string
{
    return substr(hash_hmac('sha256', $info . "\x01", $prk, true), 0, $length);
}

/** Ham P-256 noktasından (65 bayt) PEM public key üretir (SPKI DER) */
function rawPointToPem(string $point65): string
{
    $der = hex2bin('3059301306072a8648ce3d020106082a8648ce3d030107034200') . $point65;
    return "-----BEGIN PUBLIC KEY-----\n"
        . chunk_split(base64_encode($der), 64, "\n")
        . "-----END PUBLIC KEY-----\n";
}

/**
 * Bildirim yükünü aes128gcm ile şifreler.
 * Döndürür: gövde (binary) veya başarısızsa null.
 */
function encryptPayload(string $p256dhB64, string $authB64, string $payload): ?string
{
    if (!function_exists('openssl_pkey_derive')) return null;
    $uaPublic = b64url_decode($p256dhB64);   // 65 bayt
    $authSecret = b64url_decode($authB64);   // 16 bayt
    if (strlen($uaPublic) !== 65 || strlen($authSecret) < 12) return null;

    // Geçici (ephemeral) sunucu anahtarı
    $ephem = openssl_pkey_new([
        'curve_name'       => 'prime256v1',
        'private_key_type' => OPENSSL_KEYTYPE_EC,
    ]);
    if (!$ephem) return null;
    $det = openssl_pkey_get_details($ephem);
    $asPublic = "\x04"
        . str_pad($det['ec']['x'], 32, "\0", STR_PAD_LEFT)
        . str_pad($det['ec']['y'], 32, "\0", STR_PAD_LEFT);

    // ECDH paylaşılan giz
    $peerPem = rawPointToPem($uaPublic);
    $peer = openssl_pkey_get_public($peerPem);
    if (!$peer) return null;
    $shared = openssl_pkey_derive($peer, $ephem, 32);
    if (!$shared) return null;

    // RFC 8291 anahtar türetme
    $prkKey = hash_hmac('sha256', $shared, $authSecret, true);
    $keyInfo = 'WebPush: info' . "\x00" . $uaPublic . $asPublic;
    $ikm = hash_hmac('sha256', $keyInfo, $prkKey, true);
    $salt = random_bytes(16);
    $prk = hkdfExtract($salt, $ikm);
    $cek = hkdfExpand($prk, 'Content-Encoding: aes128gcm' . "\x00", 16);
    $nonce = hkdfExpand($prk, 'Content-Encoding: nonce' . "\x00", 12);

    // Dolgu: içerik + 0x02
    $tag = '';
    $cipher = openssl_encrypt(
        $payload . "\x02",
        'aes-128-gcm',
        $cek,
        OPENSSL_RAW_DATA,
        $nonce,
        $tag
    );
    if ($cipher === false) return null;

    // Gövde: salt(16) | rs(4) | idlen(1) | serverPublic(65) | ciphertext | tag(16)
    return $salt . pack('N', 4096) . chr(65) . $asPublic . $cipher . $tag;
}

/* --------------------- HTTP Gönderim --------------------- */

function httpPost(string $url, string $body, array $headers): int
{
    $headerLines = [];
    foreach ($headers as $k => $v) $headerLines[] = "$k: $v";

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => $body,
            CURLOPT_HTTPHEADER     => $headerLines,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
        ]);
        curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        return $code;
    }
    // cURL yoksa stream ile gönder
    $ctx = stream_context_create([
        'http' => [
            'method'        => 'POST',
            'header'        => implode("\r\n", $headerLines),
            'content'       => $body,
            'timeout'       => 15,
            'ignore_errors' => true,
        ],
    ]);
    $result = @file_get_contents($url, false, $ctx);
    if ($result === false || empty($http_response_header[0])) return 0;
    preg_match('#\s(\d{3})#', $http_response_header[0], $m);
    return isset($m[1]) ? (int) $m[1] : 0;
}

/** Tek bir aboneye bildirim gönderir, HTTP durum kodunu döndürür */
function sendPushToSubscription(array $sub, array $payload, array $vapid): int
{
    $endpoint = $sub['endpoint'];
    $data = json_decode($sub['data'] ?: '{}', true);
    $keys = $data['keys'] ?? [];

    $parts = parse_url($endpoint);
    $aud = ($parts['scheme'] ?? 'https') . '://' . ($parts['host'] ?? '');
    $jwt = vapidJwt($aud, 'mailto:info@sohbetsokagi.com', $vapid['privatePem']);

    $headers = [
        'TTL'           => '86400',
        'Authorization' => 'vapid t=' . $jwt . ', k=' . $vapid['publicKey'],
    ];

    $body = '';
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE);
    if (!empty($keys['p256dh']) && !empty($keys['auth'])) {
        $encrypted = encryptPayload($keys['p256dh'], $keys['auth'], $json);
        if ($encrypted !== null) {
            $body = $encrypted;
            $headers['Content-Encoding'] = 'aes128gcm';
            $headers['Content-Type'] = 'application/octet-stream';
        }
    }
    return httpPost($endpoint, $body, $headers);
}

/** Tüm abonelere bildirim gönderir; ölü abonelikleri temizler */
function sendPushToAll(array $payload): array
{
    $vapid = ensureVapidKeys();
    $subs = dbAll('SELECT * FROM push_subscriptions');
    $sent = 0;
    $removed = 0;
    foreach ($subs as $sub) {
        try {
            $code = sendPushToSubscription($sub, $payload, $vapid);
            if ($code >= 200 && $code < 300) {
                $sent++;
            } elseif ($code === 404 || $code === 410) {
                dbRun('DELETE FROM push_subscriptions WHERE id = ?', [$sub['id']]);
                $removed++;
            }
        } catch (Throwable $e) {
            // sıradaki aboneye geç
        }
    }
    return ['sent' => $sent, 'removed' => $removed, 'total' => count($subs)];
}

function pushSubCount(): int
{
    $row = dbOne('SELECT COUNT(*) AS c FROM push_subscriptions');
    return (int) ($row['c'] ?? 0);
}

/** Varsayılan bildirim yükü üretir */
function pushPayload(string $title, string $body, string $url = '/'): array
{
    return [
        'title' => $title,
        'body'  => $body,
        'url'   => $url,
        'icon'  => 'assets/img/icon-512.png',
    ];
}
