<?php
/**
 * Veritabanı bağlantı katmanı (PDO — saf PHP, kütüphanesiz)
 */

require_once __DIR__ . '/../config.php';

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
    } catch (PDOException $e) {
        http_response_code(500);
        $msg = SS_DEBUG ? $e->getMessage() : '';
        die(
            '<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>Sohbet Sokağı — Kurulum</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <style>body{font-family:system-ui,sans-serif;background:#FAF7F3;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0}
            .c{background:#fff;border:1px solid #F0E8E0;border-radius:20px;padding:32px;max-width:460px;text-align:center;box-shadow:0 10px 40px rgba(0,0,0,.06)}
            h1{font-size:20px;margin:0 0 10px}p{font-size:14px;color:#98897B;line-height:1.6}b{color:#FF5A3C}</style></head>
            <body><div class="c"><h1>Veritabanı bağlantısı kurulamadı</h1>
            <p>Lütfen <b>config.php</b> içindeki MySQL bilgilerini kontrol edin ve <b>database.sql</b> dosyasını phpMyAdmin üzerinden içe aktardığınızdan emin olun.</p>
            <p style="color:#c00;font-size:12px">' . htmlspecialchars($msg) . '</p></div></body></html>'
        );
    }
    return $pdo;
}

/** Tek satır döndürür (veya null) */
function dbOne(string $sql, array $params = []): ?array
{
    $st = db()->prepare($sql);
    $st->execute($params);
    $row = $st->fetch();
    return $row === false ? null : $row;
}

/** Tüm satırları döndürür */
function dbAll(string $sql, array $params = []): array
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

/** INSERT/UPDATE/DELETE çalıştırır, etkilenen satırı döndürür */
function dbRun(string $sql, array $params = []): int
{
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->rowCount();
}

/** Son eklenen kaydın ID'si */
function dbLastId(): string
{
    return db()->lastInsertId();
}
