<?php
/**
 * SOHBET SOKAĞI — Sunucu tarafı HTML üreteçleri
 * (Ön yüz JS'inin (assets/app.js) beklediği data-* işaretleriyle)
 */

require_once __DIR__ . '/functions.php';

/** Video gönderi kartı — akış ve profil modalında kullanılır */
function renderVideoCard(array $v, array $owner, bool $canManage): string
{
    $j = videoToJson($v);
    ob_start();
    ?>
<article id="v<?= (int)$j['id'] ?>"
  class="animate-fade-up overflow-hidden border shadow-[0_1px_2px_rgba(30,20,10,0.04)]"
  style="border-color:var(--line);background:var(--card);border-radius:var(--radius)"
  data-vcard
  data-post="<?= e(json_encode($j, JSON_UNESCAPED_UNICODE)) ?>"
  data-manage="<?= $canManage ? '1' : '0' ?>">
  <header class="flex items-center gap-3 px-4 py-3">
    <a href="<?= e(baseUrl()) ?>/profil.php" class="flex min-w-0 items-center gap-2.5">
      <span class="ring-gradient rounded-full p-[2px]">
        <img src="<?= e($owner['avatar']) ?>" alt="<?= e($owner['name']) ?>" class="h-9 w-9 rounded-full border-2 object-cover" style="border-color:var(--card)">
      </span>
      <span class="min-w-0">
        <span class="flex items-center gap-1">
          <span class="truncate text-[13.5px] font-extrabold tracking-tight"><?= e($owner['username']) ?></span>
          <?php if ($owner['verified']) echo verifiedBadge(15); ?>
          <?php if ($j['pinned']): ?>
          <span class="ml-1 inline-flex items-center gap-0.5 rounded-full px-1.5 py-0.5 text-[9.5px] font-extrabold" style="background:color-mix(in srgb, var(--accent) 10%, transparent);color:var(--accent)">
            <svg width="9" height="9" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2"><path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1z"/></svg>
            SABİTLENDİ
          </span>
          <?php endif; ?>
        </span>
        <span class="block truncate text-[11px]" style="color:var(--muted)"><?= e(timeAgo($v['created_at'])) ?> · Elbistan</span>
      </span>
    </a>
    <div class="ml-auto flex shrink-0 items-center gap-1.5">
      <a href="<?= e(baseUrl()) ?>/profil.php" class="rounded-full border px-3 py-1.5 text-[11px] font-extrabold transition" style="border-color:var(--line);background:var(--bg);color:var(--ink)">Profili Gör</a>
      <?php if ($canManage): ?>
      <div class="relative">
        <button data-vmanage class="rounded-full p-1.5 transition" style="color:var(--muted)" aria-label="Video seçenekleri">
          <svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/></svg>
        </button>
        <div data-vmenu class="animate-scale-in absolute right-0 top-9 z-30 hidden w-48 overflow-hidden rounded-2xl border py-1.5 shadow-xl" style="border-color:var(--line);background:var(--card)">
          <button data-vpin class="flex w-full items-center gap-2.5 px-4 py-2.5 text-left text-[13px] font-semibold hover:bg-[var(--bg)]">
            <?= $j['pinned'] ? 'Sabitlemeyi Kaldır' : 'Üste Sabitle' ?>
          </button>
          <button data-vedit class="flex w-full items-center gap-2.5 px-4 py-2.5 text-left text-[13px] font-semibold hover:bg-[var(--bg)]">Düzenle</button>
          <button data-vdelete class="flex w-full items-center gap-2.5 px-4 py-2.5 text-left text-[13px] font-semibold text-rose-500 hover:bg-rose-500/10">Sil</button>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </header>

  <div data-vwrap class="relative aspect-[4/5] max-h-[74vh] w-full cursor-pointer select-none overflow-hidden bg-black">
    <video data-vplayer class="video-ease h-full w-full object-cover" <?= $j['posterUrl'] ? 'poster="' . e($j['posterUrl']) . '"' : '' ?> playsinline loop muted preload="metadata"></video>
    <div data-vburst class="pointer-events-none absolute inset-0 hidden items-center justify-center">
      <svg width="110" height="110" viewBox="0 0 24 24" fill="white" stroke="white" stroke-width="1" class="animate-heart-pop drop-shadow-2xl"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
    </div>
    <div data-vflash class="pointer-events-none absolute inset-0 hidden items-center justify-center"></div>
    <div class="absolute inset-x-0 bottom-0 h-[3px] bg-white/20">
      <div data-vprogress class="h-full transition-[width] duration-150" style="width:0%;background:var(--accent)"></div>
    </div>
    <button data-vmute class="absolute bottom-4 right-3 rounded-full bg-black/50 p-2.5 text-white backdrop-blur transition hover:bg-black/70 active:scale-90" aria-label="Sesi aç/kapat">
      <svg data-icon-muted width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4V5Z"/><line x1="23" x2="17" y1="9" y2="15"/><line x1="17" x2="23" y1="9" y2="15"/></svg>
      <svg data-icon-sound class="hidden" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>
    </button>
    <div data-vplayhint class="pointer-events-none absolute inset-0 flex items-center justify-center">
      <span class="rounded-full bg-black/35 p-4 text-white/95 backdrop-blur-sm">
        <svg width="30" height="30" viewBox="0 0 24 24" fill="currentColor"><path d="M6 4.5v15l13-7.5z"/></svg>
      </span>
    </div>
  </div>

  <div class="flex items-center gap-1 px-3 pt-2.5">
    <button data-vlike class="group flex items-center gap-1.5 rounded-full px-2 py-1.5 transition active:scale-90" aria-label="Beğen">
      <svg data-vheart width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
      <span data-vlikecount class="text-[13px] font-extrabold"><?= e(formatCount($j['likes'])) ?></span>
    </button>
    <span class="flex items-center gap-1.5 rounded-full px-2 py-1.5" style="color:var(--muted)">
      <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
      <span data-vviewcount class="text-[13px] font-bold"><?= e(formatCount($j['views'])) ?></span>
    </span>
    <button data-vshare class="rounded-full px-2 py-1.5 transition active:scale-90" aria-label="Paylaş">
      <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/></svg>
    </button>
    <span class="ml-auto pr-1 text-[11px] font-semibold" style="color:var(--muted)"><?= e(fullDateTime($v['created_at'])) ?></span>
  </div>

  <?php if ($j['title'] || $j['description']): ?>
  <div class="px-4 pb-1.5 pt-1">
    <?php if ($j['title']): ?>
      <h2 class="text-[14px] font-extrabold tracking-tight"><?= e($j['title']) ?></h2>
    <?php endif; ?>
    <?php if ($j['description']): ?>
      <p data-vdesc class="mt-0.5 line-clamp-2 whitespace-pre-line text-[13px] leading-relaxed" style="color:color-mix(in srgb, var(--ink) 80%, transparent)"><?= e($j['description']) ?></p>
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <div class="flex items-center gap-1.5 px-4 pb-3.5 pt-1 text-[11.5px] font-semibold" style="color:var(--muted)">
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/><line x1="2" x2="22" y1="2" y2="22"/></svg>
    Yorumlar bu platformda kapalıdır
  </div>
</article>
    <?php
    return ob_get_clean();
}

/** Banner kartı (akış üstü / akış içi / emlak üstü) */
function renderBanner(array $b): string
{
    $external = (bool) preg_match('#^https?://#', $b['linkUrl'] ?? '');
    ob_start();
    ?>
<a href="<?= e($b['linkUrl'] ?: '#') ?>" <?= $external ? 'target="_blank" rel="noopener noreferrer"' : '' ?>
   class="group animate-fade-up relative block h-44 overflow-hidden border shadow-sm" style="border-color:var(--line);border-radius:var(--radius)">
  <img src="<?= e($b['imageUrl']) ?>" alt="<?= e($b['title']) ?>" loading="lazy" class="h-full w-full object-cover transition duration-700 group-hover:scale-105">
  <div class="absolute inset-0" style="background:linear-gradient(to top, rgba(0,0,0,.7), rgba(0,0,0,.15), transparent)"></div>
  <span class="absolute left-3 top-3 flex items-center gap-1 rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-extrabold text-neutral-800 shadow">
    <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/></svg>
    ÖNE ÇIKAN
  </span>
  <p class="absolute bottom-3 left-4 right-4 text-[15px] font-extrabold leading-snug text-white drop-shadow"><?= e($b['title']) ?></p>
</a>
    <?php
    return ob_get_clean();
}

/** Hikaye çubuğu (24 saat) */
function renderStoriesBar(array $stories, array $owner, bool $canManage): string
{
    if (count($stories) === 0) return '';
    $jsonStories = array_map('storyToJson', $stories);
    ob_start();
    ?>
<section aria-label="Hikayeler" class="border-b pb-1" style="border-color:var(--line)">
  <div class="flex items-center justify-between px-4 pt-4">
    <h2 class="text-[13px] font-extrabold tracking-tight">Hikayeler</h2>
    <span class="flex items-center gap-1 text-[10.5px] font-bold" style="color:var(--muted)">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
      24 saat sonra otomatik silinir
    </span>
  </div>
  <div class="no-scrollbar flex gap-4 overflow-x-auto px-4 py-3">
    <?php foreach ($stories as $i => $s): ?>
    <button data-story-open="<?= (int)$i ?>" class="group flex w-[74px] shrink-0 flex-col items-center gap-1.5">
      <span class="ring-gradient rounded-full p-[2.5px] transition group-hover:scale-105 group-active:scale-95">
        <span class="block h-[62px] w-[62px] overflow-hidden rounded-full border-[3px] bg-neutral-200" style="border-color:var(--bg)">
          <?php if ($s['media_type'] === 'video'): ?>
            <span class="relative flex h-full w-full items-center justify-center bg-neutral-800">
              <video src="<?= e($s['media_url']) ?>" class="absolute inset-0 h-full w-full object-cover" muted playsinline preload="metadata"></video>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="white" class="relative drop-shadow"><path d="M6 4.5v15l13-7.5z"/></svg>
            </span>
          <?php else: ?>
            <img src="<?= e($s['media_url']) ?>" alt="Hikaye <?= $i + 1 ?>" loading="lazy" class="h-full w-full object-cover">
          <?php endif; ?>
        </span>
      </span>
      <span class="w-full truncate text-center text-[10.5px] font-bold" style="color:color-mix(in srgb, var(--ink) 80%, transparent)">
        <?= $i === 0 ? e($owner['username']) : e(timeAgo($s['created_at'])) ?>
      </span>
    </button>
    <?php endforeach; ?>
  </div>
  <script>
    window.SS_STORIES = <?= json_encode($jsonStories, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
    window.SS_STORY_MANAGE = <?= $canManage ? 'true' : 'false' ?>;
  </script>
</section>
    <?php
    return ob_get_clean();
}
