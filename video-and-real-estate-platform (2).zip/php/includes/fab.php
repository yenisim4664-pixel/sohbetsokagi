<?php
/**
 * SOHBET SOKAĞI — Sahip hızlı paylaşım aracı (FAB)
 * Sadece admin oturumu veya kayıtlı sahip IP'si ile görünür.
 * includes/footer.php tarafından dahil edilir; $base mevcuttur.
 */
require_once __DIR__ . '/functions.php';
?>
<!-- Yüzen hızlı paylaşım butonu -->
<div class="fixed bottom-[86px] right-4 z-40 flex flex-col items-end gap-2.5">
  <div id="fabMenu" class="animate-fade-up hidden flex-col items-end gap-2">
    <button data-fab-open="videoModal" class="flex items-center gap-2 rounded-full border px-4 py-2.5 text-[12.5px] font-extrabold shadow-lg transition" style="border-color:var(--line);background:var(--card)">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="4"/><path d="m10 8 6 4-6 4Z"/></svg>
      Video Paylaş
    </button>
    <button data-fab-open="storyModal" class="flex items-center gap-2 rounded-full border px-4 py-2.5 text-[12.5px] font-extrabold shadow-lg transition" style="border-color:var(--line);background:var(--card)">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/><circle cx="12" cy="13" r="3"/></svg>
      Hikaye Ekle (24s)
    </button>
    <button data-fab-open="listingModal" class="flex items-center gap-2 rounded-full border px-4 py-2.5 text-[12.5px] font-extrabold shadow-lg transition" style="border-color:var(--line);background:var(--card)">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="16" height="20" x="4" y="2" rx="2"/><path d="M12 18h.01"/><path d="M8 6h.01"/><path d="M12 6h.01"/><path d="M16 6h.01"/><path d="M8 10h.01"/><path d="M12 10h.01"/><path d="M16 10h.01"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/></svg>
      Emlak İlanı Ekle
    </button>
    <a href="<?= e($base) ?>/admin/index.php" class="flex items-center gap-2 rounded-full border px-4 py-2.5 text-[12.5px] font-extrabold shadow-lg transition" style="border-color:var(--line);background:var(--card)">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1 1 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg>
      Admin Paneli
    </a>
  </div>
  <button id="fabBtn" class="flex h-14 w-14 items-center justify-center rounded-full shadow-xl transition hover:scale-105 active:scale-95" style="background:var(--accent);color:var(--accent-ink);--tw-shadow-color:var(--accent)" aria-label="Hızlı paylaşım menüsü">
    <svg id="fabIcon" width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" class="transition-transform duration-300"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
  </button>
</div>

<!-- ============ VİDEO PAYLAŞ / DÜZENLE MODALI ============ -->
<div id="videoModal" class="modal-hidden fixed inset-0 z-[90] flex items-end justify-center sm:items-center sm:p-4">
  <div class="animate-fade-in absolute inset-0 bg-black/50 backdrop-blur-sm" data-modal-close></div>
  <div class="animate-sheet-up no-scrollbar relative max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl border shadow-2xl sm:max-w-md sm:rounded-3xl" style="border-color:var(--line);background:var(--card)">
    <div class="sticky top-0 z-10 flex items-center justify-between border-b px-5 py-4 backdrop-blur" style="border-color:var(--line);background:color-mix(in srgb, var(--card) 95%, transparent)">
      <h3 id="videoModalTitle" class="text-[15px] font-extrabold tracking-tight">Yeni Video Paylaş</h3>
      <button data-modal-close class="rounded-full p-1.5 transition" style="color:var(--muted)" aria-label="Kapat">✕</button>
    </div>
    <div class="space-y-3.5 p-5">
      <input type="hidden" id="vm_id" value="">
      <label class="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-5 text-sm font-bold transition" style="border-color:var(--line);color:var(--muted)">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 14.9A7 7 0 1 1 15.7 8h1.8a4.5 4.5 0 0 1 2.5 8.2"/><path d="M12 12v9"/><path d="m8 16 4-4 4 4"/></svg>
        <span data-upload-label>Cihazdan video yükle (ffmpeg kapak üretir)</span>
        <input type="file" class="hidden" accept="video/mp4,video/webm,video/quicktime" data-upload data-upload-url="#vm_url" data-upload-poster="#vm_poster">
      </label>
      <div>
        <span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">veya Video URL (mp4 / .m3u8 HLS / CDN)</span>
        <input id="vm_url" type="text" placeholder="https://cdn.../video.mp4 veya playlist.m3u8" class="w-full rounded-xl border px-3.5 py-2.5 text-sm focus:outline-none" style="border-color:var(--line);background:var(--bg)">
      </div>
      <div>
        <span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Kapak görseli URL (opsiyonel)</span>
        <input id="vm_poster" type="text" class="w-full rounded-xl border px-3.5 py-2.5 text-sm focus:outline-none" style="border-color:var(--line);background:var(--bg)">
      </div>
      <div>
        <span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Başlık</span>
        <input id="vm_title" type="text" placeholder="Elbistan'dan bir kesit..." class="w-full rounded-xl border px-3.5 py-2.5 text-sm focus:outline-none" style="border-color:var(--line);background:var(--bg)">
      </div>
      <div>
        <span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Açıklama</span>
        <textarea id="vm_desc" rows="3" class="w-full resize-none rounded-xl border px-3.5 py-2.5 text-sm focus:outline-none" style="border-color:var(--line);background:var(--bg)"></textarea>
      </div>
      <button id="vm_pinned" data-toggle="0" class="flex w-full items-center justify-between gap-3 rounded-xl border px-3.5 py-2.5" style="border-color:var(--line);background:var(--bg)">
        <span class="text-sm font-semibold">Üste sabitle</span>
        <span data-toggle-track class="relative h-6 w-11 rounded-full transition" style="background:var(--line)"><span data-toggle-dot class="absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all"></span></span>
      </button>
      <div class="flex gap-2 pt-1">
        <button data-modal-close class="flex-1 rounded-xl border px-4 py-2.5 text-sm font-bold transition" style="border-color:var(--line)">Vazgeç</button>
        <button id="vm_submit" class="flex-1 rounded-xl px-4 py-2.5 text-sm font-bold shadow-sm transition active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">Yayınla</button>
      </div>
    </div>
  </div>
</div>

<!-- ============ HİKAYE MODALI ============ -->
<div id="storyModal" class="modal-hidden fixed inset-0 z-[90] flex items-end justify-center sm:items-center sm:p-4">
  <div class="animate-fade-in absolute inset-0 bg-black/50 backdrop-blur-sm" data-modal-close></div>
  <div class="animate-sheet-up no-scrollbar relative max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl border shadow-2xl sm:max-w-md sm:rounded-3xl" style="border-color:var(--line);background:var(--card)">
    <div class="sticky top-0 z-10 flex items-center justify-between border-b px-5 py-4" style="border-color:var(--line)">
      <h3 class="text-[15px] font-extrabold tracking-tight">Hikaye Ekle — 24 Saat</h3>
      <button data-modal-close class="rounded-full p-1.5" style="color:var(--muted)" aria-label="Kapat">✕</button>
    </div>
    <div class="space-y-3.5 p-5">
      <label class="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-5 text-sm font-bold" style="border-color:var(--line);color:var(--muted)">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 14.9A7 7 0 1 1 15.7 8h1.8a4.5 4.5 0 0 1 2.5 8.2"/><path d="M12 12v9"/><path d="m8 16 4-4 4 4"/></svg>
        <span data-upload-label>Görsel veya kısa video yükle</span>
        <input type="file" class="hidden" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm" data-upload data-upload-url="#sm_url">
      </label>
      <div>
        <span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">veya Medya URL</span>
        <input id="sm_url" type="text" placeholder="https://.../hikaye.jpg" class="w-full rounded-xl border px-3.5 py-2.5 text-sm focus:outline-none" style="border-color:var(--line);background:var(--bg)">
      </div>
      <p class="text-[11.5px] font-semibold" style="color:var(--muted)">Hikaye yayınlandıktan 24 saat sonra otomatik olarak silinir.</p>
      <div class="flex gap-2 pt-1">
        <button data-modal-close class="flex-1 rounded-xl border px-4 py-2.5 text-sm font-bold" style="border-color:var(--line)">Vazgeç</button>
        <button id="sm_submit" class="flex-1 rounded-xl px-4 py-2.5 text-sm font-bold" style="background:var(--accent);color:var(--accent-ink)">Paylaş</button>
      </div>
    </div>
  </div>
</div>

<!-- ============ EMLAK İLANI MODALI ============ -->
<div id="listingModal" class="modal-hidden fixed inset-0 z-[90] flex items-end justify-center sm:items-center sm:p-4">
  <div class="animate-fade-in absolute inset-0 bg-black/50 backdrop-blur-sm" data-modal-close></div>
  <div class="animate-sheet-up no-scrollbar relative max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl border shadow-2xl sm:max-w-xl sm:rounded-3xl" style="border-color:var(--line);background:var(--card)">
    <div class="sticky top-0 z-10 flex items-center justify-between border-b px-5 py-4" style="border-color:var(--line)">
      <h3 id="listingModalTitle" class="text-[15px] font-extrabold tracking-tight">Yeni Emlak İlanı</h3>
      <button data-modal-close class="rounded-full p-1.5" style="color:var(--muted)" aria-label="Kapat">✕</button>
    </div>
    <div class="space-y-3.5 p-5">
      <input type="hidden" id="lm_id" value="">
      <div>
        <span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">İlan Başlığı *</span>
        <input id="lm_title" type="text" placeholder="Örn: Cumhuriyet Mah. 3+1 Satılık Daire" class="w-full rounded-xl border px-3.5 py-2.5 text-sm focus:outline-none" style="border-color:var(--line);background:var(--bg)">
      </div>
      <div class="grid grid-cols-2 gap-3">
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Tür</span>
          <select id="lm_type" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"><option value="satilik">Satılık</option><option value="kiralik">Kiralık</option></select></div>
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Durum</span>
          <select id="lm_status" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"><option value="aktif">Yayında</option><option value="satildi">Satıldı</option><option value="kiralandi">Kiralandı</option></select></div>
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Fiyat (₺)</span><input id="lm_price" type="text" inputmode="numeric" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Oda Sayısı</span><input id="lm_rooms" type="text" placeholder="3+1" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Brüt m²</span><input id="lm_area" type="text" inputmode="numeric" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Kat</span><input id="lm_floor" type="text" placeholder="3. Kat" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Isıtma</span>
          <select id="lm_heating" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)">
            <?php foreach (HEATING_OPTIONS as $h): ?><option value="<?= e($h) ?>"><?= e($h) ?></option><?php endforeach; ?>
          </select></div>
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Mahalle / Konum</span>
          <select id="lm_district" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)">
            <?php foreach (DISTRICTS as $d): ?><option value="<?= e($d) ?>"><?= e($d) ?></option><?php endforeach; ?>
          </select></div>
      </div>
      <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Telefon (boş bırakılırsa profil numarası kullanılır)</span><input id="lm_phone" type="text" placeholder="905551112233" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
      <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Açıklama</span><textarea id="lm_desc" rows="3" class="w-full resize-none rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></textarea></div>
      <label class="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-4 text-sm font-bold" style="border-color:var(--line);color:var(--muted)">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 14.9A7 7 0 1 1 15.7 8h1.8a4.5 4.5 0 0 1 2.5 8.2"/><path d="M12 12v9"/><path d="m8 16 4-4 4 4"/></svg>
        <span data-upload-label>İlan fotoğrafları yükle (çoklu seçim)</span>
        <input type="file" class="hidden" accept="image/jpeg,image/png,image/webp" multiple data-upload data-upload-images="#lm_images">
      </label>
      <div id="lm_images_preview" class="flex flex-wrap gap-2"></div>
      <button id="lm_pinned" data-toggle="0" class="flex w-full items-center justify-between gap-3 rounded-xl border px-3.5 py-2.5" style="border-color:var(--line);background:var(--bg)">
        <span class="text-sm font-semibold">Üste sabitle</span>
        <span data-toggle-track class="relative h-6 w-11 rounded-full transition" style="background:var(--line)"><span data-toggle-dot class="absolute left-0.5 top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all"></span></span>
      </button>
      <div class="flex gap-2 pt-1">
        <button data-modal-close class="flex-1 rounded-xl border px-4 py-2.5 text-sm font-bold" style="border-color:var(--line)">Vazgeç</button>
        <button id="lm_submit" class="flex-1 rounded-xl px-4 py-2.5 text-sm font-bold" style="background:var(--accent);color:var(--accent-ink)">İlanı Yayınla</button>
      </div>
    </div>
  </div>
</div>
