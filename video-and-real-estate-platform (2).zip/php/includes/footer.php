<?php
/**
 * SOHBET SOKAĞI — Sayfa sonu (footer + alt navigasyon + sahip araçları)
 * header.php içinden gelen: $S, $owner, $visitStats, $active, $CAN, $base
 */
require_once __DIR__ . '/functions.php';
?>
</main>
<footer class="border-t pb-28 pt-8" style="border-color:var(--line)">
  <div class="mx-auto flex max-w-[520px] flex-col items-center gap-2 px-4 text-center">
    <p class="text-[14px] font-extrabold tracking-tight"><?= e($S['siteName']) ?></p>
    <p class="flex items-center gap-1 text-[11.5px] font-bold" style="color:var(--muted)">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>
      Elbistan / Kahramanmaraş
    </p>
    <nav class="mt-1 flex gap-4 text-[12px] font-bold" style="color:var(--muted)">
      <a href="<?= e($base) ?>/index.php" class="hover:text-[var(--accent)]">Akış</a>
      <a href="<?= e($base) ?>/emlak.php" class="hover:text-[var(--accent)]">Emlak</a>
      <a href="<?= e($base) ?>/profil.php" class="hover:text-[var(--accent)]">Profil</a>
    </nav>
    <p class="mt-2 flex items-center gap-1.5 rounded-full border px-3.5 py-1.5 text-[10.5px] font-extrabold" style="border-color:var(--line);background:var(--card);color:var(--muted)">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
      Bugün <?= number_format((int)$visitStats['u'], 0, ',', '.') ?> tekil ziyaretçi · <?= number_format((int)$visitStats['c'], 0, ',', '.') ?> gezinme
    </p>
    <p class="mt-2 text-[10.5px] font-semibold" style="color:var(--muted)"><?= e($S['footerText']) ?></p>
  </div>
</footer>

<?php
$navItems = [
    ['home', 'index.php', 'Akış', '<rect width="18" height="18" x="3" y="3" rx="4"/><path d="m10 8 6 4-6 4Z"/>'],
    ['emlak', 'emlak.php', 'Emlak', '<rect width="16" height="20" x="4" y="2" rx="2"/><path d="M12 18h.01"/><path d="M8 6h.01"/><path d="M12 6h.01"/><path d="M16 6h.01"/><path d="M8 10h.01"/><path d="M12 10h.01"/><path d="M16 10h.01"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/>'],
    ['profil', 'profil.php', 'Profil', '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>'],
];
?>
<nav class="pb-safe pointer-events-none fixed inset-x-0 bottom-0 z-40">
  <div class="flex justify-center pb-3">
    <div class="pointer-events-auto flex items-center gap-1 rounded-full border p-1.5 shadow-xl shadow-black/10 backdrop-blur-xl" style="border-color:var(--line);background:color-mix(in srgb, var(--card) 95%, transparent)">
      <?php foreach ($navItems as [$key, $href, $label, $icon]): $isActive = ($active === $key); ?>
      <a href="<?= e($base) ?>/<?= e($href) ?>"
         class="flex items-center gap-1.5 rounded-full px-4 sm:px-5 py-2 text-[12px] font-extrabold transition active:scale-95 <?= $isActive ? 'shadow-sm' : '' ?>"
         style="<?= $isActive ? 'background:var(--ink);color:var(--bg)' : 'color:var(--muted)' ?>">
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="<?= $isActive ? '2.6' : '2' ?>" stroke-linecap="round" stroke-linejoin="round"><?= $icon ?></svg>
        <?= e($label) ?>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</nav>

<?php if ($CAN): require __DIR__ . '/fab.php'; endif; ?>

<script>
window.SS = <?= json_encode([
    'base' => $base,
    'canManage' => $CAN,
    'siteName' => $S['siteName'],
    'owner' => [
        'name' => $owner['name'],
        'username' => $owner['username'],
        'avatar' => $owner['avatar'],
        'verified' => (bool)$owner['verified'],
    ],
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
</script>
<script src="<?= e($base) ?>/assets/app.js" defer></script>
</div>
</body>
</html>
