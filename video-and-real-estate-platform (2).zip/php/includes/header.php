<?php
/**
 * SOHBET SOKAĞI — Sayfa başı (SEO meta + tema + üst bar)
 * Beklenen değişkenler:
 *   $PAGE_TITLE       string  Sayfa başlığı
 *   $PAGE_DESCRIPTION string  Sayfa açıklaması
 *   $PAGE_ACTIVE      string  'home' | 'emlak' | 'profil'
 *   $PAGE_JSONLD      array   JSON-LD blokları (opsiyonel)
 *   $PAGE_OG_IMAGE    string  OG görseli (opsiyonel)
 */

require_once __DIR__ . '/functions.php';

$S = siteData();
$theme = $S['theme'];
$owner = $S['owner'];
$seo = $S['seo'];
$base = baseUrl();
$ip = clientIp();

// Yasaklı IP kontrolü (admin sayfaları bu dosyayı kullanmaz)
if (isBanned($ip)) {
    http_response_code(403);
    ?><!doctype html><html lang="tr"><head><meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>Erişim Kısıtlandı — <?= e($S['siteName']) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="<?= e($base) ?>/assets/site.css"></head>
    <body class="min-h-dvh" style="<?= themeStyle(DEFAULT_THEME) ?>background:var(--bg);color:var(--ink)">
    <div class="flex min-h-dvh flex-col items-center justify-center px-6 text-center">
      <span class="rounded-full bg-rose-500/10 p-5 text-rose-500">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1 1 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m4.243 5.21 14.39 12.472"/></svg>
      </span>
      <h1 class="mt-4 text-xl font-extrabold tracking-tight">Erişiminiz Kısıtlandı</h1>
      <p class="mt-2 max-w-sm text-sm font-medium" style="color:var(--muted)">Bu siteye erişiminiz yönetici tarafından engellenmiştir. Bir hata olduğunu düşünüyorsanız bizimle iletişime geçebilirsiniz.</p>
      <a href="<?= e(waLink($owner['whatsapp'], 'Merhaba, site erişimim hakkında bilgi almak istiyorum.')) ?>" class="mt-5 rounded-full px-5 py-2.5 text-sm font-bold" style="background:var(--accent);color:var(--accent-ink)">İletişime Geç</a>
    </div></body></html><?php
    exit;
}

// Ziyaretçi kaydı (sayfa görüntüleme)
recordVisit($ip, $_SERVER['REQUEST_URI'] ?? '/', $_SERVER['HTTP_USER_AGENT'] ?? '');

$pageTitle = $PAGE_TITLE ?? $seo['title'];
$pageDesc = $PAGE_DESCRIPTION ?? $seo['description'];
$ogImage = $PAGE_OG_IMAGE ?? $seo['ogImage'];
$active = $PAGE_ACTIVE ?? 'home';
$CAN = canManage();

// Ziyaretçi sayaçları (footer için)
$visitStats = dbOne(
    "SELECT COUNT(*) AS c, COUNT(DISTINCT ip) AS u
     FROM visits WHERE created_at >= CURDATE()"
) ?: ['c' => 0, 'u' => 0];

$orgJsonLd = [
    '@context' => 'https://schema.org',
    '@type' => 'Organization',
    'name' => $S['siteName'],
    'description' => $seo['description'],
    'logo' => $ogImage,
    'sameAs' => array_filter([$owner['instagram']]),
    'address' => [
        '@type' => 'PostalAddress',
        'addressLocality' => 'Elbistan',
        'addressRegion' => 'Kahramanmaraş',
        'addressCountry' => 'TR',
    ],
];
?><!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title><?= e($pageTitle) ?></title>
<meta name="description" content="<?= e($pageDesc) ?>">
<meta name="keywords" content="<?= e($seo['keywords']) ?>">
<meta name="robots" content="index, follow">
<meta name="theme-color" content="<?= e($theme['accent']) ?>">
<meta name="application-name" content="<?= e($S['siteName']) ?>">
<link rel="icon" href="<?= e($base) ?>/assets/img/icon-512.png">
<link rel="apple-touch-icon" href="<?= e($base) ?>/assets/img/icon-512.png">
<link rel="manifest" href="<?= e($base) ?>/manifest.json">
<link rel="sitemap" type="application/xml" href="<?= e($base) ?>/sitemap.php">
<meta property="og:type" content="website">
<meta property="og:locale" content="tr_TR">
<meta property="og:site_name" content="<?= e($S['siteName']) ?>">
<meta property="og:title" content="<?= e($pageTitle) ?>">
<meta property="og:description" content="<?= e($pageDesc) ?>">
<meta property="og:image" content="<?= e($ogImage) ?>">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?= e($pageTitle) ?>">
<meta name="twitter:description" content="<?= e($pageDesc) ?>">
<meta name="twitter:image" content="<?= e($ogImage) ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/hls.js@1"></script>
<link rel="stylesheet" href="<?= e($base) ?>/assets/site.css">
<script type="application/ld+json"><?= json_encode($orgJsonLd, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?></script>
<?php if (!empty($PAGE_JSONLD)): foreach ($PAGE_JSONLD as $block): ?>
<script type="application/ld+json"><?= json_encode($block, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?></script>
<?php endforeach; endif; ?>
</head>
<body style="<?= themeStyle($theme) ?>">
<div class="min-h-dvh" style="background:var(--bg);color:var(--ink)">
<header class="sticky top-0 z-40 border-b backdrop-blur-xl" style="border-color:var(--line);background:color-mix(in srgb, var(--bg) 85%, transparent)">
  <div class="mx-auto flex h-[60px] max-w-[520px] items-center justify-between gap-3 px-4">
    <a href="<?= e($base) ?>/index.php" class="flex min-w-0 items-center gap-2.5" aria-label="<?= e($S['siteName']) ?> ana sayfa">
      <?php if ($S['logoUrl']): ?>
        <img src="<?= e($S['logoUrl']) ?>" alt="<?= e($S['siteName']) ?>" class="h-10 w-10 rounded-xl object-cover shadow-sm">
      <?php else: ?>
        <div class="ring-gradient flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-[13px] font-extrabold tracking-tight text-white shadow-md">SS</div>
      <?php endif; ?>
      <div class="min-w-0">
        <div class="truncate text-[16px] font-extrabold leading-tight tracking-tight"><?= e($S['siteName']) ?></div>
        <div class="-mt-0.5 truncate text-[10.5px] font-medium" style="color:var(--muted)"><?= e($S['tagline']) ?></div>
      </div>
    </a>
    <div class="flex shrink-0 items-center gap-2">
      <button id="pushBell" class="rounded-full p-2.5 transition active:scale-90" style="color:var(--muted)" aria-label="Bildirimleri aç" title="Yeni videolardan anında haberdar ol">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>
      </button>
      <a href="<?= e($base) ?>/emlak.php" class="flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[12px] font-extrabold shadow-md transition hover:opacity-90 active:scale-95" style="background:var(--accent);color:var(--accent-ink)">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="16" height="20" x="4" y="2" rx="2"/><path d="M12 18h.01"/><path d="M8 6h.01"/><path d="M12 6h.01"/><path d="M16 6h.01"/><path d="M8 10h.01"/><path d="M12 10h.01"/><path d="M16 10h.01"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/></svg>
        <span class="hidden sm:inline">Sohbet Sokağı</span> Emlak
      </a>
    </div>
  </div>
</header>
<main class="pb-32">
