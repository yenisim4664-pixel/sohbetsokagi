# SOHBET SOKAĞI — Saf PHP + MySQL Sürümü

Elbistan merkezli, Instagram tarzı **video akışı ve emlak platformu**.
Backend %100 saf PHP'dir — **harici hiçbir PHP kütüphanesi/composer paketi kullanılmaz.**
Kullanıcı girişi/kaydı **yoktur**; herkes tüm içeriği anında görüntüleyebilir.

---

## Özellikler

| Alan | İçerik |
|---|---|
| **Video Akışı** | Instagram tarzı sonsuz kaydırma, otomatik oynatma, çift dokun beğeni, HLS (.m3u8) / MP4 desteği, lazy loading + sanal kaydırma (uzak videolar bellekten boşaltılır), donmasız oynatma |
| **Gönderi Kartı** | Sahip profil fotoğrafı + isim + **mavi tik** + **"Profili Gör"** butonu, beğeni & görüntülenme sayısı, paylaşım tarihi+saati. **Yorumlar kapalıdır.** |
| **Hikayeler** | 24 saat sonra **otomatik silinen** hikayeler (tam ekran görüntüleyici, ilerleme çubuğu) |
| **Emlak Modülü** | Satılık / Kiralık / Satıldı / Kiralandı etiketleri, fiyatlandırma, arama + filtre, fotoğraf karuseli, detay sayfası, WhatsApp/Ara butonları |
| **Push Bildirim** | **Saf PHP ile yazılmış** Web Push motoru (VAPID + aes128gcm, openssl). Yeni videoda abonelere otomatik bildirim |
| **Admin Paneli** | 9 sekme: Genel Bakış (istatistik + ziyaretçi sayacı + şüpheli IP), Videolar, Hikayeler, **Emlak Admini**, Bannerlar, **Görünüm** (tema/renk/logo/footer), Profil & İletişim, **SEO**, **Güvenlik** (IP ban, sahip IP, şifre) |
| **Sahip IP** | IP'nizi kaydedin → panele girmeden sitedeki **+ butonuyla** video/hikaye/ilan paylaşın |
| **FFmpeg** | Sunucuda ffmpeg varsa yüklenen videolara otomatik kapak karesi üretir (yoksa sorunsuz atlanır) |
| **SEO** | JSON-LD (VideoObject, RealEstateListing, ProfilePage), dinamik sitemap.php, robots.txt, manifest, düzenlenebilir meta etiketler |
| **Güvenlik** | Ziyaretçi takibi, şüpheli IP tespiti (6 saatte 120+ istek), IP banlama, oturum bazlı giriş denemesi sınırlama |

---

## Kurulum (5 dakika)

### 1. Gereksinimler
- PHP **7.4+** (8.x önerilir), MySQL **5.7+** / MariaDB 10.3+
- `openssl` PHP eklentisi (push bildirimleri için)
- `ffmpeg` (opsiyonel — video kapakları için)
- **HTTPS** (Web Push bildirimleri tarayıcı gereği HTTPS ister)

### 2. Dosyaları yükleyin
`php/` klasörünün **içeriğini** hostinginizin public klasörüne (örn. `public_html/`) atın:

```
public_html/
├── index.php          ← ana akış
├── emlak.php          ← emlak modülü
├── profil.php         ← sahip profili
├── sitemap.php
├── robots.txt
├── manifest.json
├── database.sql
├── config.php
├── .htaccess
├── admin/             ← yönetim paneli (/admin)
├── api/               ← JSON API uçları
├── includes/          ← çekirdek (web erişimine kapalı)
├── assets/            ← css/js/sw/img
└── uploads/           ← yüklenen medyalar (yazılabilir olmalı!)
```

### 3. Veritabanını oluşturun
1. phpMyAdmin → hesabınızda yeni bir isim boşluğu açmadan direkt **İçe Aktar** sekmesinden
   `database.sql` dosyasını seçin → **Git**.
   (Dosya `sohbet_sokagi` veritabanını, tüm tabloları ve örnek içeriği kendisi oluşturur.)
2. `config.php` dosyasını açın ve bilgilerinizi girin:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'sohbet_sokagi');
define('DB_USER', 'KULLANICI_ADINIZ');
define('DB_PASS', 'SIFRENIZ');
define('SESSION_SECRET', 'rastgele-uzun-bir-deger-yazin');
```

> cPanel kullanıyorsanız: **MySQL Veritabanları** bölümünden veritabanı + kullanıcı oluşturup
> kullanıcıyı veritabanına tüm yetkilerle ekleyin, sonra dosyaları içe aktarın.

### 4. Yazma izinleri
```bash
chmod -R 775 uploads
```

### 5. İlk giriş
- Site: `https://alanadiniz.com/`
- Admin: `https://alanadiniz.com/admin/` → **varsayılan şifre: `admin123`**
- **İlk iş:** Admin → Güvenlik → şifrenizi değiştirin.
- **İkinci iş:** Güvenlik → "Bu Cihazı Sahip Olarak Kaydet" → artık site içinden
  (+ butonu ile) panele girmeden paylaşım yapabilirsiniz.

---

## Kullanım Notları

**Videolar** — Admin → Videolar → Yeni Video. Dosya yükleyebilir (sunucunuzda saklanır,
ffmpeg varsa kapak otomatik üretilir) veya doğrudan URL verebilirsiniz.
**Donma olmaması için öneri:** videoları CDN'de barındırın veya HLS (`.m3u8`) kullanın —
oynatıcı her iki biçimi de otomatik algılar.

**HLS için ffmpeg komutu (kendi sunucunuzda):**
```bash
ffmpeg -i video.mp4 -codec: copy -start_number 0 -hls_time 6 -hls_list_size 0 -f hls video.m3u8
```
Oluşan `video.m3u8` + `.ts` dosyalarını `uploads/` içine atıp URL olarak `uploads/video.m3u8` verin.

**Hikayeler** — Yayına alındıktan 24 saat sonra otomatik silinir (ek silme işine gerek yok; ilk okumada temizlenir).

**Bannerlar** — Admin → Bannerlar. Üç konum: Akış üstü, Akış içi (her 3 gönderide bir), Emlak üstü.

**Push Bildirim** — Ziyaretçi zil ikonuna basıp izin verir → abone olur. Yeni video
paylaştığınızda tüm abonelere otomatik bildirim gider (Güvenlik sekmesinden kapatılabilir,
oradan test bildirimi de gönderebilirsiniz).

**Tema** — Admin → Görünüm: 5 hazır tema + tüm renkler + köşe yuvarlaklığı + logo/site adı/slogan/footer.

**Ziyaretçi takibi** — Tüm sayfalar sunucu tarafında kaydedilir. Şüpheli IP'ler
(6 saatte 120+ istek) Genel Bakış'ta listelenir, tek tıkla yasaklanır.

---

## Dosya Haritası

| Dosya | Görev |
|---|---|
| `config.php` | **Tek düzenlemeniz gereken dosya** (DB + gizli anahtar) |
| `includes/db.php` | PDO bağlantı katmanı |
| `includes/functions.php` | Ayarlar, yetki, IP, biçimlendirme, JSON dönüşümleri |
| `includes/webpush.php` | Saf PHP Web Push motoru (VAPID/aes128gcm — kütüphanesiz) |
| `includes/header.php` `footer.php` | Site iskeleti (SEO meta, tema, üst/alt bar) |
| `includes/render.php` | Video kartı, hikaye çubuğu, banner üreteçleri |
| `includes/fab.php` | Sahip hızlı paylaşım araçları |
| `api/*.php` | Tüm JSON uçları (videos, stories, listings, engage, upload, push, admin) |
| `admin/index.php` | 9 sekmeli yönetim paneli |
| `assets/app.js` | Ön yüz motoru (oynatıcı, hikayeler, sonsuz kaydırma, push, emlak) |
| `assets/sw.js` | Push servis çalışanı |
| `assets/site.css` | Animasyonlar + tema köprüsü |
| `database.sql` | MySQL şema + örnek içerik |

---

## Sorun Giderme

- **"Veritabanı bağlantısı kurulamadı"** → `config.php` bilgilerini ve `database.sql` içe aktarımını kontrol edin.
- **Yükleme çalışmıyor** → `uploads/` klasörü yazılabilir mi? (chmod 775). PHP limitleri `.htaccess` içinde 150MB olarak ayarlı (sunucu izin veriyorsa).
- **Push gitmiyor** → HTTPS şart. `openssl` eklentisi aktif olmalı. Bildirim izni tarayıcıda verilmiş olmalı.
- **Beyaz sayfa** → `config.php` içinde `SS_DEBUG` değerini `1` yapıp hatayı görün.

© Sohbet Sokağı — Elbistan
