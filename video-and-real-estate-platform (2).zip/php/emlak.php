<?php
/**
 * SOHBET SOKAĞI — Emlak modülü
 */
require_once __DIR__ . '/includes/render.php';

$S = siteData();
$rows = dbAll('SELECT * FROM listings ORDER BY pinned DESC, created_at DESC LIMIT 200');
$listings = array_map('listingToJson', $rows);
$activeCount = count(array_filter($listings, function ($l) { return $l['status'] === 'aktif'; }));
$emlakBanners = array_values(array_filter($S['banners'], function ($b) {
    return !empty($b['active']) && ($b['position'] ?? '') === 'emlak-top';
}));

$PAGE_TITLE = 'Emlak İlanları — Elbistan Satılık & Kiralık | ' . $S['siteName'];
$PAGE_DESCRIPTION = "Sohbet Sokağı Emlak: Elbistan'da satılık daire, kiralık ev, dükkan ve müstakil ev ilanları. Güncel fiyatlar, mahalle bazlı arama, WhatsApp ile anında iletişim.";
$PAGE_ACTIVE = 'emlak';
$PAGE_JSONLD = [
    [
        '@context' => 'https://schema.org',
        '@type' => 'RealEstateAgent',
        'name' => $S['siteName'] . ' Emlak',
        'description' => 'Elbistan merkezli emlak danışmanlığı — satılık ve kiralık ilanlar.',
        'areaServed' => 'Elbistan, Kahramanmaraş',
        'telephone' => '+' . $S['owner']['whatsapp'],
        'address' => [
            '@type' => 'PostalAddress',
            'addressLocality' => 'Elbistan',
            'addressRegion' => 'Kahramanmaraş',
            'addressCountry' => 'TR',
        ],
    ],
    [
        '@context' => 'https://schema.org',
        '@type' => 'ItemList',
        'itemListElement' => array_map(function ($l, $i) {
            return [
                '@type' => 'ListItem',
                'position' => $i + 1,
                'item' => array_filter([
                    '@type' => 'RealEstateListing',
                    'name' => $l['title'],
                    'description' => $l['description'],
                    'image' => $l['images'][0] ?? null,
                    'datePosted' => $l['createdAt'],
                ]),
            ];
        }, array_slice($listings, 0, 20), array_keys(array_slice($listings, 0, 20))),
    ],
];

require __DIR__ . '/includes/header.php';

$statusStyles = ['satildi' => 'background:#dc2626;color:#fff', 'kiralandi' => 'background:#f59e0b;color:#fff'];
?>
<div class="mx-auto w-full max-w-[700px]">
  <h1 class="sr-only">Elbistan Emlak İlanları — Satılık ve Kiralık | <?= e($S['siteName']) ?> Emlak</h1>
  <div id="emlakApp" class="flex flex-col gap-5 px-4 pt-4">

    <!-- Danışman kartı -->
    <section class="overflow-hidden border p-5" style="border-color:var(--line);background:var(--card);border-radius:var(--radius)" aria-label="Emlak danışmanı">
      <div class="flex items-center gap-3.5">
        <span class="ring-gradient rounded-full p-[3px]">
          <img src="<?= e($owner['avatar']) ?>" alt="<?= e($owner['name']) ?>" class="h-16 w-16 rounded-full border-[3px] object-cover" style="border-color:var(--card)">
        </span>
        <div class="min-w-0">
          <h2 class="flex items-center gap-1.5 text-[17px] font-extrabold tracking-tight">
            <?= e($owner['name']) ?> Emlak
            <?php if ($owner['verified']) echo verifiedBadge(17); ?>
          </h2>
          <p class="text-[12px] font-semibold" style="color:var(--muted)">Elbistan'ın güvenilir emlak danışmanı · <?= (int)$activeCount ?> aktif ilan</p>
        </div>
      </div>
      <div class="mt-4 grid grid-cols-3 gap-2">
        <a href="<?= e(waLink($owner['whatsapp'], 'Merhaba, emlak ilanlarınız hakkında bilgi almak istiyorum.')) ?>" target="_blank" rel="noopener" class="flex items-center justify-center gap-1.5 rounded-xl bg-[#25D366] px-2 py-2.5 text-[12px] font-extrabold text-white shadow-sm transition hover:opacity-90 active:scale-[.98]">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/></svg>
          WhatsApp
        </a>
        <a href="<?= e($owner['instagram']) ?>" target="_blank" rel="noopener" class="flex items-center justify-center gap-1.5 rounded-xl border px-2 py-2.5 text-[12px] font-extrabold transition active:scale-[.98]" style="border-color:var(--line);background:var(--bg)">
          <?= instagramIcon(15) ?> Instagram
        </a>
        <a href="<?= e(waLink($owner['whatsapp'], 'Merhaba, Sohbet Sokağı üzerinden reklam ve iş birliği için ulaşıyorum.')) ?>" target="_blank" rel="noopener" class="flex items-center justify-center gap-1.5 rounded-xl px-2 py-2.5 text-[12px] font-extrabold shadow-sm transition hover:opacity-90 active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/></svg>
          Reklam
        </a>
      </div>
    </section>

    <!-- Emlak bannerları -->
    <?php foreach ($emlakBanners as $b): ?>
    <a href="<?= e($b['linkUrl'] ?: '#') ?>" <?= preg_match('#^https?://#', $b['linkUrl'] ?? '') ? 'target="_blank" rel="noopener"' : '' ?> class="group relative block h-36 overflow-hidden border" style="border-color:var(--line);border-radius:var(--radius)">
      <img src="<?= e($b['imageUrl']) ?>" alt="<?= e($b['title']) ?>" loading="lazy" class="h-full w-full object-cover transition duration-700 group-hover:scale-105">
      <div class="absolute inset-0" style="background:linear-gradient(to top, rgba(0,0,0,.65), transparent)"></div>
      <p class="absolute bottom-3 left-4 right-4 text-[14px] font-extrabold text-white drop-shadow"><?= e($b['title']) ?></p>
    </a>
    <?php endforeach; ?>

    <!-- Arama + filtre -->
    <div class="sticky top-[60px] z-30 -mx-4 space-y-2.5 px-4 py-3 backdrop-blur-xl" style="background:color-mix(in srgb, var(--bg) 90%, transparent)">
      <div class="relative">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2" style="color:var(--muted)"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
        <input id="emlakSearch" type="text" placeholder="Mahalle, oda sayısı veya başlık ara..." class="w-full rounded-full border py-2.5 pl-10 pr-4 text-[13px] font-semibold focus:outline-none" style="border-color:var(--line);background:var(--card)">
      </div>
      <div class="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-0.5">
        <?php
        $filters = ['all' => 'Tümü', 'satilik' => 'Satılık', 'kiralik' => 'Kiralık', 'satildi' => 'Satıldı', 'kiralandi' => 'Kiralandı'];
        foreach ($filters as $fid => $flabel):
            $on = $fid === 'all';
            ?>
        <button data-emlak-filter="<?= e($fid) ?>" class="shrink-0 rounded-full border px-4 py-2 text-[12px] font-extrabold transition active:scale-95"
          style="<?= $on ? 'background:var(--ink);color:var(--bg);border-color:var(--ink)' : 'background:var(--card);color:var(--muted);border-color:var(--line)' ?>">
          <?= e($flabel) ?>
        </button>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- İlan listesi -->
    <section class="grid grid-cols-1 gap-4 sm:grid-cols-2" aria-label="Emlak ilanları">
      <?php foreach ($listings as $l): ?>
      <article data-listing-card="<?= (int)$l['id'] ?>"
               data-type="<?= e($l['type']) ?>" data-status="<?= e($l['status']) ?>"
               data-hay="<?= e($l['title'] . ' ' . $l['district'] . ' ' . $l['rooms']) ?>"
               class="group cursor-pointer overflow-hidden border shadow-[0_1px_2px_rgba(30,20,10,0.04)] transition hover:-translate-y-0.5 hover:shadow-lg"
               style="border-color:var(--line);background:var(--card);border-radius:var(--radius)">
        <div class="relative" <?= count($l['images']) > 1 ? 'data-carousel="' . e(implode('|', $l['images'])) . '"' : '' ?>>
          <div class="relative h-52 overflow-hidden bg-neutral-200">
            <?php if ($l['images']): ?>
              <img src="<?= e($l['images'][0]) ?>" alt="<?= e($l['title']) ?>" loading="lazy" class="h-full w-full object-cover">
            <?php else: ?>
              <div class="flex h-full items-center justify-center" style="color:var(--muted)">
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21 2-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0 3 3L22 7l-3-3m-3.5 3.5L19 4"/></svg>
              </div>
            <?php endif; ?>
            <?php if (count($l['images']) > 1): ?>
              <button data-car-prev class="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-black/45 p-1.5 text-white backdrop-blur transition hover:bg-black/65" aria-label="Önceki"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m15 18-6-6 6-6"/></svg></button>
              <button data-car-next class="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-black/45 p-1.5 text-white backdrop-blur transition hover:bg-black/65" aria-label="Sonraki"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 18 6-6-6-6"/></svg></button>
              <div class="absolute bottom-2 left-1/2 flex -translate-x-1/2 gap-1">
                <?php foreach ($l['images'] as $di => $_): ?><span data-dot class="h-1.5 rounded-full <?= $di === 0 ? 'w-4 bg-white' : 'w-1.5 bg-white/50' ?>"></span><?php endforeach; ?>
              </div>
            <?php endif; ?>
          </div>
          <div class="pointer-events-none absolute left-2.5 top-2.5 flex gap-1.5">
            <span class="rounded-full px-2.5 py-1 text-[10px] font-extrabold shadow" style="<?= $l['type'] === 'kiralik' ? 'background:#0284c7;color:#fff' : 'background:rgba(255,255,255,.95);color:#171717' ?>">
              <?= $l['type'] === 'kiralik' ? 'KİRALIK' : 'SATILIK' ?>
            </span>
            <?php if ($l['status'] !== 'aktif'): ?>
            <span class="rounded-full px-2.5 py-1 text-[10px] font-extrabold shadow" style="<?= $statusStyles[$l['status']] ?>">
              <?= e(mb_strtoupper(LISTING_STATUS_LABELS[$l['status']])) ?>
            </span>
            <?php endif; ?>
          </div>
          <?php if ($l['pinned']): ?>
          <span class="absolute right-2.5 top-2.5 rounded-full p-1.5 shadow" style="background:var(--accent);color:var(--accent-ink)">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1z"/></svg>
          </span>
          <?php endif; ?>
        </div>
        <div class="p-4">
          <div class="flex items-baseline justify-between gap-2">
            <p class="text-[17px] font-extrabold tracking-tight" style="color:var(--accent)"><?= e(formatPrice($l['price'], $l['type'])) ?></p>
            <span class="flex items-center gap-1 text-[10.5px] font-bold" style="color:var(--muted)">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
              <?= e(formatCount($l['views'])) ?>
            </span>
          </div>
          <h2 class="mt-0.5 line-clamp-1 text-[13.5px] font-extrabold tracking-tight"><?= e($l['title']) ?></h2>
          <div class="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] font-bold" style="color:var(--muted)">
            <?php if ($l['rooms']): ?><span class="flex items-center gap-1"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8"/><path d="M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4"/><path d="M12 4v6"/><path d="M2 18h20"/></svg> <?= e($l['rooms']) ?></span><?php endif; ?>
            <?php if ($l['area'] > 0): ?><span class="flex items-center gap-1"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21.3 15.3a2.4 2.4 0 0 1 0 3.4l-2.6 2.6a2.4 2.4 0 0 1-3.4 0L2.7 8.7a2.41 2.41 0 0 1 0-3.4l2.6-2.6a2.41 2.41 0 0 1 3.4 0Z"/><path d="m14.5 12.5 2-2"/><path d="m11.5 9.5 2-2"/><path d="m8.5 6.5 2-2"/><path d="m17.5 15.5 2-2"/></svg> <?= (int)$l['area'] ?> m²</span><?php endif; ?>
            <?php if ($l['district']): ?><span class="flex items-center gap-1"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg> <?= e($l['district']) ?></span><?php endif; ?>
          </div>
          <p class="mt-2.5 border-t pt-2 text-[10.5px] font-semibold" style="border-color:var(--line);color:var(--muted)"><?= e(timeAgo($l['createdAt'])) ?> · İlan №<?= (int)$l['id'] ?></p>
        </div>
      </article>
      <?php endforeach; ?>
    </section>
    <p id="emlakEmpty" style="display:<?= count($listings) ? 'none' : '' ?>" class="py-14 text-center text-sm font-semibold" >Bu kriterlere uygun ilan bulunamadı.</p>
  </div>
</div>
<script>
window.SS_LISTINGS = <?= json_encode(array_values($listings), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
window.SS_OWNER_PHONE = <?= json_encode($owner['whatsapp']) ?>;
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
