<?php
/**
 * SOHBET SOKAĞI — Ana sayfa (video akışı)
 */
require_once __DIR__ . '/includes/render.php';

$S = siteData();
$stories = activeStories();
$videos = dbAll('SELECT * FROM videos ORDER BY pinned DESC, created_at DESC LIMIT 4');
$jsonVideos = array_map('videoToJson', $videos);

$activeBanners = array_values(array_filter($S['banners'], function ($b) {
    return !empty($b['active']);
}));
$topBanners = array_values(array_filter($activeBanners, function ($b) {
    return ($b['position'] ?? '') === 'feed-top';
}));
$inlineBanners = array_values(array_filter($activeBanners, function ($b) {
    return ($b['position'] ?? '') === 'feed-inline';
}));

$PAGE_TITLE = $S['seo']['title'];
$PAGE_DESCRIPTION = $S['seo']['description'];
$PAGE_ACTIVE = 'home';
$PAGE_JSONLD = [[
    '@context' => 'https://schema.org',
    '@type' => 'ItemList',
    'itemListElement' => array_map(function ($v, $i) use ($S) {
        return [
            '@type' => 'ListItem',
            'position' => $i + 1,
            'item' => array_filter([
                '@type' => 'VideoObject',
                'name' => $v['title'] ?: 'Sohbet Sokağı videosu',
                'description' => $v['description'] ?: $v['title'],
                'thumbnailUrl' => $v['posterUrl'] ?: null,
                'uploadDate' => $v['createdAt'],
                'contentUrl' => $v['videoUrl'],
                'interactionStatistic' => [
                    ['@type' => 'InteractionCounter', 'interactionType' => ['@type' => 'WatchAction'], 'userInteractionCount' => $v['views']],
                    ['@type' => 'InteractionCounter', 'interactionType' => ['@type' => 'LikeAction'], 'userInteractionCount' => $v['likes']],
                ],
                'author' => ['@type' => 'Person', 'name' => $S['owner']['name']],
            ]),
        ];
    }, $jsonVideos, array_keys($jsonVideos)),
]];

require __DIR__ . '/includes/header.php';
?>
<div class="mx-auto w-full max-w-[480px]">
  <h1 class="sr-only"><?= e($S['seo']['title']) ?></h1>

  <?= renderStoriesBar($stories, $owner, $CAN) ?>

  <?php if ($topBanners): ?>
  <div class="flex flex-col gap-4 px-4 pt-4">
    <?php foreach ($topBanners as $b) echo renderBanner($b); ?>
  </div>
  <?php endif; ?>

  <div class="px-4 pt-5">
    <div id="videoFeed" class="flex flex-col gap-5">
      <?php
      foreach ($videos as $i => $v) {
          // Akış içi banner: 3. gönderiden sonra (React sürümüyle aynı kural)
          if ($inlineBanners && $i > 0 && $i % 3 === 0) {
              echo renderBanner($inlineBanners[(int)(($i / 3) - 1) % count($inlineBanners)]);
          }
          echo renderVideoCard($v, $owner, $CAN);
      }
      if (count($videos) === 0) {
          echo '<p class="py-12 text-center text-sm font-semibold" style="color:var(--muted)">Henüz video paylaşılmadı.</p>';
      }
      ?>
    </div>
    <div id="feedSentinel" data-offset="4" class="h-1"></div>
    <div id="feedLoading" class="hidden justify-center py-6" style="color:var(--muted)">
      <svg class="animate-spin" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M21 12a9 9 0 1 1-6.219-8.56"/></svg>
    </div>
    <p id="feedEnd" style="display:none" class="py-6 text-center text-[12px] font-bold" >Sohbet Sokağı'nın sonuna geldiniz — yenileri için takipte kalın</p>
  </div>
</div>
<script>
window.SS_INLINE_BANNERS = <?= json_encode(array_values($inlineBanners), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
