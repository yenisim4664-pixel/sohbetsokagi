<?php
/**
 * SOHBET SOKAĞI — Yönetim Paneli (9 sekme, tam kontrol)
 * Sekmeler: Genel Bakış, Videolar, Hikayeler, Emlak Admini, Bannerlar,
 *           Görünüm, Profil & İletişim, SEO, Güvenlik
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/webpush.php';

if (!isAdmin()) {
    header('Location: login.php');
    exit;
}

$S = siteData();
$theme = $S['theme'];
$owner = $S['owner'];
$seo = $S['seo'];
$base = baseUrl();
$currentIp = clientIp();
$ownerIpList = ownerIps();

/* ---------- Veriler ---------- */
$v = dbOne('SELECT COUNT(*) AS c, COALESCE(SUM(views),0) AS sv, COALESCE(SUM(likes),0) AS sl FROM videos') ?: [];
$l = dbOne("SELECT COUNT(*) AS c, COALESCE(SUM(status='aktif'),0) AS aktif, COALESCE(SUM(views),0) AS sv FROM listings") ?: [];
$st = dbOne('SELECT COUNT(*) AS c FROM stories WHERE expires_at > NOW()') ?: [];
$today = dbOne('SELECT COUNT(*) AS c, COUNT(DISTINCT ip) AS u FROM visits WHERE created_at >= CURDATE()') ?: [];
$total = dbOne('SELECT COUNT(*) AS c FROM visits') ?: [];
$recent = dbAll('SELECT ip, path, created_at FROM visits ORDER BY id DESC LIMIT 18');
$suspicious = dbAll('SELECT ip, COUNT(*) AS hits FROM visits WHERE created_at > NOW() - INTERVAL 6 HOUR GROUP BY ip HAVING COUNT(*) > 120 ORDER BY hits DESC LIMIT 12');
$bans = dbAll('SELECT * FROM banned_ips ORDER BY created_at DESC');
$videos = dbAll('SELECT * FROM videos ORDER BY pinned DESC, created_at DESC LIMIT 50');
$stories = activeStories();
$listings = dbAll('SELECT * FROM listings ORDER BY pinned DESC, created_at DESC LIMIT 200');
$banners = $S['banners'];
try { $pushSubs = pushSubCount(); } catch (Throwable $e) { $pushSubs = 0; }

$STATS = [
    ['Bugün', (int)($today['u'] ?? 0), (int)($today['c'] ?? 0) . ' sayfa gezinme'],
    ['Toplam Ziyaret', (int)($total['c'] ?? 0), 'tüm zamanlar'],
    ['Video', (int)($v['c'] ?? 0), number_format((int)($v['sv'] ?? 0), 0, ',', '.') . ' izlenme'],
    ['Beğeni', (int)($v['sl'] ?? 0), 'tüm videolar'],
    ['İlan', (int)($l['c'] ?? 0), (int)($l['aktif'] ?? 0) . ' aktif · ' . number_format((int)($l['sv'] ?? 0), 0, ',', '.') . ' görüntülenme'],
    ['Aktif Hikaye', (int)($st['c'] ?? 0), '24 saat döngüsü'],
    ['Bildirim Abonesi', $pushSubs, 'web push kayıtları'],
    ['Yasaklı IP', count($bans), 'erişimi engelli'],
];

$statusColors = [
    'aktif' => 'background:rgba(16,185,129,.1);color:#059669',
    'satildi' => 'background:rgba(244,63,94,.1);color:#f43f5e',
    'kiralandi' => 'background:rgba(245,158,11,.1);color:#d97706',
];
?><!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Yönetim Paneli — <?= e($S['siteName']) ?></title>
<meta name="robots" content="noindex, nofollow">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com"></script>
<script src="https://cdn.jsdelivr.net/npm/hls.js@1"></script>
<link rel="stylesheet" href="<?= e($base) ?>/assets/site.css">
<style>#fabBtn,#fabMenu{display:none!important}</style>
</head>
<body style="<?= themeStyle($theme) ?>background:var(--bg);color:var(--ink)">
<div class="min-h-dvh pb-16">

<!-- Üst çubuk -->
<header class="sticky top-0 z-40 border-b backdrop-blur-xl" style="border-color:var(--line);background:color-mix(in srgb, var(--bg) 85%, transparent)">
  <div class="mx-auto flex max-w-[900px] items-center justify-between gap-3 px-4 py-3">
    <div class="flex items-center gap-2.5">
      <span class="ring-gradient flex h-9 w-9 items-center justify-center rounded-xl text-[11px] font-extrabold text-white">SS</span>
      <div>
        <p class="text-[14px] font-extrabold leading-tight tracking-tight">Admin Paneli</p>
        <p class="text-[10.5px] font-semibold" style="color:var(--muted)"><?= e($S['siteName']) ?> · tam kontrol</p>
      </div>
    </div>
    <div class="flex items-center gap-2">
      <a href="<?= e($base) ?>/index.php" class="flex items-center gap-1.5 rounded-full border px-3.5 py-2 text-[11.5px] font-extrabold transition" style="border-color:var(--line);background:var(--card)">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
        Siteyi Gör
      </a>
      <a href="logout.php" class="flex items-center gap-1.5 rounded-full px-3.5 py-2 text-[11.5px] font-extrabold transition hover:opacity-85" style="background:var(--ink);color:var(--bg)">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>
        Çıkış
      </a>
    </div>
  </div>
  <div class="no-scrollbar mx-auto flex max-w-[900px] gap-1 overflow-x-auto px-3 pb-2">
    <?php
    $tabs = [
        'genel' => 'Genel Bakış', 'videolar' => 'Videolar', 'hikayeler' => 'Hikayeler',
        'emlak' => 'Emlak Admini', 'banner' => 'Bannerlar', 'gorunum' => 'Görünüm',
        'profil' => 'Profil & İletişim', 'seo' => 'SEO', 'guvenlik' => 'Güvenlik',
    ];
    foreach ($tabs as $tid => $tlabel): ?>
    <button data-tab="<?= e($tid) ?>" class="shrink-0 rounded-full px-3.5 py-2 text-[11.5px] font-extrabold transition active:scale-95" style="color:var(--muted)"><?= e($tlabel) ?></button>
    <?php endforeach; ?>
  </div>
</header>

<main class="mx-auto max-w-[900px] px-4 pt-5">

<!-- ================= GENEL BAKIŞ ================= -->
<section data-tabpanel="genel" class="flex flex-col gap-4">
  <div class="grid grid-cols-2 gap-3 sm:grid-cols-4">
    <?php foreach ($STATS as [$label, $val, $sub]): ?>
    <div class="rounded-2xl border p-4" style="border-color:var(--line);background:var(--card)">
      <span class="text-[11px] font-extrabold uppercase tracking-wide" style="color:var(--muted)"><?= e($label) ?></span>
      <p class="mt-1.5 text-2xl font-extrabold tracking-tight"><?= number_format((int)$val, 0, ',', '.') ?></p>
      <p class="text-[11px] font-semibold" style="color:var(--muted)"><?= e($sub) ?></p>
    </div>
    <?php endforeach; ?>
  </div>

  <div class="rounded-2xl border p-5" style="border-color:var(--line);background:var(--card)">
    <div class="mb-4 flex items-center justify-between">
      <h3 class="text-[14px] font-extrabold tracking-tight" style="color:var(--accent)">Şüpheli IP Adresleri</h3>
      <span class="text-[10.5px] font-bold" style="color:var(--muted)">son 6 saatte 120+ istek</span>
    </div>
    <?php if ($suspicious): ?>
      <div class="flex flex-col gap-2">
        <?php foreach ($suspicious as $sp): ?>
        <div class="flex items-center justify-between gap-2 rounded-xl border border-amber-500/25 bg-amber-500/5 px-3.5 py-2.5">
          <div>
            <p class="font-mono text-[13px] font-bold"><?= e($sp['ip']) ?></p>
            <p class="text-[10.5px] font-bold text-amber-600"><?= (int)$sp['hits'] ?> istek / 6 saat</p>
          </div>
          <button class="rounded-full bg-rose-500 px-3.5 py-1.5 text-[11px] font-extrabold text-white transition active:scale-95" onclick="banIp('<?= e($sp['ip']) ?>', 'Şüpheli aktivite (otomatik tespit)')">Yasakla</button>
        </div>
        <?php endforeach; ?>
      </div>
    <?php else: ?>
      <p class="text-[12.5px] font-semibold" style="color:var(--muted)">Şüpheli aktivite tespit edilmedi. Her şey normal görünüyor.</p>
    <?php endif; ?>
  </div>

  <div class="rounded-2xl border p-5" style="border-color:var(--line);background:var(--card)">
    <h3 class="mb-4 text-[14px] font-extrabold tracking-tight" style="color:var(--accent)">Son Ziyaretler</h3>
    <?php if ($recent): ?>
    <div class="overflow-x-auto">
      <table class="w-full text-left text-[12px]">
        <thead>
          <tr class="text-[10.5px] uppercase tracking-wide" style="color:var(--muted)">
            <th class="pb-2 pr-3 font-extrabold">IP Adresi</th>
            <th class="pb-2 pr-3 font-extrabold">Sayfa</th>
            <th class="pb-2 font-extrabold">Zaman</th>
          </tr>
        </thead>
        <tbody class="font-semibold">
          <?php foreach ($recent as $rv): ?>
          <tr class="border-t" style="border-color:var(--line)">
            <td class="py-2 pr-3 font-mono"><?= e($rv['ip']) ?></td>
            <td class="py-2 pr-3" style="color:var(--muted)"><?= e($rv['path']) ?></td>
            <td class="py-2" style="color:var(--muted)"><?= e(date('d.m H:i', strtotime($rv['created_at']))) ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
      <p class="text-[12.5px] font-semibold" style="color:var(--muted)">Henüz ziyaret kaydı yok.</p>
    <?php endif; ?>
  </div>
</section>

<!-- ================= VİDEOLAR ================= -->
<section data-tabpanel="videolar" class="hidden flex-col gap-3">
  <div class="flex items-center justify-between">
    <p class="text-[13px] font-bold" style="color:var(--muted)"><?= count($videos) ?> video · sabitlenenler en üstte görünür</p>
    <button data-fab-open="videoModal" class="flex items-center gap-1.5 rounded-xl px-4 py-2 text-sm font-bold shadow-sm transition active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
      Yeni Video
    </button>
  </div>
  <?php if (!$videos): ?>
    <p class="rounded-2xl border border-dashed py-12 text-center text-sm font-semibold" style="border-color:var(--line);color:var(--muted)">Henüz video yok — ilk videonuzu ekleyin.</p>
  <?php endif; ?>
  <?php foreach ($videos as $vd): $vj = videoToJson($vd); ?>
  <div class="flex items-center gap-3 rounded-2xl border p-3" style="border-color:var(--line);background:var(--card)">
    <div class="relative h-14 w-24 shrink-0 overflow-hidden rounded-lg bg-neutral-200">
      <?php if ($vj['posterUrl']): ?><img src="<?= e($vj['posterUrl']) ?>" class="h-full w-full object-cover" alt=""><?php endif; ?>
    </div>
    <div class="min-w-0 flex-1">
      <p class="line-clamp-1 text-[13px] font-extrabold tracking-tight">
        <?php if ($vj['pinned']): ?><span style="color:var(--accent)">◈</span><?php endif; ?>
        <?= e($vj['title'] ?: '(Başlıksız)') ?>
      </p>
      <p class="mt-0.5 flex items-center gap-3 text-[10.5px] font-bold" style="color:var(--muted)">
        <span><?= e(formatCount($vj['views'])) ?> izlenme</span>
        <span><?= e(formatCount($vj['likes'])) ?> beğeni</span>
        <span><?= e(timeAgo($vd['created_at'])) ?></span>
      </p>
    </div>
    <div class="flex shrink-0 items-center gap-1">
      <button class="rounded-lg p-2 transition hover:bg-[var(--bg)]" style="color:var(--muted)" title="<?= $vj['pinned'] ? 'Sabitlemeyi kaldır' : 'Üste sabitle' ?>" onclick="pinVideo(<?= (int)$vj['id'] ?>, <?= $vj['pinned'] ? 'false' : 'true' ?>)">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="<?= $vj['pinned'] ? 'var(--accent)' : 'none' ?>" stroke="currentColor" stroke-width="2"><path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1z"/></svg>
      </button>
      <button class="rounded-lg p-2 transition hover:bg-[var(--bg)]" style="color:var(--muted)" title="Düzenle"
        onclick='adminEditVideo(<?= json_encode($vj, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_APOS) ?>)'>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
      </button>
      <button class="rounded-lg p-2 transition hover:bg-rose-500/10 hover:text-rose-500" style="color:var(--muted)" title="Sil" onclick="delVideo(<?= (int)$vj['id'] ?>)">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
      </button>
    </div>
  </div>
  <?php endforeach; ?>
</section>

<!-- ================= HİKAYELER ================= -->
<section data-tabpanel="hikayeler" class="hidden flex-col gap-4">
  <div class="rounded-2xl border p-4" style="border-color:var(--line);background:var(--card)">
    <p class="mb-3 text-[13px] font-extrabold" style="color:var(--accent)">Yeni Hikaye <span class="text-[10.5px] font-bold" style="color:var(--muted)">(24 saat sonra otomatik silinir)</span></p>
    <div class="flex flex-col gap-2.5 sm:flex-row">
      <label class="flex flex-1 cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-3 text-[12.5px] font-bold transition" style="border-color:var(--line);color:var(--muted)">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 14.9A7 7 0 1 1 15.7 8h1.8a4.5 4.5 0 0 1 2.5 8.2"/><path d="M12 12v9"/><path d="m8 16 4-4 4 4"/></svg>
        <span data-upload-label>Medya yükle</span>
        <input type="file" class="hidden" accept="image/jpeg,image/png,image/webp,video/mp4,video/webm" data-upload data-upload-url="#quickStoryUrl">
      </label>
      <input id="quickStoryUrl" type="text" placeholder="veya medya URL'si yapıştır" class="flex-[2] rounded-xl border px-3.5 py-2.5 text-sm focus:outline-none" style="border-color:var(--line);background:var(--bg)">
      <button onclick="addStory()" class="rounded-xl px-4 py-2.5 text-sm font-bold transition active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">Hikaye Ekle</button>
    </div>
  </div>
  <?php if (!$stories): ?>
    <p class="rounded-2xl border border-dashed py-12 text-center text-sm font-semibold" style="border-color:var(--line);color:var(--muted)">Aktif hikaye yok.</p>
  <?php endif; ?>
  <div class="grid grid-cols-2 gap-3 sm:grid-cols-4">
    <?php foreach ($stories as $s): $leftH = max(0, (int) round((strtotime($s['expires_at']) - time()) / 3600)); ?>
    <div class="group relative aspect-[9/16] overflow-hidden rounded-2xl border bg-neutral-200" style="border-color:var(--line)">
      <?php if ($s['media_type'] === 'video'): ?>
        <video src="<?= e($s['media_url']) ?>" class="h-full w-full object-cover" muted playsinline preload="metadata"></video>
      <?php else: ?>
        <img src="<?= e($s['media_url']) ?>" class="h-full w-full object-cover" alt="">
      <?php endif; ?>
      <div class="absolute inset-x-0 bottom-0 p-2.5 pt-8" style="background:linear-gradient(to top, rgba(0,0,0,.7), transparent)">
        <p class="text-[10.5px] font-extrabold text-white"><?= $leftH ?> sa kaldı</p>
      </div>
      <button onclick="delStory(<?= (int)$s['id'] ?>)" class="absolute right-2 top-2 rounded-full bg-black/55 p-1.5 text-white opacity-0 backdrop-blur transition group-hover:opacity-100 hover:bg-rose-500" aria-label="Sil">
        <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>
      </button>
    </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- ================= EMLAK ADMİNİ ================= -->
<section data-tabpanel="emlak" class="hidden flex-col gap-3">
  <div class="flex flex-wrap items-center justify-between gap-2">
    <div class="flex flex-wrap gap-1.5" id="emlakAdminFilters">
      <?php foreach (['all' => 'Tümü', 'satilik' => 'Satılık', 'kiralik' => 'Kiralık', 'satildi' => 'Satıldı', 'kiralandi' => 'Kiralandı'] as $fid => $fl): ?>
      <button data-afilter="<?= e($fid) ?>" class="rounded-full border px-3.5 py-1.5 text-[11px] font-extrabold transition active:scale-95" style="<?= $fid === 'all' ? 'background:var(--ink);color:var(--bg);border-color:var(--ink)' : 'border-color:var(--line);background:var(--card);color:var(--muted)' ?>"><?= e($fl) ?></button>
      <?php endforeach; ?>
    </div>
    <button data-fab-open="listingModal" class="flex items-center gap-1.5 rounded-xl px-4 py-2 text-sm font-bold shadow-sm transition active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
      Yeni İlan
    </button>
  </div>
  <?php if (!$listings): ?>
    <p class="rounded-2xl border border-dashed py-12 text-center text-sm font-semibold" style="border-color:var(--line);color:var(--muted)">Henüz ilan yok.</p>
  <?php endif; ?>
  <?php foreach ($listings as $li): $lj = listingToJson($li); ?>
  <div class="flex items-center gap-3 rounded-2xl border p-3" style="border-color:var(--line);background:var(--card)" data-arow data-atype="<?= e($lj['type']) ?>" data-astatus="<?= e($lj['status']) ?>">
    <div class="h-14 w-20 shrink-0 overflow-hidden rounded-lg bg-neutral-200">
      <?php if ($lj['images']): ?><img src="<?= e($lj['images'][0]) ?>" class="h-full w-full object-cover" alt=""><?php endif; ?>
    </div>
    <div class="min-w-0 flex-1">
      <p class="line-clamp-1 text-[13px] font-extrabold tracking-tight"><?= e($lj['title']) ?></p>
      <p class="mt-0.5 flex flex-wrap items-center gap-2 text-[10.5px] font-bold" style="color:var(--muted)">
        <span style="color:var(--accent)"><?= e(formatPrice($lj['price'], $lj['type'])) ?></span>
        <span class="rounded-full px-2 py-0.5" style="<?= $statusColors[$lj['status']] ?>"><?= e(LISTING_STATUS_LABELS[$lj['status']]) ?></span>
        <span><?= e(formatCount($lj['views'])) ?> görüntülenme</span>
      </p>
    </div>
    <div class="flex shrink-0 items-center gap-1">
      <select onchange="listingStatus(<?= (int)$lj['id'] ?>, this.value)" class="rounded-lg border px-1.5 py-1.5 text-[10.5px] font-bold focus:outline-none" style="border-color:var(--line);background:var(--bg);color:var(--muted)" title="Durum değiştir">
        <?php foreach (LISTING_STATUS_LABELS as $sk => $sl): ?>
        <option value="<?= e($sk) ?>" <?= $lj['status'] === $sk ? 'selected' : '' ?>><?= e($sl) ?></option>
        <?php endforeach; ?>
      </select>
      <button class="rounded-lg p-2 transition hover:bg-[var(--bg)]" style="color:var(--muted)" title="<?= $lj['pinned'] ? 'Sabitlemeyi kaldır' : 'Üste sabitle' ?>" onclick="pinListing(<?= (int)$lj['id'] ?>, <?= $lj['pinned'] ? 'false' : 'true' ?>)">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="<?= $lj['pinned'] ? 'var(--accent)' : 'none' ?>" stroke="currentColor" stroke-width="2"><path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1z"/></svg>
      </button>
      <button class="rounded-lg p-2 transition hover:bg-[var(--bg)]" style="color:var(--muted)" title="Düzenle"
        onclick='adminEditListing(<?= json_encode($lj, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_APOS) ?>)'>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
      </button>
      <button class="rounded-lg p-2 transition hover:bg-rose-500/10 hover:text-rose-500" style="color:var(--muted)" title="Sil" onclick="delListing(<?= (int)$lj['id'] ?>)">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>
      </button>
    </div>
  </div>
  <?php endforeach; ?>
</section>

<!-- ================= BANNERLAR ================= -->
<section data-tabpanel="banner" class="hidden flex-col gap-3">
  <div class="flex items-center justify-between">
    <p class="text-[13px] font-bold" style="color:var(--muted)"><?= count($banners) ?> banner · konumlarına göre sitede gösterilir</p>
    <button onclick="bannerNew()" class="flex items-center gap-1.5 rounded-xl px-4 py-2 text-sm font-bold shadow-sm transition active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
      Yeni Banner
    </button>
  </div>
  <?php if (!$banners): ?>
    <p class="rounded-2xl border border-dashed py-12 text-center text-sm font-semibold" style="border-color:var(--line);color:var(--muted)">Banner yok — reklam ve duyuru alanları için ekleyin.</p>
  <?php endif; ?>
  <?php foreach ($banners as $bi => $b): ?>
  <div class="flex items-center gap-3 rounded-2xl border p-3" style="border-color:var(--line);background:var(--card)">
    <div class="h-14 w-24 shrink-0 overflow-hidden rounded-lg bg-neutral-200">
      <?php if (!empty($b['imageUrl'])): ?><img src="<?= e($b['imageUrl']) ?>" class="h-full w-full object-cover" alt=""><?php endif; ?>
    </div>
    <div class="min-w-0 flex-1">
      <p class="line-clamp-1 text-[13px] font-extrabold tracking-tight"><?= e($b['title'] ?: '(Başlıksız banner)') ?></p>
      <p class="mt-0.5 text-[10.5px] font-bold" style="color:var(--muted)">
        <?= e(POSITION_LABELS[$b['position'] ?? 'feed-top'] ?? $b['position']) ?> · <?= !empty($b['active']) ? 'Aktif' : 'Pasif' ?> · <?= e($b['linkUrl'] ?: 'linksiz') ?>
      </p>
    </div>
    <div class="flex shrink-0 items-center gap-1">
      <button onclick="bannerToggle(<?= $bi ?>)" class="rounded-full px-3 py-1.5 text-[10.5px] font-extrabold transition active:scale-95" style="<?= !empty($b['active']) ? 'background:rgba(16,185,129,.1);color:#059669' : 'background:var(--bg);color:var(--muted)' ?>">
        <?= !empty($b['active']) ? 'AKTİF' : 'PASİF' ?>
      </button>
      <button class="rounded-lg p-2 transition hover:bg-[var(--bg)]" style="color:var(--muted)" onclick='bannerEdit(<?= $bi ?>)'>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/></svg>
      </button>
      <button class="rounded-lg p-2 transition hover:bg-rose-500/10 hover:text-rose-500" style="color:var(--muted)" onclick="bannerDel(<?= $bi ?>)">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/></svg>
      </button>
    </div>
  </div>
  <?php endforeach; ?>

  <!-- Banner form modali -->
  <div id="bannerModal" class="modal-hidden fixed inset-0 z-[90] flex items-end justify-center sm:items-center sm:p-4">
    <div class="animate-fade-in absolute inset-0 bg-black/50 backdrop-blur-sm" data-modal-close></div>
    <div class="animate-sheet-up no-scrollbar relative max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl border shadow-2xl sm:max-w-md sm:rounded-3xl" style="border-color:var(--line);background:var(--card)">
      <div class="sticky top-0 z-10 flex items-center justify-between border-b px-5 py-4" style="border-color:var(--line)">
        <h3 id="bannerModalTitle" class="text-[15px] font-extrabold tracking-tight">Yeni Banner</h3>
        <button data-modal-close class="rounded-full p-1.5" style="color:var(--muted)">✕</button>
      </div>
      <div class="space-y-3.5 p-5">
        <input type="hidden" id="bn_idx" value="-1">
        <label class="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-5 text-sm font-bold" style="border-color:var(--line);color:var(--muted)">
          <span data-upload-label>Banner görseli yükle</span>
          <input type="file" class="hidden" accept="image/jpeg,image/png,image/webp" data-upload data-upload-url="#bn_image">
        </label>
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">veya Görsel URL</span>
          <input id="bn_image" type="text" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Başlık</span>
          <input id="bn_title" type="text" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Bağlantı</span>
          <input id="bn_link" type="text" placeholder="emlak.php veya https://..." class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Konum</span>
          <select id="bn_position" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)">
            <option value="feed-top">Akış üstü (hikayelerin altı)</option>
            <option value="feed-inline">Akış içi (gönderiler arası)</option>
            <option value="emlak-top">Emlak sayfası üstü</option>
          </select></div>
        <button id="bn_active" data-toggle="1" class="flex w-full items-center justify-between gap-3 rounded-xl border px-3.5 py-2.5" style="border-color:var(--line);background:var(--bg)">
          <span class="text-sm font-semibold">Banner aktif</span>
          <span data-toggle-track class="relative h-6 w-11 rounded-full transition" style="background:var(--accent)"><span data-toggle-dot class="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all" style="left:22px"></span></span>
        </button>
        <div class="flex gap-2">
          <button data-modal-close class="flex-1 rounded-xl border px-4 py-2.5 text-sm font-bold" style="border-color:var(--line)">Vazgeç</button>
          <button onclick="bannerSave()" class="flex-1 rounded-xl px-4 py-2.5 text-sm font-bold" style="background:var(--accent);color:var(--accent-ink)">Kaydet</button>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ================= GÖRÜNÜM ================= -->
<section data-tabpanel="gorunum" class="hidden flex-col gap-4">
  <div class="rounded-2xl border p-5" style="border-color:var(--line);background:var(--card)">
    <h3 class="mb-4 text-[14px] font-extrabold tracking-tight">Hazır Temalar</h3>
    <div class="grid grid-cols-2 gap-2.5 sm:grid-cols-5">
      <?php
      $presets = [
          ['Açık Sıcak', ['accent' => '#FF5A3C', 'accentInk' => '#FFFFFF', 'gradientFrom' => '#FF8A00', 'gradientTo' => '#E1306C', 'bg' => '#FAF7F3', 'card' => '#FFFFFF', 'ink' => '#1C1611', 'muted' => '#98897B', 'line' => '#F0E8E0']],
          ['Gece', ['accent' => '#FF6A4D', 'accentInk' => '#16110D', 'gradientFrom' => '#FF8A00', 'gradientTo' => '#E1306C', 'bg' => '#12100E', 'card' => '#1C1915', 'ink' => '#F4EEE6', 'muted' => '#8D8073', 'line' => '#2C2721']],
          ['Okyanus', ['accent' => '#0E8FD6', 'accentInk' => '#FFFFFF', 'gradientFrom' => '#19B3F0', 'gradientTo' => '#0E5FD6', 'bg' => '#F4F8FB', 'card' => '#FFFFFF', 'ink' => '#1C1611', 'muted' => '#7E93A3', 'line' => '#E4EDF4']],
          ['Yosun', ['accent' => '#1C9E57', 'accentInk' => '#FFFFFF', 'gradientFrom' => '#3BC476', 'gradientTo' => '#0E7A45', 'bg' => '#F5F9F4', 'card' => '#FFFFFF', 'ink' => '#1C1611', 'muted' => '#82997F', 'line' => '#E5EEE3']],
          ['Gece Moru', ['accent' => '#7C4DFF', 'accentInk' => '#FFFFFF', 'gradientFrom' => '#A265FF', 'gradientTo' => '#5A2ED6', 'bg' => '#F6F4FB', 'card' => '#FFFFFF', 'ink' => '#1C1611', 'muted' => '#8E84A6', 'line' => '#EAE5F6']],
      ];
      foreach ($presets as [$pname, $pt]): ?>
      <button onclick='applyPreset(<?= json_encode($pt, JSON_UNESCAPED_SLASHES | JSON_HEX_APOS) ?>)' class="overflow-hidden rounded-2xl border-2 text-left transition active:scale-[.98]" style="border-color:<?= $theme['accent'] === $pt['accent'] && $theme['bg'] === $pt['bg'] ? 'var(--accent)' : 'var(--line)' ?>">
        <span class="block h-14" style="background:linear-gradient(120deg, <?= e($pt['gradientFrom']) ?>, <?= e($pt['gradientTo']) ?>)"></span>
        <span class="flex items-center justify-between px-3 py-2" style="background:<?= e($pt['card']) ?>;color:<?= e($pt['ink']) ?>">
          <span class="text-[11px] font-extrabold"><?= e($pname) ?></span>
        </span>
      </button>
      <?php endforeach; ?>
    </div>
  </div>

  <div class="rounded-2xl border p-5" style="border-color:var(--line);background:var(--card)">
    <h3 class="mb-4 text-[14px] font-extrabold tracking-tight">Renk Özelleştirme</h3>
    <div class="grid gap-2 sm:grid-cols-2">
      <?php
      $colorFields = [
          ['c_accent', 'Ana renk (vurgu)', $theme['accent']],
          ['c_accentInk', 'Vurgu metin rengi', $theme['accentInk']],
          ['c_gradientFrom', 'Hikaye halkası başlangıç', $theme['gradientFrom']],
          ['c_gradientTo', 'Hikaye halkası bitiş', $theme['gradientTo']],
          ['c_bg', 'Arka plan', $theme['bg']],
          ['c_card', 'Kart rengi', $theme['card']],
          ['c_ink', 'Metin rengi', $theme['ink']],
          ['c_muted', 'Soluk metin', $theme['muted']],
          ['c_line', 'Kenarlık', $theme['line']],
      ];
      foreach ($colorFields as [$fid, $flabel, $fval]): ?>
      <label class="flex items-center justify-between gap-3 rounded-xl border px-3 py-2" style="border-color:var(--line);background:var(--bg)">
        <span class="text-[12px] font-bold"><?= e($flabel) ?></span>
        <span class="flex items-center gap-2">
          <span class="font-mono text-[10.5px] font-bold" style="color:var(--muted)" data-hex="<?= e($fid) ?>"><?= e(strtoupper($fval)) ?></span>
          <input type="color" id="<?= e($fid) ?>" value="<?= e($fval) ?>" class="h-8 w-10 cursor-pointer rounded-lg border bg-transparent p-0.5" style="border-color:var(--line)" oninput="colorChanged('<?= e($fid) ?>', this.value)">
        </span>
      </label>
      <?php endforeach; ?>
      <label class="flex items-center justify-between gap-3 rounded-xl border px-3 py-2" style="border-color:var(--line);background:var(--bg)">
        <span class="text-[12px] font-bold">Köşe yuvarlaklığı</span>
        <span class="flex items-center gap-2">
          <input type="range" id="c_radius" min="6" max="28" value="<?= (int) rtrim($theme['radius'], 'px') ?>" class="w-24" style="accent-color:var(--accent)" oninput="document.getElementById('c_radius_val').textContent = this.value + 'px'">
          <span id="c_radius_val" class="font-mono text-[10.5px] font-bold" style="color:var(--muted)"><?= e($theme['radius']) ?></span>
        </span>
      </label>
    </div>
  </div>

  <div class="rounded-2xl border p-5" style="border-color:var(--line);background:var(--card)">
    <h3 class="mb-4 text-[14px] font-extrabold tracking-tight">Logo, İsim ve Footer</h3>
    <div class="flex flex-col gap-3">
      <div class="flex items-start gap-3">
        <div class="flex-1">
          <span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Site Adı</span>
          <input id="m_siteName" type="text" value="<?= e($S['siteName']) ?>" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)">
        </div>
        <img id="m_logoPreview" src="<?= e($S['logoUrl'] ?: $base . '/assets/img/icon-512.png') ?>" class="mt-5 h-10 w-10 rounded-xl border object-cover" style="border-color:var(--line)" alt="">
      </div>
      <div>
        <span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Slogan (header altında görünür)</span>
        <input id="m_tagline" type="text" value="<?= e($S['tagline']) ?>" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)">
      </div>
      <div>
        <span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Logo URL (boş bırakılırsa SS monogramı)</span>
        <input id="m_logoUrl" type="text" value="<?= e($S['logoUrl']) ?>" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)">
      </div>
      <label class="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-4 text-sm font-bold" style="border-color:var(--line);color:var(--muted)">
        <span data-upload-label>Logo dosyası yükle</span>
        <input type="file" class="hidden" accept="image/jpeg,image/png,image/webp" data-upload data-upload-url="#m_logoUrl">
      </label>
      <div>
        <span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Footer Metni</span>
        <textarea id="m_footerText" rows="2" class="w-full resize-none rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"><?= e($S['footerText']) ?></textarea>
      </div>
      <button onclick="saveAppearance()" class="self-start rounded-xl px-4 py-2.5 text-sm font-bold transition active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">Tüm Görünüm Ayarlarını Kaydet</button>
    </div>
  </div>
</section>

<!-- ================= PROFİL & İLETİŞİM ================= -->
<section data-tabpanel="profil" class="hidden flex-col gap-4">
  <div class="rounded-2xl border p-5" style="border-color:var(--line);background:var(--card)">
    <h3 class="mb-4 text-[14px] font-extrabold tracking-tight">Profil Bilgileri</h3>
    <div class="flex flex-col gap-3">
      <div class="flex items-center gap-3">
        <span class="ring-gradient rounded-full p-[2.5px]">
          <img id="p_avatarPreview" src="<?= e($owner['avatar']) ?>" class="h-14 w-14 rounded-full border-2 object-cover" style="border-color:var(--card)" alt="">
        </span>
        <div class="flex-1">
          <span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Avatar URL</span>
          <input id="p_avatar" type="text" value="<?= e($owner['avatar']) ?>" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)" oninput="document.getElementById('p_avatarPreview').src=this.value">
        </div>
      </div>
      <label class="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-4 text-sm font-bold" style="border-color:var(--line);color:var(--muted)">
        <span data-upload-label>Avatar yükle</span>
        <input type="file" class="hidden" accept="image/jpeg,image/png,image/webp" data-upload data-upload-url="#p_avatar">
      </label>
      <div class="grid grid-cols-2 gap-3">
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Görünen İsim</span>
          <input id="p_name" type="text" value="<?= e($owner['name']) ?>" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
        <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Kullanıcı Adı</span>
          <input id="p_username" type="text" value="<?= e($owner['username']) ?>" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
      </div>
      <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Biyografi</span>
        <textarea id="p_bio" rows="3" class="w-full resize-none rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"><?= e($owner['bio']) ?></textarea></div>
      <button id="p_verified" data-toggle="<?= $owner['verified'] ? '1' : '0' ?>" class="flex w-full items-center justify-between gap-3 rounded-xl border px-3.5 py-2.5" style="border-color:var(--line);background:var(--bg)">
        <span class="text-sm font-semibold">Mavi tik (doğrulanmış hesap rozeti) göster</span>
        <span data-toggle-track class="relative h-6 w-11 rounded-full transition" style="background:<?= $owner['verified'] ? 'var(--accent)' : 'var(--line)' ?>"><span data-toggle-dot class="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all" style="left:<?= $owner['verified'] ? '22' : '2' ?>px"></span></span>
      </button>
    </div>
  </div>
  <div class="rounded-2xl border p-5" style="border-color:var(--line);background:var(--card)">
    <h3 class="mb-4 text-[14px] font-extrabold tracking-tight">İletişim ve Yönlendirmeler</h3>
    <div class="flex flex-col gap-3">
      <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">WhatsApp Numarası (90 ile başlayan, boşluksuz)</span>
        <input id="p_whatsapp" type="text" value="<?= e($owner['whatsapp']) ?>" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
      <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Instagram Profil URL</span>
        <input id="p_instagram" type="text" value="<?= e($owner['instagram']) ?>" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
      <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">E-posta</span>
        <input id="p_email" type="text" value="<?= e($owner['email']) ?>" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
      <p class="rounded-xl px-3.5 py-2.5 text-[11.5px] font-semibold leading-relaxed" style="background:var(--bg);color:var(--muted)">WhatsApp, Instagram ve "Reklam ve İş Birliği" butonları profil sayfasında ve emlak sayfasında otomatik görünür; tümü bu bilgileri kullanır.</p>
      <button onclick="saveProfile()" class="self-start rounded-xl px-4 py-2.5 text-sm font-bold transition active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">Profil Ayarlarını Kaydet</button>
    </div>
  </div>
</section>

<!-- ================= SEO ================= -->
<section data-tabpanel="seo" class="hidden flex-col gap-4">
  <div class="rounded-2xl border p-5" style="border-color:var(--line);background:var(--card)">
    <h3 class="mb-4 text-[14px] font-extrabold tracking-tight">Google Önizleme</h3>
    <div class="rounded-2xl border bg-white p-4" style="border-color:var(--line)">
      <p class="text-[11px] font-semibold text-neutral-600">sohbetsokagi.com</p>
      <p id="gPrevTitle" class="mt-1 line-clamp-1 text-[16px] font-medium text-[#1a0dab]"><?= e($seo['title']) ?></p>
      <p id="gPrevDesc" class="mt-0.5 line-clamp-2 text-[12.5px] leading-snug text-neutral-600"><?= e($seo['description']) ?></p>
    </div>
  </div>
  <div class="rounded-2xl border p-5" style="border-color:var(--line);background:var(--card)">
    <h3 class="mb-4 text-[14px] font-extrabold tracking-tight">SEO Meta Etiketleri</h3>
    <div class="flex flex-col gap-3">
      <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Site Başlığı (70 karakter)</span>
        <input id="s_title" type="text" maxlength="70" value="<?= e($seo['title']) ?>" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)" oninput="document.getElementById('gPrevTitle').textContent=this.value"></div>
      <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Açıklama (160 karakter)</span>
        <textarea id="s_desc" rows="3" maxlength="160" class="w-full resize-none rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)" oninput="document.getElementById('gPrevDesc').textContent=this.value"><?= e($seo['description']) ?></textarea></div>
      <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Anahtar Kelimeler (virgülle ayırın)</span>
        <textarea id="s_keywords" rows="2" class="w-full resize-none rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"><?= e($seo['keywords']) ?></textarea></div>
      <div><span class="mb-1.5 block text-xs font-bold" style="color:var(--muted)">Sosyal Paylaşım Görseli (OG Image) URL</span>
        <input id="s_og" type="text" value="<?= e($seo['ogImage']) ?>" class="w-full rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)"></div>
      <label class="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-4 text-sm font-bold" style="border-color:var(--line);color:var(--muted)">
        <span data-upload-label>OG görseli yükle (1200×630 önerilir)</span>
        <input type="file" class="hidden" accept="image/jpeg,image/png,image/webp" data-upload data-upload-url="#s_og">
      </label>
      <p class="rounded-xl px-3.5 py-2.5 text-[11.5px] font-semibold leading-relaxed" style="background:var(--bg);color:var(--muted)">Bunların yanında site; video gönderileri için VideoObject, ilanlar için RealEstateListing, profil için ProfilePage yapısal verilerini (schema.org JSON-LD), sitemap.php ve robots.txt dosyalarını otomatik üretir.</p>
      <button onclick="saveSeo()" class="self-start rounded-xl px-4 py-2.5 text-sm font-bold transition active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">SEO Ayarlarını Kaydet</button>
    </div>
  </div>
</section>

<!-- ================= GÜVENLİK ================= -->
<section data-tabpanel="guvenlik" class="hidden flex-col gap-4">
  <div class="rounded-2xl border p-5" style="border-color:var(--line);background:var(--card)">
    <h3 class="mb-3 text-[14px] font-extrabold tracking-tight" style="color:var(--accent)">Sahip Cihazı — Site İçi Hızlı Paylaşım</h3>
    <p class="mb-3 text-[12.5px] font-semibold leading-relaxed" style="color:var(--muted)">Kayıtlı IP adreslerinden siteye giren cihazlar, admin paneline girmeden doğrudan akış üzerinden video, hikaye ve ilan paylaşabilir; gönderileri yönetebilir.</p>
    <div class="flex flex-wrap items-center gap-2">
      <span class="rounded-lg px-3 py-2 font-mono text-[12.5px] font-bold" style="background:var(--bg)">Bu cihaz: <?= e($currentIp) ?></span>
      <button onclick="registerOwnerIp('<?= e($currentIp) ?>')" class="rounded-xl px-4 py-2.5 text-sm font-bold transition active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">Bu Cihazı Sahip Olarak Kaydet</button>
    </div>
    <?php if ($ownerIpList): ?>
    <div class="mt-3 flex flex-wrap gap-2">
      <?php foreach ($ownerIpList as $oip): ?>
      <span class="flex items-center gap-2 rounded-full border py-1.5 pl-3.5 pr-1.5 font-mono text-[11.5px] font-bold" style="border-color:var(--line);background:var(--bg)">
        <?= e($oip) ?>
        <button onclick="removeOwnerIp('<?= e($oip) ?>')" class="rounded-full p-1 transition hover:bg-rose-500/10 hover:text-rose-500" style="color:var(--muted)" aria-label="Kaldır">✕</button>
      </span>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

  <div class="rounded-2xl border p-5" style="border-color:var(--line);background:var(--card)">
    <h3 class="mb-4 text-[14px] font-extrabold tracking-tight" style="color:var(--accent)">IP Yasaklama</h3>
    <div class="flex flex-col gap-2 sm:flex-row">
      <input id="ban_ip" type="text" placeholder="IP adresi (örn. 85.34.12.90)" class="flex-1 rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)">
      <input id="ban_reason" type="text" placeholder="Sebep (opsiyonel)" class="flex-1 rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)">
      <button onclick="banForm()" class="rounded-xl px-4 py-2.5 text-sm font-bold transition active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">Yasakla</button>
    </div>
    <?php if ($bans): ?>
    <div class="mt-4 flex flex-col gap-2">
      <?php foreach ($bans as $bn): ?>
      <div class="flex items-center justify-between gap-2 rounded-xl border border-rose-500/20 bg-rose-500/5 px-3.5 py-2.5">
        <div>
          <p class="font-mono text-[12.5px] font-bold"><?= e($bn['ip']) ?></p>
          <p class="text-[10.5px] font-semibold" style="color:var(--muted)"><?= e($bn['reason'] ?: 'Sebep belirtilmedi') ?> · <?= e(date('d.m.Y H:i', strtotime($bn['created_at']))) ?></p>
        </div>
        <button onclick="unbanIp('<?= e($bn['ip']) ?>')" class="rounded-full border px-3.5 py-1.5 text-[11px] font-extrabold transition active:scale-95" style="border-color:var(--line);background:var(--card)">Yasağı Kaldır</button>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

  <div class="rounded-2xl border p-5" style="border-color:var(--line);background:var(--card)">
    <h3 class="mb-4 text-[14px] font-extrabold tracking-tight" style="color:var(--accent)">Bildirim Sistemi (Web Push)</h3>
    <div class="flex flex-col gap-3">
      <button id="push_on_post" data-toggle="<?= $S['pushOnPost'] ? '1' : '0' ?>" class="flex w-full items-center justify-between gap-3 rounded-xl border px-3.5 py-2.5" style="border-color:var(--line);background:var(--bg)">
        <span class="text-sm font-semibold">Yeni video paylaşıldığında abonelere otomatik bildirim gönder</span>
        <span data-toggle-track class="relative h-6 w-11 rounded-full transition" style="background:<?= $S['pushOnPost'] ? 'var(--accent)' : 'var(--line)' ?>"><span data-toggle-dot class="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all" style="left:<?= $S['pushOnPost'] ? '22' : '2' ?>px"></span></span>
      </button>
      <div class="flex items-center justify-between rounded-xl px-3.5 py-2.5" style="background:var(--bg)">
        <span class="text-[12.5px] font-bold">Kayıtlı abone: <?= number_format($pushSubs, 0, ',', '.') ?></span>
        <button onclick="testPush()" class="rounded-xl border px-4 py-2 text-[12px] font-bold transition active:scale-[.98]" style="border-color:var(--line);background:var(--card)">Test Bildirimi Gönder</button>
      </div>
    </div>
  </div>

  <div class="rounded-2xl border p-5" style="border-color:var(--line);background:var(--card)">
    <h3 class="mb-4 text-[14px] font-extrabold tracking-tight" style="color:var(--accent)">Admin Şifresini Değiştir</h3>
    <div class="flex flex-col gap-3 sm:flex-row">
      <input id="pw_cur" type="password" placeholder="Mevcut şifre" class="flex-1 rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)">
      <input id="pw_new" type="password" placeholder="Yeni şifre (en az 6 karakter)" class="flex-1 rounded-xl border px-3.5 py-2.5 text-sm" style="border-color:var(--line);background:var(--bg)">
      <button onclick="changePassword()" class="rounded-xl px-4 py-2.5 text-sm font-bold transition active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">Güncelle</button>
    </div>
  </div>
</section>

</main>
</div>

<?php require __DIR__ . '/../includes/fab.php'; ?>

<script>
window.SS = <?= json_encode([
    'base' => $base,
    'canManage' => true,
    'siteName' => $S['siteName'],
    'owner' => [
        'name' => $owner['name'],
        'username' => $owner['username'],
        'avatar' => $owner['avatar'],
        'verified' => (bool)$owner['verified'],
    ],
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
</script>
<script src="<?= e($base) ?>/assets/app.js" defer></script>
<script>
(function () {
  var BASE = <?= json_encode($base) ?>;
  function api(path, opts) {
    opts = opts || {};
    opts.headers = Object.assign({ "Content-Type": "application/json" }, opts.headers || {});
    return fetch(BASE + "/api/" + path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        return { ok: r.ok, data: j };
      });
    });
  }
  function adminApi(action, body) {
    return api("admin.php?action=" + action, { method: "POST", body: JSON.stringify(body || {}) });
  }
  function toastIt(m) { if (window.toast) return; }

  /* ---------- Sekme geçişi (URL hash ile kalıcı) ---------- */
  function activate(tab) {
    document.querySelectorAll("[data-tab]").forEach(function (b) {
      var on = b.getAttribute("data-tab") === tab;
      b.style.background = on ? "var(--accent)" : "";
      b.style.color = on ? "var(--accent-ink)" : "var(--muted)";
    });
    document.querySelectorAll("[data-tabpanel]").forEach(function (p) {
      var on = p.getAttribute("data-tabpanel") === tab;
      p.classList.toggle("hidden", !on);
      p.classList.toggle("flex", on);
    });
  }
  document.querySelectorAll("[data-tab]").forEach(function (b) {
    b.addEventListener("click", function () {
      location.hash = b.getAttribute("data-tab");
    });
  });
  window.addEventListener("hashchange", function () {
    activate(location.hash.replace("#", "") || "genel");
  });
  activate(location.hash.replace("#", "") || "genel");

  /* ---------- Video işlemleri ---------- */
  window.adminEditVideo = function (p) {
    document.getElementById("vm_id").value = p.id;
    document.getElementById("vm_url").value = p.videoUrl;
    document.getElementById("vm_poster").value = p.posterUrl || "";
    document.getElementById("vm_title").value = p.title || "";
    document.getElementById("vm_desc").value = p.description || "";
    window.setToggle(document.getElementById("vm_pinned"), !!p.pinned);
    document.getElementById("videoModalTitle").textContent = "Videoyu Düzenle";
    document.getElementById("vm_submit").textContent = "Güncelle";
    window.openModal("videoModal");
  };
  window.pinVideo = function (id, pin) {
    api("video.php?id=" + id, { method: "PATCH", body: JSON.stringify({ pinned: pin }) })
      .then(function (r) { if (r.ok) location.reload(); });
  };
  window.delVideo = function (id) {
    if (!confirm("Bu video kalıcı olarak silinsin mi?")) return;
    api("video.php?id=" + id, { method: "DELETE" })
      .then(function (r) { if (r.ok) location.reload(); });
  };

  /* ---------- Hikaye işlemleri ---------- */
  window.addStory = function () {
    var url = document.getElementById("quickStoryUrl").value.trim();
    if (!url) return;
    var isVideo = /\.(mp4|webm|mov)(\?|$)/i.test(url);
    api("stories.php", {
      method: "POST",
      body: JSON.stringify({ mediaUrl: url, mediaType: isVideo ? "video" : "image", hours: 24 }),
    }).then(function (r) { if (r.ok) location.reload(); });
  };
  window.delStory = function (id) {
    api("stories.php?id=" + id, { method: "DELETE" })
      .then(function (r) { if (r.ok) location.reload(); });
  };

  /* ---------- Emlak işlemleri ---------- */
  window.adminEditListing = function (l) {
    document.getElementById("lm_id").value = l.id;
    document.getElementById("lm_title").value = l.title;
    document.getElementById("lm_type").value = l.type;
    document.getElementById("lm_status").value = l.status;
    document.getElementById("lm_price").value = l.price;
    document.getElementById("lm_rooms").value = l.rooms;
    document.getElementById("lm_area").value = l.area || "";
    document.getElementById("lm_floor").value = l.floor;
    document.getElementById("lm_heating").value = l.heating;
    document.getElementById("lm_district").value = l.district;
    document.getElementById("lm_phone").value = l.phone || "";
    document.getElementById("lm_desc").value = l.description;
    document.getElementById("listingModalTitle").textContent = "İlanı Düzenle";
    document.getElementById("lm_submit").textContent = "Güncelle";
    window.openModal("listingModal");
    // Görseller: gizli alana yaz
    if (window.ssLoadListingImages) window.ssLoadListingImages(l.images || []);
    else setTimeout(function () { if (window.ssLoadListingImages) window.ssLoadListingImages(l.images || []); }, 300);
  };
  window.listingStatus = function (id, status) {
    api("listing.php?id=" + id, { method: "PATCH", body: JSON.stringify({ status: status }) })
      .then(function (r) { if (r.ok) location.reload(); });
  };
  window.pinListing = function (id, pin) {
    api("listing.php?id=" + id, { method: "PATCH", body: JSON.stringify({ pinned: pin }) })
      .then(function (r) { if (r.ok) location.reload(); });
  };
  window.delListing = function (id) {
    if (!confirm("Bu ilan kalıcı olarak silinsin mi?")) return;
    api("listing.php?id=" + id, { method: "DELETE" })
      .then(function (r) { if (r.ok) location.reload(); });
  };
  // Emlak admin filtreleri
  document.querySelectorAll("[data-afilter]").forEach(function (chip) {
    chip.addEventListener("click", function () {
      var f = chip.getAttribute("data-afilter");
      document.querySelectorAll("[data-afilter]").forEach(function (c) {
        var on = c === chip;
        c.style.background = on ? "var(--ink)" : "var(--card)";
        c.style.color = on ? "var(--bg)" : "var(--muted)";
        c.style.borderColor = on ? "var(--ink)" : "var(--line)";
      });
      document.querySelectorAll("[data-arow]").forEach(function (row) {
        var type = row.getAttribute("data-atype"), status = row.getAttribute("data-astatus");
        var show = true;
        if (f === "satilik" || f === "kiralik") show = type === f;
        else if (f === "satildi" || f === "kiralandi") show = status === f;
        row.style.display = show ? "" : "none";
      });
    });
  });

  /* ---------- Banner işlemleri ---------- */
  var banners = <?= json_encode(array_values($banners), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  function persistBanners() {
    return adminApi("settings", { key: "banners", value: JSON.stringify(banners) });
  }
  window.bannerNew = function () {
    document.getElementById("bn_idx").value = "-1";
    document.getElementById("bn_image").value = "";
    document.getElementById("bn_title").value = "";
    document.getElementById("bn_link").value = "";
    document.getElementById("bn_position").value = "feed-top";
    window.setToggle(document.getElementById("bn_active"), true);
    document.getElementById("bannerModalTitle").textContent = "Yeni Banner";
    window.openModal("bannerModal");
  };
  window.bannerEdit = function (i) {
    var b = banners[i];
    document.getElementById("bn_idx").value = String(i);
    document.getElementById("bn_image").value = b.imageUrl || "";
    document.getElementById("bn_title").value = b.title || "";
    document.getElementById("bn_link").value = b.linkUrl || "";
    document.getElementById("bn_position").value = b.position || "feed-top";
    window.setToggle(document.getElementById("bn_active"), !!b.active);
    document.getElementById("bannerModalTitle").textContent = "Bannerı Düzenle";
    window.openModal("bannerModal");
  };
  window.bannerSave = function () {
    var idx = parseInt(document.getElementById("bn_idx").value, 10);
    var data = {
      imageUrl: document.getElementById("bn_image").value,
      title: document.getElementById("bn_title").value,
      linkUrl: document.getElementById("bn_link").value,
      position: document.getElementById("bn_position").value,
      active: document.getElementById("bn_active").getAttribute("data-toggle") === "1",
    };
    if (!data.imageUrl.trim()) return alert("Banner görseli gerekli");
    if (idx >= 0 && banners[idx]) {
      data.id = banners[idx].id;
      banners[idx] = data;
    } else {
      data.id = "bnr-" + Math.random().toString(36).slice(2, 9);
      banners.push(data);
    }
    persistBanners().then(function (r) { if (r.ok) location.reload(); });
  };
  window.bannerToggle = function (i) {
    banners[i].active = !banners[i].active;
    persistBanners().then(function (r) { if (r.ok) location.reload(); });
  };
  window.bannerDel = function (i) {
    if (!confirm("Banner silinsin mi?")) return;
    banners.splice(i, 1);
    persistBanners().then(function (r) { if (r.ok) location.reload(); });
  };

  /* ---------- Görünüm ---------- */
  window.colorChanged = function (id, value) {
    var hex = document.querySelector('[data-hex="' + id + '"]');
    if (hex) hex.textContent = value.toUpperCase();
  };
  window.applyPreset = function (p) {
    document.getElementById("c_accent").value = p.accent;
    document.getElementById("c_accentInk").value = p.accentInk;
    document.getElementById("c_gradientFrom").value = p.gradientFrom;
    document.getElementById("c_gradientTo").value = p.gradientTo;
    document.getElementById("c_bg").value = p.bg;
    document.getElementById("c_card").value = p.card;
    document.getElementById("c_ink").value = p.ink;
    document.getElementById("c_muted").value = p.muted;
    document.getElementById("c_line").value = p.line;
    Object.keys(p).forEach(function (k) {
      var map = { accent: "c_accent", accentInk: "c_accentInk", gradientFrom: "c_gradientFrom", gradientTo: "c_gradientTo", bg: "c_bg", card: "c_card", ink: "c_ink", muted: "c_muted", line: "c_line" };
      if (map[k]) window.colorChanged(map[k], p[k]);
    });
  };
  window.saveAppearance = function () {
    var theme = {
      accent: document.getElementById("c_accent").value,
      accentInk: document.getElementById("c_accentInk").value,
      gradientFrom: document.getElementById("c_gradientFrom").value,
      gradientTo: document.getElementById("c_gradientTo").value,
      bg: document.getElementById("c_bg").value,
      card: document.getElementById("c_card").value,
      ink: document.getElementById("c_ink").value,
      muted: document.getElementById("c_muted").value,
      line: document.getElementById("c_line").value,
      radius: document.getElementById("c_radius").value + "px",
    };
    Promise.all([
      adminApi("settings", { key: "theme", value: JSON.stringify(theme) }),
      adminApi("settings", { key: "site_name", value: document.getElementById("m_siteName").value }),
      adminApi("settings", { key: "tagline", value: document.getElementById("m_tagline").value }),
      adminApi("settings", { key: "logo_url", value: document.getElementById("m_logoUrl").value }),
      adminApi("settings", { key: "footer_text", value: document.getElementById("m_footerText").value }),
    ]).then(function (rs) {
      if (rs.every(function (r) { return r.ok; })) location.reload();
    });
  };

  /* ---------- Profil ---------- */
  window.saveProfile = function () {
    var owner = {
      name: document.getElementById("p_name").value,
      username: document.getElementById("p_username").value,
      avatar: document.getElementById("p_avatar").value,
      bio: document.getElementById("p_bio").value,
      verified: document.getElementById("p_verified").getAttribute("data-toggle") === "1",
      whatsapp: document.getElementById("p_whatsapp").value,
      instagram: document.getElementById("p_instagram").value,
      email: document.getElementById("p_email").value,
    };
    adminApi("settings", { key: "owner", value: JSON.stringify(owner) })
      .then(function (r) { if (r.ok) location.reload(); });
  };

  /* ---------- SEO ---------- */
  window.saveSeo = function () {
    var seo = {
      title: document.getElementById("s_title").value,
      description: document.getElementById("s_desc").value,
      keywords: document.getElementById("s_keywords").value,
      ogImage: document.getElementById("s_og").value,
    };
    adminApi("settings", { key: "seo", value: JSON.stringify(seo) })
      .then(function (r) { if (r.ok) location.reload(); });
  };

  /* ---------- Güvenlik ---------- */
  window.registerOwnerIp = function (ip) {
    adminApi("me").then(function () {
      adminApi("settings", { key: "owner_ips", value: <?= json_encode(implode(',', $ownerIpList)) ?> .split(",").filter(Boolean).concat([ip]).filter(function (v, i, a) { return v && a.indexOf(v) === i; }).join(",") })
        .then(function (r) { if (r.ok) location.reload(); });
    });
  };
  window.removeOwnerIp = function (ip) {
    var list = <?= json_encode(implode(',', $ownerIpList)) ?> .split(",").filter(function (v) { return v && v !== ip; });
    adminApi("settings", { key: "owner_ips", value: list.join(",") })
      .then(function (r) { if (r.ok) location.reload(); });
  };
  window.banIp = function (ip, reason) {
    adminApi("ban", { ip: ip, reason: reason || "" })
      .then(function (r) { if (r.ok) location.reload(); });
  };
  window.banForm = function () {
    var ip = document.getElementById("ban_ip").value.trim();
    if (!ip) return;
    window.banIp(ip, document.getElementById("ban_reason").value);
  };
  window.unbanIp = function (ip) {
    fetch(BASE + "/api/admin.php?action=unban&ip=" + encodeURIComponent(ip), { method: "DELETE" })
      .then(function (r) { return r.json(); })
      .then(function (j) { if (j.ok) location.reload(); });
  };
  document.getElementById("push_on_post").addEventListener("click", function () {
    var on = this.getAttribute("data-toggle") === "1";
    adminApi("settings", { key: "push_on_post", value: on ? "1" : "0" });
  });
  window.testPush = function () {
    api("push_send.php", {
      method: "POST",
      body: JSON.stringify({
        title: <?= json_encode($S['siteName']) ?>,
        body: "Test bildirimi: Bildirim sistemi sorunsuz çalışıyor!",
        url: BASE + "/index.php",
      }),
    }).then(function (r) {
      if (r.ok) alert(r.data.sent + " aboneye bildirim gönderildi (" + r.data.total + " kayıt)");
    });
  };
  window.changePassword = function () {
    var cur = document.getElementById("pw_cur").value;
    var nxt = document.getElementById("pw_new").value;
    if (!cur || nxt.length < 6) return alert("Yeni şifre en az 6 karakter olmalı");
    adminApi("password", { current: cur, next: nxt }).then(function (r) {
      if (r.ok) { alert("Şifre güncellendi"); document.getElementById("pw_cur").value = ""; document.getElementById("pw_new").value = ""; }
      else alert(r.data.error || "Şifre değiştirilemedi");
    });
  };
})();
</script>
</body>
</html>
