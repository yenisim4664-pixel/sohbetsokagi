<?php
/** Admin çıkışı */
require_once __DIR__ . '/../includes/functions.php';
revokeAdmin();
header('Location: ../index.php');
exit;
