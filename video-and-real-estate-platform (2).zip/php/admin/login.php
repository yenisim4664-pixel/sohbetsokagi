<?php
/**
 * SOHBET SOKAĞI — Admin girişi
 */
require_once __DIR__ . '/../includes/functions.php';

if (isAdmin()) {
    header('Location: index.php');
    exit;
}
$S = siteData();
$base = baseUrl();
?><!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<title>Admin Girişi — <?= e($S['siteName']) ?></title>
<meta name="robots" content="noindex, nofollow">
<script src="https://cdn.tailwindcss.com"></script>
<link rel="stylesheet" href="<?= e($base) ?>/assets/site.css">
</head>
<body style="<?= themeStyle($S['theme']) ?>background:var(--bg);color:var(--ink)">
<div class="flex min-h-dvh items-center justify-center px-4">
  <form id="loginForm" class="animate-scale-in w-full max-w-sm rounded-3xl border p-7 shadow-xl" style="border-color:var(--line);background:var(--card)">
    <div class="flex flex-col items-center text-center">
      <span class="ring-gradient flex h-14 w-14 items-center justify-center rounded-2xl text-white shadow-lg">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1 1 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/></svg>
      </span>
      <h1 class="mt-4 text-xl font-extrabold tracking-tight"><?= e($S['siteName']) ?> Admin</h1>
      <p class="mt-1 text-[12.5px] font-semibold" style="color:var(--muted)">Yönetim paneline erişmek için şifrenizi girin</p>
    </div>
    <div class="mt-6 space-y-3">
      <div class="relative">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2" style="color:var(--muted)"><rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
        <input id="pw" type="password" placeholder="Admin şifresi" autofocus
               class="w-full rounded-xl border py-2.5 pl-10 pr-3.5 text-sm focus:outline-none" style="border-color:var(--line);background:var(--bg)">
      </div>
      <p id="err" class="hidden rounded-xl bg-rose-500/10 px-3.5 py-2.5 text-[12px] font-bold text-rose-500"></p>
      <button type="submit" id="btn" class="flex w-full items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-bold shadow-sm transition active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">
        Panele Giriş Yap
      </button>
      <p class="pt-1 text-center text-[10.5px] font-semibold leading-relaxed" style="color:var(--muted)">
        Varsayılan şifre: <b>admin123</b> — ilk girişte Güvenlik sekmesinden değiştirmeyi unutmayın.
      </p>
    </div>
  </form>
</div>
<script>
document.getElementById('loginForm').addEventListener('submit', function (e) {
  e.preventDefault();
  var err = document.getElementById('err');
  var btn = document.getElementById('btn');
  err.classList.add('hidden');
  btn.disabled = true;
  btn.textContent = 'Kontrol ediliyor...';
  fetch('<?= e($base) ?>/api/admin.php?action=login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password: document.getElementById('pw').value }),
  }).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
    .then(function (r) {
      if (r.ok) {
        location.href = 'index.php';
      } else {
        err.textContent = r.j.error || 'Giriş başarısız';
        err.classList.remove('hidden');
        btn.disabled = false;
        btn.textContent = 'Panele Giriş Yap';
      }
    })
    .catch(function () {
      err.textContent = 'Bağlantı hatası';
      err.classList.remove('hidden');
      btn.disabled = false;
      btn.textContent = 'Panele Giriş Yap';
    });
});
</script>
</body>
</html>
