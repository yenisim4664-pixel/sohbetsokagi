<?php
/**
 * API: Yönetim — giriş/çıkış, istatistikler, ayarlar, şifre, IP yasakları
 * Kullanım: api/admin.php?action=login|logout|me|stats|settings|password|ban|unban
 */
require_once __DIR__ . '/../includes/functions.php';

$action = (string) ($_GET['action'] ?? '');
$method = $_SERVER['REQUEST_METHOD'];
$body = jsonBody();

/* ---------------- GİRİŞ ---------------- */
if ($action === 'login') {
    if ($method !== 'POST') jsonResponse(['error' => 'Yöntem desteklenmiyor'], 405);
    // Oturum bazlı deneme sınırlama
    $fails = $_SESSION['ss_login_fails'] ?? 0;
    $until = $_SESSION['ss_login_until'] ?? 0;
    if ($until > time()) {
        jsonResponse(['error' => 'Çok fazla hatalı deneme. 10 dakika bekleyin.'], 429);
    }
    if (!verifyAdminPassword((string) ($body['password'] ?? ''))) {
        $fails++;
        $_SESSION['ss_login_fails'] = $fails;
        if ($fails >= 8) {
            $_SESSION['ss_login_until'] = time() + 600;
            $_SESSION['ss_login_fails'] = 0;
        }
        jsonResponse(['error' => 'Şifre hatalı'], 401);
    }
    unset($_SESSION['ss_login_fails'], $_SESSION['ss_login_until']);
    grantAdmin();
    jsonResponse(['ok' => true]);
}

if ($action === 'logout') {
    revokeAdmin();
    jsonResponse(['ok' => true]);
}

if ($action === 'me') {
    jsonResponse(['authed' => isAdmin(), 'ip' => clientIp()]);
}

/* ---------------- Bundan sonrası admin yetkisi ister ---------------- */
requireAdminApi();

/* ---------------- İSTATİSTİKLER ---------------- */
if ($action === 'stats') {
    $v = dbOne('SELECT COUNT(*) AS c, COALESCE(SUM(views),0) AS sv, COALESCE(SUM(likes),0) AS sl FROM videos') ?: [];
    $l = dbOne("SELECT COUNT(*) AS c, COALESCE(SUM(status='aktif'),0) AS aktif, COALESCE(SUM(views),0) AS sv FROM listings") ?: [];
    $s = dbOne('SELECT COUNT(*) AS c FROM stories WHERE expires_at > NOW()') ?: [];
    $today = dbOne('SELECT COUNT(*) AS c, COUNT(DISTINCT ip) AS u FROM visits WHERE created_at >= CURDATE()') ?: [];
    $total = dbOne('SELECT COUNT(*) AS c FROM visits') ?: [];
    $recent = dbAll('SELECT ip, path, created_at AS createdAt FROM visits ORDER BY id DESC LIMIT 18');
    $suspicious = dbAll(
        'SELECT ip, COUNT(*) AS hits FROM visits
         WHERE created_at > NOW() - INTERVAL 6 HOUR
         GROUP BY ip HAVING COUNT(*) > 120
         ORDER BY hits DESC LIMIT 12'
    );
    $bans = dbAll('SELECT * FROM banned_ips ORDER BY created_at DESC');
    jsonResponse([
        'videos' => (int) ($v['c'] ?? 0),
        'totalViews' => (int) ($v['sv'] ?? 0),
        'totalLikes' => (int) ($v['sl'] ?? 0),
        'listings' => (int) ($l['c'] ?? 0),
        'activeListings' => (int) ($l['aktif'] ?? 0),
        'listingViews' => (int) ($l['sv'] ?? 0),
        'activeStories' => (int) ($s['c'] ?? 0),
        'visitsToday' => (int) ($today['c'] ?? 0),
        'uniqueToday' => (int) ($today['u'] ?? 0),
        'visitsTotal' => (int) ($total['c'] ?? 0),
        'pushSubs' => pushSubCountSafe(),
        'recentVisits' => $recent,
        'suspicious' => $suspicious,
        'bans' => $bans,
        'currentIp' => clientIp(),
    ]);
}

/* ---------------- AYAR KAYDI ---------------- */
if ($action === 'settings') {
    if ($method !== 'POST') jsonResponse(['error' => 'Yöntem desteklenmiyor'], 405);
    $whitelist = [
        'site_name', 'tagline', 'logo_url', 'footer_text',
        'theme', 'owner', 'seo', 'banners', 'owner_ips', 'push_on_post',
    ];
    $key = (string) ($body['key'] ?? '');
    if (!in_array($key, $whitelist, true)) {
        jsonResponse(['error' => 'Geçersiz ayar'], 400);
    }
    $value = is_string($body['value'] ?? null) ? $body['value'] : json_encode($body['value'] ?? '', JSON_UNESCAPED_UNICODE);
    if (in_array($key, ['theme', 'owner', 'seo', 'banners'], true)) {
        json_decode($value, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            jsonResponse(['error' => 'Geçersiz JSON'], 400);
        }
    }
    setSetting($key, $value);
    jsonResponse(['ok' => true]);
}

/* ---------------- ŞİFRE DEĞİŞTİRME ---------------- */
if ($action === 'password') {
    if ($method !== 'POST') jsonResponse(['error' => 'Yöntem desteklenmiyor'], 405);
    if (!verifyAdminPassword((string) ($body['current'] ?? ''))) {
        jsonResponse(['error' => 'Mevcut şifre hatalı'], 401);
    }
    $next = (string) ($body['next'] ?? '');
    if (strlen($next) < 6) {
        jsonResponse(['error' => 'Yeni şifre en az 6 karakter olmalı'], 400);
    }
    setSetting('admin_password_hash', hashPassword($next));
    jsonResponse(['ok' => true]);
}

/* ---------------- IP YASAKLAMA ---------------- */
if ($action === 'ban') {
    if ($method !== 'POST') jsonResponse(['error' => 'Yöntem desteklenmiyor'], 405);
    $ip = trim((string) ($body['ip'] ?? ''));
    if (!preg_match('/^[\d.:a-fA-F]{3,45}$/', $ip)) {
        jsonResponse(['error' => 'Geçersiz IP adresi'], 400);
    }
    dbRun('INSERT IGNORE INTO banned_ips (ip, reason) VALUES (?, ?)', [
        $ip,
        mb_substr((string) ($body['reason'] ?? ''), 0, 200),
    ]);
    jsonResponse(['ok' => true]);
}

if ($action === 'unban') {
    $ip = (string) ($_GET['ip'] ?? ($body['ip'] ?? ''));
    if (!$ip) jsonResponse(['error' => 'IP gerekli'], 400);
    dbRun('DELETE FROM banned_ips WHERE ip = ?', [$ip]);
    jsonResponse(['ok' => true]);
}

jsonResponse(['error' => 'Bilinmeyen işlem'], 404);

/* webpush.php yüklenmediyse patlama olmasın */
function pushSubCountSafe(): int
{
    try {
        if (!function_exists('pushSubCount')) {
            require_once __DIR__ . '/../includes/webpush.php';
        }
        return pushSubCount();
    } catch (Throwable $e) {
        return 0;
    }
}
