<?php
/**
 * API: Tekil ilan — güncelle / sil (sahip/admin), görüntülenme (herkese açık)
 */
require_once __DIR__ . '/../includes/functions.php';

$id = (int) ($_GET['id'] ?? 0);
if (!$id) jsonResponse(['error' => 'Geçersiz id'], 400);
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'PATCH' || $method === 'POST') {
    $body = jsonBody();

    // Herkese açık görüntülenme sayacı
    if (($body['action'] ?? '') === 'view') {
        dbRun('UPDATE listings SET views = views + 1 WHERE id = ?', [$id]);
        jsonResponse(['ok' => true]);
    }

    requireManageApi();
    $sets = [];
    $params = [];
    $str = function ($k, $col, $max) use (&$sets, &$params, $body) {
        if (isset($body[$k])) { $sets[] = "$col = ?"; $params[] = mb_substr((string) $body[$k], 0, $max); }
    };
    $str('title', 'title', 200);
    $str('description', 'description', 4000);
    $str('rooms', 'rooms', 20);
    $str('floor', 'floor', 30);
    $str('heating', 'heating', 40);
    $str('district', 'district', 60);
    $str('phone', 'phone', 20);
    if (isset($body['price'])) { $sets[] = 'price = ?'; $params[] = max(0, (int) $body['price']); }
    if (isset($body['area'])) { $sets[] = 'area = ?'; $params[] = max(0, (int) $body['area']); }
    if (isset($body['type'])) { $sets[] = 'type = ?'; $params[] = $body['type'] === 'kiralik' ? 'kiralik' : 'satilik'; }
    if (isset($body['status'])) { $sets[] = 'status = ?'; $params[] = in_array($body['status'], ['satildi', 'kiralandi'], true) ? $body['status'] : 'aktif'; }
    if (isset($body['pinned'])) { $sets[] = 'pinned = ?'; $params[] = !empty($body['pinned']) ? 1 : 0; }
    if (isset($body['images']) && is_array($body['images'])) {
        $sets[] = 'images = ?';
        $params[] = json_encode(array_slice(array_values(array_filter(array_map('strval', $body['images']))), 0, 10), JSON_UNESCAPED_UNICODE);
    }
    if (!$sets) jsonResponse(['error' => 'Güncellenecek alan yok'], 400);
    $params[] = $id;
    dbRun('UPDATE listings SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);
    $row = dbOne('SELECT * FROM listings WHERE id = ?', [$id]);
    if (!$row) jsonResponse(['error' => 'Bulunamadı'], 404);
    jsonResponse(['listing' => listingToJson($row)]);
}

if ($method === 'DELETE') {
    requireManageApi();
    dbRun('DELETE FROM listings WHERE id = ?', [$id]);
    jsonResponse(['ok' => true]);
}

jsonResponse(['error' => 'Yöntem desteklenmiyor'], 405);
