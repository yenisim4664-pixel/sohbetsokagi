<?php
/**
 * API: Web Push — VAPID genel anahtarı + abonelik kaydı/silme
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/webpush.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    try {
        $keys = ensureVapidKeys();
        jsonResponse(['publicKey' => $keys['publicKey']]);
    } catch (Throwable $e) {
        jsonResponse(['error' => 'Push desteklenmiyor'], 500);
    }
}

if ($method === 'POST') {
    $body = jsonBody();
    $sub = $body['subscription'] ?? null;
    $endpoint = $sub['endpoint'] ?? '';
    if (!$endpoint) jsonResponse(['error' => 'Geçersiz abonelik'], 400);
    $json = json_encode($sub, JSON_UNESCAPED_UNICODE);
    dbRun(
        'INSERT INTO push_subscriptions (endpoint, data) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE data = VALUES(data)',
        [$endpoint, $json]
    );
    jsonResponse(['ok' => true]);
}

if ($method === 'DELETE') {
    $body = jsonBody();
    $endpoint = $body['endpoint'] ?? '';
    if ($endpoint) {
        dbRun('DELETE FROM push_subscriptions WHERE endpoint = ?', [$endpoint]);
    }
    jsonResponse(['ok' => true]);
}

jsonResponse(['error' => 'Yöntem desteklenmiyor'], 405);
