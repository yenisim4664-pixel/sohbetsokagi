<?php
/**
 * API: Video listesi (herkese açık) + yeni video (sahip/admin)
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/webpush.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $offset = max(0, (int) ($_GET['offset'] ?? 0));
    $limit = min(20, max(1, (int) ($_GET['limit'] ?? 4)));
    $take = $limit + 1;
    $rows = dbAll(
        "SELECT * FROM videos ORDER BY pinned DESC, created_at DESC LIMIT $take OFFSET $offset"
    );
    $hasMore = count($rows) > $limit;
    $rows = array_slice($rows, 0, $limit);
    jsonResponse([
        'videos' => array_map('videoToJson', $rows),
        'hasMore' => $hasMore,
    ]);
}

if ($method === 'POST') {
    requireManageApi();
    $body = jsonBody();
    $videoUrl = trim((string) ($body['videoUrl'] ?? ''));
    if ($videoUrl === '') {
        jsonResponse(['error' => 'Video adresi gerekli'], 400);
    }
    dbRun(
        'INSERT INTO videos (title, description, video_url, poster_url, pinned) VALUES (?, ?, ?, ?, ?)',
        [
            mb_substr((string) ($body['title'] ?? ''), 0, 200),
            mb_substr((string) ($body['description'] ?? ''), 0, 3000),
            $videoUrl,
            (string) ($body['posterUrl'] ?? ''),
            !empty($body['pinned']) ? 1 : 0,
        ]
    );
    $row = dbOne('SELECT * FROM videos WHERE id = ?', [dbLastId()]);

    // Yeni videoda abonelere push bildirimi
    try {
        $S = siteData();
        if ($S['pushOnPost']) {
            sendPushToAll(pushPayload(
                $S['siteName'],
                $row['title'] ? 'Yeni video: ' . $row['title'] : 'Yeni bir video yayınlandı!',
                baseUrl() . '/index.php'
            ));
        }
    } catch (Throwable $e) {
        // Bildirim hatası paylaşımı engellemez
    }
    jsonResponse(['video' => videoToJson($row)]);
}

jsonResponse(['error' => 'Yöntem desteklenmiyor'], 405);
