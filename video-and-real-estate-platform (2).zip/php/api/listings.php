<?php
/**
 * API: Emlak ilanları — liste (herkese açık) + yeni ilan (sahip/admin)
 */
require_once __DIR__ . '/../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $rows = dbAll('SELECT * FROM listings ORDER BY pinned DESC, created_at DESC LIMIT 200');
    jsonResponse(['listings' => array_map('listingToJson', $rows)]);
}

if ($method === 'POST') {
    requireManageApi();
    $body = jsonBody();
    $title = trim((string) ($body['title'] ?? ''));
    if ($title === '') jsonResponse(['error' => 'İlan başlığı gerekli'], 400);
    $images = [];
    if (isset($body['images']) && is_array($body['images'])) {
        $images = array_slice(array_values(array_filter(array_map('strval', $body['images']))), 0, 10);
    }
    dbRun(
        'INSERT INTO listings (title, description, price, type, status, rooms, area, floor, heating, district, images, phone, pinned)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
            mb_substr($title, 0, 200),
            mb_substr((string) ($body['description'] ?? ''), 0, 4000),
            max(0, (int) ($body['price'] ?? 0)),
            ($body['type'] ?? '') === 'kiralik' ? 'kiralik' : 'satilik',
            in_array($body['status'] ?? '', ['satildi', 'kiralandi'], true) ? $body['status'] : 'aktif',
            mb_substr((string) ($body['rooms'] ?? ''), 0, 20),
            max(0, (int) ($body['area'] ?? 0)),
            mb_substr((string) ($body['floor'] ?? ''), 0, 30),
            mb_substr((string) ($body['heating'] ?? ''), 0, 40),
            mb_substr((string) ($body['district'] ?? ''), 0, 60),
            json_encode($images, JSON_UNESCAPED_UNICODE),
            mb_substr((string) ($body['phone'] ?? ''), 0, 20),
            !empty($body['pinned']) ? 1 : 0,
        ]
    );
    $row = dbOne('SELECT * FROM listings WHERE id = ?', [dbLastId()]);
    jsonResponse(['listing' => listingToJson($row)]);
}

jsonResponse(['error' => 'Yöntem desteklenmiyor'], 405);
