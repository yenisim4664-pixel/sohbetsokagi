<?php
/**
 * API: Test/toplu bildirim gönderimi (sadece admin oturumu)
 */
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/webpush.php';

requireAdminApi();

$body = jsonBody();
$result = sendPushToAll(pushPayload(
    (string) ($body['title'] ?? 'Sohbet Sokağı'),
    (string) ($body['body'] ?? 'Yeni bir içerik sizi bekliyor!'),
    (string) ($body['url'] ?? baseUrl() . '/index.php')
));
jsonResponse($result);
