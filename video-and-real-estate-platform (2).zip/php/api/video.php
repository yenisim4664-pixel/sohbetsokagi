<?php
/**
 * API: Tekil video güncelleme / silme (sahip/admin)
 */
require_once __DIR__ . '/../includes/functions.php';

$id = (int) ($_GET['id'] ?? 0);
if (!$id) jsonResponse(['error' => 'Geçersiz id'], 400);

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'PATCH' || $method === 'POST') {
    requireManageApi();
    $body = jsonBody();
    $sets = [];
    $params = [];
    if (isset($body['title'])) { $sets[] = 'title = ?'; $params[] = mb_substr((string) $body['title'], 0, 200); }
    if (isset($body['description'])) { $sets[] = 'description = ?'; $params[] = mb_substr((string) $body['description'], 0, 3000); }
    if (!empty($body['videoUrl'])) { $sets[] = 'video_url = ?'; $params[] = trim((string) $body['videoUrl']); }
    if (isset($body['posterUrl'])) { $sets[] = 'poster_url = ?'; $params[] = (string) $body['posterUrl']; }
    if (isset($body['pinned'])) { $sets[] = 'pinned = ?'; $params[] = !empty($body['pinned']) ? 1 : 0; }
    if (!$sets) jsonResponse(['error' => 'Güncellenecek alan yok'], 400);
    $params[] = $id;
    dbRun('UPDATE videos SET ' . implode(', ', $sets) . ' WHERE id = ?', $params);
    $row = dbOne('SELECT * FROM videos WHERE id = ?', [$id]);
    if (!$row) jsonResponse(['error' => 'Bulunamadı'], 404);
    jsonResponse(['video' => videoToJson($row)]);
}

if ($method === 'DELETE') {
    requireManageApi();
    dbRun('DELETE FROM videos WHERE id = ?', [$id]);
    dbRun('DELETE FROM likes WHERE video_id = ?', [$id]);
    jsonResponse(['ok' => true]);
}

jsonResponse(['error' => 'Yöntem desteklenmiyor'], 405);
