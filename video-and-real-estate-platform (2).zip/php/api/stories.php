<?php
/**
 * API: Hikayeler — liste (herkese açık), ekle/sil (sahip/admin)
 * 24 saati geçen hikayeler her okumada otomatik silinir.
 */
require_once __DIR__ . '/../includes/functions.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    jsonResponse(['stories' => array_map('storyToJson', activeStories())]);
}

if ($method === 'POST') {
    requireManageApi();
    $body = jsonBody();
    $mediaUrl = trim((string) ($body['mediaUrl'] ?? ''));
    if ($mediaUrl === '') jsonResponse(['error' => 'Medya adresi gerekli'], 400);
    $hours = min(48, max(1, (int) ($body['hours'] ?? 24)));
    $mediaType = ($body['mediaType'] ?? 'image') === 'video' ? 'video' : 'image';
    dbRun(
        'INSERT INTO stories (media_url, media_type, expires_at) VALUES (?, ?, NOW() + INTERVAL ? HOUR)',
        [$mediaUrl, $mediaType, $hours]
    );
    $row = dbOne('SELECT * FROM stories WHERE id = ?', [dbLastId()]);
    jsonResponse(['story' => storyToJson($row)]);
}

if ($method === 'DELETE') {
    requireManageApi();
    $id = (int) ($_GET['id'] ?? 0);
    if (!$id) jsonResponse(['error' => 'Geçersiz id'], 400);
    dbRun('DELETE FROM stories WHERE id = ?', [$id]);
    jsonResponse(['ok' => true]);
}

jsonResponse(['error' => 'Yöntem desteklenmiyor'], 405);
