<?php
/**
 * API: Video etkileşimi — görüntülenme / beğeni (herkese açık, IP tekilleştirmeli)
 */
require_once __DIR__ . '/../includes/functions.php';

$id = (int) ($_GET['id'] ?? 0);
if (!$id) jsonResponse(['error' => 'Geçersiz id'], 400);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Yöntem desteklenmiyor'], 405);
}

$body = jsonBody();
$kind = $body['kind'] ?? '';

if ($kind === 'view') {
    dbRun('UPDATE videos SET views = views + 1 WHERE id = ?', [$id]);
    $row = dbOne('SELECT views FROM videos WHERE id = ?', [$id]);
    jsonResponse(['views' => (int) ($row['views'] ?? 0)]);
}

if ($kind === 'like') {
    $ip = clientIp();
    $existing = dbOne('SELECT id FROM likes WHERE video_id = ? AND ip = ? LIMIT 1', [$id, $ip]);
    if ($existing) {
        dbRun('DELETE FROM likes WHERE id = ?', [$existing['id']]);
        dbRun('UPDATE videos SET likes = GREATEST(likes - 1, 0) WHERE id = ?', [$id]);
        $liked = false;
    } else {
        dbRun('INSERT INTO likes (video_id, ip) VALUES (?, ?)', [$id, $ip]);
        dbRun('UPDATE videos SET likes = likes + 1 WHERE id = ?', [$id]);
        $liked = true;
    }
    $row = dbOne('SELECT likes FROM videos WHERE id = ?', [$id]);
    jsonResponse(['liked' => $liked, 'likes' => (int) ($row['likes'] ?? 0)]);
}

jsonResponse(['error' => 'Geçersiz işlem'], 400);
