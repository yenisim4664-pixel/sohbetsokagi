<?php
/**
 * API: Medya yükleme (sahip/admin)
 * Sunucuda ffmpeg varsa videolara otomatik kapak karesi üretir.
 */
require_once __DIR__ . '/../includes/functions.php';

requireManageApi();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Yöntem desteklenmiyor'], 405);
}

if (empty($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
    jsonResponse(['error' => 'Dosya bulunamadı'], 400);
}

$file = $_FILES['file'];
$maxSize = 150 * 1024 * 1024; // 150MB
if ($file['size'] > $maxSize) {
    jsonResponse(['error' => 'Dosya 150MB sınırını aşıyor'], 400);
}

// Gerçek MIME tespiti
$finfo = function_exists('finfo_open') ? finfo_open(FILEINFO_MIME_TYPE) : null;
$mime = $finfo ? finfo_file($finfo, $file['tmp_name']) : ($file['type'] ?? '');
$isImage = strpos($mime, 'image/') === 0;
$isVideo = strpos($mime, 'video/') === 0;
if (!$isImage && !$isVideo) {
    jsonResponse(['error' => 'Sadece görsel veya video yükleyebilirsiniz'], 400);
}

$extMap = [
    'image/jpeg' => '.jpg', 'image/png' => '.png', 'image/webp' => '.webp',
    'image/gif' => '.gif', 'video/mp4' => '.mp4', 'video/webm' => '.webm',
    'video/quicktime' => '.mov',
];
$ext = $extMap[$mime] ?? strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
if ($ext === '' || $ext[0] !== '.') $ext = '.' . $ext;

$ym = date('Ym');
$relDir = 'uploads/' . $ym;
$absDir = __DIR__ . '/../' . $relDir;
if (!is_dir($absDir)) {
    @mkdir($absDir, 0775, true);
}

$name = bin2hex(random_bytes(8)) . $ext;
$absPath = $absDir . '/' . $name;
if (!move_uploaded_file($file['tmp_name'], $absPath)) {
    jsonResponse(['error' => 'Dosya kaydedilemedi (uploads klasör izinlerini kontrol edin)'], 500);
}
@chmod($absPath, 0664);

$url = $relDir . '/' . $name;
$posterUrl = '';

// ffmpeg varsa 1. saniyeden kapak karesi üret
if ($isVideo) {
    $ffmpeg = trim((string) @shell_exec('command -v ffmpeg 2>/dev/null'));
    if ($ffmpeg) {
        $posterName = preg_replace('/\.[^.]+$/', '.jpg', $name);
        $posterAbs = $absDir . '/' . $posterName;
        @shell_exec(
            escapeshellcmd($ffmpeg) . ' -y -ss 1 -i ' . escapeshellarg($absPath)
            . ' -frames:v 1 -q:v 4 ' . escapeshellarg($posterAbs) . ' 2>/dev/null'
        );
        if (file_exists($posterAbs)) {
            $posterUrl = $relDir . '/' . $posterName;
        }
    }
}

jsonResponse([
    'url' => $url,
    'posterUrl' => $posterUrl,
    'mediaType' => $isVideo ? 'video' : 'image',
    'size' => $file['size'],
    'name' => $file['name'],
]);
