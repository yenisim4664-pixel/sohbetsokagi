/* ============================================================
 * SOHBET SOKAĞI — Ön yüz motoru (saf JavaScript, kütüphanesiz)
 * Video oynatıcı, HLS, hikayeler, sonsuz kaydırma, push,
 * sahip hızlı paylaşım araçları, emlak modülü etkileşimleri.
 * ============================================================ */
(function () {
  "use strict";

  var SS = window.SS || { base: "", canManage: false, owner: {} };
  var BASE = SS.base || "";

  /* --------------------- Yardımcılar --------------------- */

  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;").replace(/'/g, "&#039;");
  }

  function toast(msg) {
    var old = $("#ssToast");
    if (old) old.remove();
    var el = document.createElement("div");
    el.id = "ssToast";
    el.className = "animate-toast-in fixed bottom-28 left-1/2 z-[110] max-w-[86vw] -translate-x-1/2 rounded-full border px-4 py-2.5 text-center text-[13px] font-semibold shadow-xl";
    el.style.cssText = "border-color:var(--line);background:var(--ink);color:var(--bg)";
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(function () { el.remove(); }, 2800);
  }

  function timeAgo(iso) {
    var d = new Date(iso).getTime();
    var s = Math.max(1, Math.floor((Date.now() - d) / 1000));
    if (s < 60) return "az önce";
    var m = Math.floor(s / 60);
    if (m < 60) return m + " dk önce";
    var h = Math.floor(m / 60);
    if (h < 24) return h + " sa önce";
    var g = Math.floor(h / 24);
    if (g < 7) return g + " gün önce";
    var hf = Math.floor(g / 7);
    if (hf < 5) return hf + " hf önce";
    var ay = Math.floor(g / 30);
    if (ay < 12) return ay + " ay önce";
    return Math.floor(ay / 12) + " yıl önce";
  }

  function formatCount(n) {
    n = Number(n) || 0;
    if (n < 1000) return String(n);
    function tr(v) {
      var s = v.toFixed(1).replace(".", ",");
      return s.replace(/,0$/, "");
    }
    if (n < 1000000) return tr(n / 1000) + " B";
    return tr(n / 1000000) + " Mn";
  }

  function api(path, opts) {
    opts = opts || {};
    opts.headers = Object.assign({ "Content-Type": "application/json" }, opts.headers || {});
    return fetch(BASE + "/api/" + path, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (j) {
        return { ok: r.ok, status: r.status, data: j };
      });
    });
  }

  function getLiked() {
    try { return JSON.parse(localStorage.getItem("ss_liked") || "[]"); } catch (e) { return []; }
  }
  function setLiked(arr) {
    try { localStorage.setItem("ss_liked", JSON.stringify(arr)); } catch (e) {}
  }

  /* --------------------- Web Push --------------------- */

  function b64ToUint8(base64String) {
    var padding = "=".repeat((4 - (base64String.length % 4)) % 4);
    var base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
    var rawData = atob(base64);
    var arr = new Uint8Array(rawData.length);
    for (var i = 0; i < rawData.length; ++i) arr[i] = rawData.charCodeAt(i);
    return arr;
  }

  (function initPush() {
    var bell = $("#pushBell");
    if (!bell) return;
    if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
      bell.style.display = "none";
      return;
    }
    function setState(state) {
      if (state === "on") {
        bell.style.color = "var(--accent)";
        bell.style.background = "color-mix(in srgb, var(--accent) 10%, transparent)";
        bell.title = "Bildirimler açık";
      }
    }
    navigator.serviceWorker.getRegistration(BASE + "/assets/sw.js").then(function (reg) {
      if (!reg) return;
      reg.pushManager.getSubscription().then(function (sub) {
        if (sub) setState("on");
      });
    }).catch(function () {});
    bell.addEventListener("click", function () {
      navigator.serviceWorker.register(BASE + "/assets/sw.js").then(function (reg) {
        return Notification.requestPermission().then(function (perm) {
          if (perm !== "granted") { toast("Bildirim izni verilmedi"); return null; }
          return fetch(BASE + "/api/push.php").then(function (r) { return r.json(); }).then(function (j) {
            return reg.pushManager.subscribe({
              userVisibleOnly: true,
              applicationServerKey: b64ToUint8(j.publicKey),
            });
          });
        });
      }).then(function (sub) {
        if (!sub) return;
        return api("push.php", { method: "POST", body: JSON.stringify({ subscription: sub.toJSON() }) }).then(function () {
          setState("on");
          toast("Bildirimler açıldı — yeni videoları kaçırmayın!");
        });
      }).catch(function () { toast("Bildirimler açılamadı"); });
    });
  })();

  /* --------------------- Modal & FAB altyapısı --------------------- */

  window.openModal = function (id) {
    var m = document.getElementById(id);
    if (m) m.classList.remove("modal-hidden");
  };
  window.closeModal = function (id) {
    var m = document.getElementById(id);
    if (m) m.classList.add("modal-hidden");
  };

  document.addEventListener("click", function (e) {
    var closer = e.target.closest("[data-modal-close]");
    if (closer) {
      var modal = closer.closest(".fixed.z-\\[90\\]") || closer.closest("[id$='Modal']");
      if (modal && modal.id) modal.classList.add("modal-hidden");
      else if (modal) modal.classList.add("modal-hidden");
    }
    var opener = e.target.closest("[data-fab-open]");
    if (opener) {
      openModal(opener.getAttribute("data-fab-open"));
      var fm = $("#fabMenu");
      if (fm) { fm.classList.add("hidden"); fm.classList.remove("flex"); }
      var fi = $("#fabIcon");
      if (fi) fi.style.transform = "";
    }
  });

  var fabBtn = $("#fabBtn");
  if (fabBtn) {
    fabBtn.addEventListener("click", function () {
      var fm = $("#fabMenu");
      var fi = $("#fabIcon");
      var open = fm.classList.contains("hidden");
      fm.classList.toggle("hidden", !open);
      fm.classList.toggle("flex", open);
      fi.style.transform = open ? "rotate(45deg)" : "";
    });
  }

  // Aç/Kapa (toggle) butonları
  $$("[data-toggle]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      setToggle(btn, btn.getAttribute("data-toggle") !== "1");
    });
  });
  function setToggle(btn, on) {
    btn.setAttribute("data-toggle", on ? "1" : "0");
    var track = $("[data-toggle-track]", btn);
    var dot = $("[data-toggle-dot]", btn);
    if (track) track.style.background = on ? "var(--accent)" : "var(--line)";
    if (dot) dot.style.left = on ? "22px" : "2px";
  }
  window.setToggle = setToggle;

  /* --------------------- Dosya yükleme --------------------- */

  $$("input[data-upload]").forEach(function (input) {
    input.addEventListener("change", function () {
      var files = Array.prototype.slice.call(input.files || []);
      if (!files.length) return;
      var label = input.closest("label") ? $("[data-upload-label]", input.closest("label")) : null;
      var oldLabel = label ? label.textContent : "";
      if (label) label.textContent = "Yükleniyor...";
      var urlTarget = input.getAttribute("data-upload-url");
      var posterTarget = input.getAttribute("data-upload-poster");
      var imagesTarget = input.getAttribute("data-upload-images");
      var uploaded = [];

      function done() {
        if (label) label.textContent = oldLabel;
        input.value = "";
        if (urlTarget && uploaded[0]) {
          var t = $(urlTarget);
          if (t) t.value = uploaded[0].url;
          if (posterTarget && uploaded[0].posterUrl) {
            var pt = $(posterTarget);
            if (pt) pt.value = uploaded[0].posterUrl;
          }
        }
        if (imagesTarget) {
          uploaded.forEach(function (f) { window.ssAddListingImage && window.ssAddListingImage(f.url); });
        }
        toast("Yükleme tamamlandı");
      }

      (function next(i) {
        if (i >= files.length) return done();
        var fd = new FormData();
        fd.append("file", files[i]);
        fetch(BASE + "/api/upload.php", { method: "POST", body: fd })
          .then(function (r) { return r.json(); })
          .then(function (j) { if (j && j.url) uploaded.push(j); })
          .catch(function () {})
          .finally(function () { next(i + 1); });
      })(0);
    });
  });

  // İlan görsel listesi (FAB modali)
  var lmImages = [];
  window.ssAddListingImage = function (url) {
    lmImages.push(url);
    renderLmImages();
  };
  window.ssLoadListingImages = function (arr) {
    lmImages = (arr || []).slice(0, 10);
    renderLmImages();
  };
  function renderLmImages() {
    var wrap = $("#lm_images_preview");
    if (!wrap) return;
    wrap.innerHTML = lmImages.map(function (u, i) {
      return '<div class="relative"><img src="' + esc(u) + '" class="h-16 w-16 rounded-lg border object-cover" style="border-color:var(--line)">' +
        '<button type="button" data-lmimg-del="' + i + '" class="absolute -right-1.5 -top-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-rose-500 text-[10px] font-bold text-white">×</button></div>';
    }).join("");
    $$("[data-lmimg-del]", wrap).forEach(function (b) {
      b.addEventListener("click", function () {
        lmImages.splice(Number(b.getAttribute("data-lmimg-del")), 1);
        renderLmImages();
      });
    });
  }

  /* --------------------- Video Kartları --------------------- */

  function initVideoCard(card) {
    if (card.__vcInit) return;
    card.__vcInit = true;
    var post;
    try { post = JSON.parse(card.getAttribute("data-post")); } catch (e) { return; }
    var manage = card.getAttribute("data-manage") === "1";
    var wrap = $("[data-vwrap]", card);
    var video = $("[data-vplayer]", card);
    var progress = $("[data-vprogress]", card);
    var playHint = $("[data-vplayhint]", card);
    var flashBox = $("[data-vflash]", card);
    var burstBox = $("[data-vburst]", card);
    var near = false, hls = null, viewCounted = false, viewTimer = null, clickTimer = null;

    // Beğeni durumu
    var liked = getLiked().indexOf(post.id) !== -1;
    paintHeart(liked);
    function paintHeart(on) {
      var heart = $("[data-vheart]", card);
      if (!heart) return;
      heart.style.fill = on ? "var(--accent)" : "none";
      heart.style.stroke = on ? "var(--accent)" : "currentColor";
    }

    // Yakınlık gözlemcisi — kaynak bağla / belleği boşalt
    var nearObs = new IntersectionObserver(function (entries) {
      var e = entries[0];
      if (e.isIntersecting) { near = true; attach(); }
      else { near = false; detach(); }
    }, { rootMargin: "800px 0px", threshold: 0 });
    nearObs.observe(wrap);

    function attach() {
      if (video.getAttribute("data-src-attached") === "1" || !near) return;
      video.setAttribute("data-src-attached", "1");
      var url = post.videoUrl;
      if (url.indexOf(".m3u8") !== -1) {
        if (video.canPlayType("application/vnd.apple.mpegurl")) {
          video.src = url;
        } else if (window.Hls && window.Hls.isSupported()) {
          hls = new window.Hls({
            maxBufferLength: 12, maxMaxBufferLength: 30, backBufferLength: 6,
            startLevel: -1, capLevelToPlayerSize: true, enableWorker: true,
          });
          hls.loadSource(url);
          hls.attachMedia(video);
        } else {
          video.src = url;
        }
      } else {
        video.src = url;
      }
    }

    function detach() {
      video.pause();
      paintPlayHint(true);
      if (hls) { hls.destroy(); hls = null; }
      video.removeAttribute("src");
      video.removeAttribute("data-src-attached");
      video.load();
    }

    // Görünürlük gözlemcisi — otomatik oynat + görüntülenme
    var visObs = new IntersectionObserver(function (entries) {
      var e = entries[0];
      var visible = e.isIntersecting && e.intersectionRatio >= 0.55;
      if (visible) {
        video.muted = true;
        paintMute(true);
        video.play().then(function () { paintPlayHint(false); }).catch(function () { paintPlayHint(true); });
        if (viewTimer) clearTimeout(viewTimer);
        viewTimer = setTimeout(function () {
          if (viewCounted) return;
          try {
            var arr = JSON.parse(sessionStorage.getItem("ss_viewed") || "[]");
            if (arr.indexOf(post.id) !== -1) { viewCounted = true; return; }
            arr.push(post.id);
            sessionStorage.setItem("ss_viewed", JSON.stringify(arr));
          } catch (err) {}
          viewCounted = true;
          var vc = $("[data-vviewcount]", card);
          if (vc) vc.textContent = formatCount(post.views += 1);
          api("engage.php?id=" + post.id, { method: "POST", body: JSON.stringify({ kind: "view" }) });
        }, 1800);
      } else {
        video.pause();
        paintPlayHint(true);
        if (viewTimer) clearTimeout(viewTimer);
      }
    }, { threshold: [0, 0.55, 1] });
    visObs.observe(wrap);

    function paintPlayHint(show) {
      if (playHint) playHint.style.display = show ? "flex" : "none";
    }
    function paintMute(muted) {
      var a = $("[data-icon-muted]", card), b = $("[data-icon-sound]", card);
      if (a) a.classList.toggle("hidden", !muted);
      if (b) b.classList.toggle("hidden", muted);
    }

    video.addEventListener("timeupdate", function () {
      if (video.duration > 0 && progress) {
        progress.style.width = (video.currentTime / video.duration) * 100 + "%";
      }
    });
    video.addEventListener("play", function () { paintPlayHint(false); });
    video.addEventListener("pause", function () { paintPlayHint(true); });

    // Dokunma: tek = oynat/durdur, çift = kalp + beğeni
    wrap.addEventListener("click", function () {
      if (clickTimer) {
        clearTimeout(clickTimer); clickTimer = null;
        onDouble();
      } else {
        clickTimer = setTimeout(function () {
          togglePlay();
          clickTimer = null;
        }, 260);
      }
    });

    function togglePlay() {
      if (video.paused) {
        video.play().catch(function () {});
        flash("play");
      } else {
        video.pause();
        flash("pause");
      }
    }

    function flash(kind) {
      if (!flashBox) return;
      flashBox.innerHTML = '<span class="animate-flash rounded-full bg-black/45 p-5 text-white">' +
        (kind === "play"
          ? '<svg width="36" height="36" viewBox="0 0 24 24" fill="currentColor"><path d="M6 4.5v15l13-7.5z"/></svg>'
          : '<svg width="36" height="36" viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/></svg>') +
        "</span>";
      flashBox.style.display = "flex";
      setTimeout(function () { flashBox.style.display = "none"; flashBox.innerHTML = ""; }, 650);
    }

    function onDouble() {
      if (burstBox) {
        burstBox.style.display = "flex";
        var heart = burstBox.firstElementChild;
        if (heart) {
          heart.classList.remove("animate-heart-pop");
          void heart.offsetWidth;
          heart.classList.add("animate-heart-pop");
        }
        setTimeout(function () { burstBox.style.display = "none"; }, 900);
      }
      if (!liked) doLike();
    }

    function doLike() {
      api("engage.php?id=" + post.id, { method: "POST", body: JSON.stringify({ kind: "like" }) })
        .then(function (r) {
          if (!r.ok) return;
          liked = !!r.data.liked;
          post.likes = r.data.likes;
          var lc = $("[data-vlikecount]", card);
          if (lc) lc.textContent = formatCount(post.likes);
          paintHeart(liked);
          var arr = getLiked();
          if (liked && arr.indexOf(post.id) === -1) arr.push(post.id);
          if (!liked) arr = arr.filter(function (x) { return x !== post.id; });
          setLiked(arr);
        });
    }

    var likeBtn = $("[data-vlike]", card);
    if (likeBtn) likeBtn.addEventListener("click", doLike);

    var muteBtn = $("[data-vmute]", card);
    if (muteBtn) muteBtn.addEventListener("click", function (e) {
      e.stopPropagation();
      video.muted = !video.muted;
      paintMute(video.muted);
    });

    var shareBtn = $("[data-vshare]", card);
    if (shareBtn) shareBtn.addEventListener("click", function () {
      var url = location.origin + BASE + "/index.php#v" + post.id;
      if (navigator.share) {
        navigator.share({ title: SS.owner.name, text: post.title || "Sohbet Sokağı'nda bu videoyu izle", url: url }).catch(function () {});
      } else if (navigator.clipboard) {
        navigator.clipboard.writeText(url).then(function () { toast("Bağlantı kopyalandı"); });
      }
    });

    var desc = $("[data-vdesc]", card);
    if (desc) desc.addEventListener("click", function () { desc.classList.toggle("line-clamp-2"); });

    // Yönetim menüsü
    if (manage) {
      var mBtn = $("[data-vmanage]", card);
      var menu = $("[data-vmenu]", card);
      if (mBtn && menu) {
        mBtn.addEventListener("click", function (e) {
          e.stopPropagation();
          menu.classList.toggle("hidden");
        });
        document.addEventListener("click", function () { menu.classList.add("hidden"); });
      }
      var pinBtn = $("[data-vpin]", card);
      if (pinBtn) pinBtn.addEventListener("click", function () {
        api("video.php?id=" + post.id, { method: "PATCH", body: JSON.stringify({ pinned: !post.pinned }) })
          .then(function (r) { toast(r.ok ? (post.pinned ? "Sabitleme kaldırıldı" : "Üste sabitlendi") : "İşlem başarısız"); if (r.ok) location.reload(); });
      });
      var editBtn = $("[data-vedit]", card);
      if (editBtn) editBtn.addEventListener("click", function () {
        $("#vm_id").value = post.id;
        $("#vm_url").value = post.videoUrl;
        $("#vm_poster").value = post.posterUrl || "";
        $("#vm_title").value = post.title || "";
        $("#vm_desc").value = post.description || "";
        setToggle($("#vm_pinned"), !!post.pinned);
        $("#videoModalTitle").textContent = "Videoyu Düzenle";
        $("#vm_submit").textContent = "Güncelle";
        openModal("videoModal");
      });
      var delBtn = $("[data-vdelete]", card);
      if (delBtn) delBtn.addEventListener("click", function () {
        if (!confirm("Bu video kalıcı olarak silinsin mi?")) return;
        api("video.php?id=" + post.id, { method: "DELETE" })
          .then(function (r) { if (r.ok) { toast("Video silindi"); card.remove(); } });
      });
    }
  }

  // Sayfadaki tüm kartları başlat
  function initAllCards(root) {
    $$("[data-vcard]", root).forEach(initVideoCard);
  }
  initAllCards(document);

  // Video paylaş / düzenle formu
  var vmSubmit = $("#vm_submit");
  if (vmSubmit) {
    vmSubmit.addEventListener("click", function () {
      var id = $("#vm_id").value;
      var url = $("#vm_url").value.trim();
      if (!url) return toast("Önce video ekleyin (URL veya yükleme)");
      var payload = {
        title: $("#vm_title").value,
        description: $("#vm_desc").value,
        videoUrl: url,
        posterUrl: $("#vm_poster").value,
        pinned: $("#vm_pinned").getAttribute("data-toggle") === "1",
      };
      var req = id
        ? api("video.php?id=" + id, { method: "PATCH", body: JSON.stringify(payload) })
        : api("videos.php", { method: "POST", body: JSON.stringify(payload) });
      vmSubmit.disabled = true;
      req.then(function (r) {
        vmSubmit.disabled = false;
        if (r.ok) {
          toast(id ? "Video güncellendi" : "Video yayınlandı — abonelere bildirim gönderiliyor");
          setTimeout(function () { location.reload(); }, 900);
        } else {
          toast(r.data.error || "İşlem başarısız");
        }
      });
    });
    // Yeni paylaşım için formu sıfırla
    $$("[data-fab-open='videoModal']").forEach(function (b) {
      b.addEventListener("click", function () {
        $("#vm_id").value = "";
        $("#vm_url").value = "";
        $("#vm_poster").value = "";
        $("#vm_title").value = "";
        $("#vm_desc").value = "";
        setToggle($("#vm_pinned"), false);
        $("#videoModalTitle").textContent = "Yeni Video Paylaş";
        $("#vm_submit").textContent = "Yayınla";
      });
    });
  }

  var smSubmit = $("#sm_submit");
  if (smSubmit) {
    smSubmit.addEventListener("click", function () {
      var url = $("#sm_url").value.trim();
      if (!url) return toast("Önce medya ekleyin");
      var isVideo = /\.(mp4|webm|mov)(\?|$)/i.test(url);
      smSubmit.disabled = true;
      api("stories.php", {
        method: "POST",
        body: JSON.stringify({ mediaUrl: url, mediaType: isVideo ? "video" : "image", hours: 24 }),
      }).then(function (r) {
        smSubmit.disabled = false;
        if (r.ok) {
          toast("Hikaye paylaşıldı — 24 saat sonra otomatik silinecek");
          setTimeout(function () { location.reload(); }, 900);
        } else toast("Paylaşılamadı");
      });
    });
  }

  var lmSubmit = $("#lm_submit");
  if (lmSubmit) {
    lmSubmit.addEventListener("click", function () {
      if (!$("#lm_title").value.trim()) return toast("İlan başlığı gerekli");
      var id = $("#lm_id").value;
      var payload = {
        title: $("#lm_title").value,
        type: $("#lm_type").value,
        status: $("#lm_status").value,
        price: Number(($("#lm_price").value || "").replace(/[^\d]/g, "")) || 0,
        rooms: $("#lm_rooms").value,
        area: Number($("#lm_area").value) || 0,
        floor: $("#lm_floor").value,
        heating: $("#lm_heating").value,
        district: $("#lm_district").value,
        phone: $("#lm_phone").value,
        description: $("#lm_desc").value,
        images: lmImages.slice(0, 10),
        pinned: $("#lm_pinned").getAttribute("data-toggle") === "1",
      };
      var req = id
        ? api("listing.php?id=" + id, { method: "PATCH", body: JSON.stringify(payload) })
        : api("listings.php", { method: "POST", body: JSON.stringify(payload) });
      lmSubmit.disabled = true;
      req.then(function (r) {
        lmSubmit.disabled = false;
        if (r.ok) {
          toast(id ? "İlan güncellendi" : "İlan yayınlandı");
          setTimeout(function () { location.reload(); }, 900);
        } else toast(r.data.error || "İşlem başarısız");
      });
    });
    $$("[data-fab-open='listingModal']").forEach(function (b) {
      b.addEventListener("click", function () {
        $("#lm_id").value = "";
        ["lm_title", "lm_price", "lm_rooms", "lm_area", "lm_floor", "lm_phone", "lm_desc"].forEach(function (i) {
          var el = document.getElementById(i); if (el) el.value = "";
        });
        lmImages = []; renderLmImages();
        setToggle($("#lm_pinned"), false);
        $("#listingModalTitle").textContent = "Yeni Emlak İlanı";
        $("#lm_submit").textContent = "İlanı Yayınla";
      });
    });
  }

  /* --------------------- Sonsuz Kaydırma --------------------- */

  var sentinel = $("#feedSentinel");
  if (sentinel) {
    var feed = $("#videoFeed");
    var offset = Number(sentinel.getAttribute("data-offset")) || 4;
    var hasMore = true, loading = false;
    var template = $("#videoCardTemplate");

    var feedObs = new IntersectionObserver(function (entries) {
      if (entries[0].isIntersecting && hasMore && !loading) {
        loading = true;
        fetch(BASE + "/api/videos.php?offset=" + offset + "&limit=4")
          .then(function (r) { return r.json(); })
          .then(function (j) {
            hasMore = !!j.hasMore;
            if (j.videos && j.videos.length) {
              var existing = {};
              $$("[data-vcard]", feed).forEach(function (c) {
                try { existing[JSON.parse(c.getAttribute("data-post")).id] = 1; } catch (e) {}
              });
              j.videos.forEach(function (p) {
                if (existing[p.id]) return;
                // Akış içi banner enjeksiyonu (her 3 gönderide bir)
                var banners = window.SS_INLINE_BANNERS || [];
                var cc = $$("[data-vcard]", feed).length;
                if (banners.length && cc > 0 && cc % 3 === 0) {
                  var b = banners[((cc / 3) - 1) % banners.length];
                  var bt = document.createElement("div");
                  bt.innerHTML = buildBanner(b);
                  if (bt.firstElementChild) feed.appendChild(bt.firstElementChild);
                }
                var html = buildCard(p);
                var tmp = document.createElement("div");
                tmp.innerHTML = html;
                var node = tmp.firstElementChild;
                feed.appendChild(node);
                initVideoCard(node);
              });
              offset += j.videos.length;
            }
            if (!hasMore) {
              var end = $("#feedEnd");
              if (end) end.style.display = "";
            }
            loading = false;
          })
          .catch(function () { loading = false; hasMore = false; });
      }
    }, { rootMargin: "900px 0px" });
    feedObs.observe(sentinel);
  }

  function buildBanner(b) {
    var external = /^https?:\/\//.test(b.linkUrl || "");
    return '<a href="' + esc(b.linkUrl || "#") + '"' + (external ? ' target="_blank" rel="noopener"' : "") +
      ' class="group animate-fade-up relative block h-44 overflow-hidden border shadow-sm" style="border-color:var(--line);border-radius:var(--radius)">' +
      '<img src="' + esc(b.imageUrl) + '" loading="lazy" class="h-full w-full object-cover transition duration-700 group-hover:scale-105" alt="' + esc(b.title || "") + '">' +
      '<div class="absolute inset-0" style="background:linear-gradient(to top, rgba(0,0,0,.7), rgba(0,0,0,.15), transparent)"></div>' +
      '<span class="absolute left-3 top-3 flex items-center gap-1 rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-extrabold text-neutral-800 shadow"><svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/></svg> ÖNE ÇIKAN</span>' +
      '<p class="absolute bottom-3 left-4 right-4 text-[15px] font-extrabold leading-snug text-white drop-shadow">' + esc(b.title || "") + "</p></a>";
  }

  function buildCard(p) {
    // Sunucu tarafı renderVideoCard ile aynı görünüm (yönetim menüsü dahil)
    var o = SS.owner;
    var manage = SS.canManage;
    return '' +
    '<article id="v' + p.id + '" class="animate-fade-up overflow-hidden border shadow-[0_1px_2px_rgba(30,20,10,0.04)]" style="border-color:var(--line);background:var(--card);border-radius:var(--radius)" data-vcard data-post=\'' + esc(JSON.stringify(p)) + '\' data-manage="' + (manage ? 1 : 0) + '">' +
      '<header class="flex items-center gap-3 px-4 py-3">' +
        '<a href="' + BASE + '/profil.php" class="flex min-w-0 items-center gap-2.5">' +
          '<span class="ring-gradient rounded-full p-[2px]"><img src="' + esc(o.avatar) + '" class="h-9 w-9 rounded-full border-2 object-cover" style="border-color:var(--card)"></span>' +
          '<span class="min-w-0"><span class="flex items-center gap-1">' +
            '<span class="truncate text-[13.5px] font-extrabold tracking-tight">' + esc(o.username) + "</span>" +
            (o.verified ? '<svg width="15" height="15" viewBox="0 0 24 24" fill="#0095F6"><path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><path d="m9 12 2 2 4-4" stroke="var(--card)" stroke-width="2" fill="none"/></svg>' : "") +
            (p.pinned ? '<span class="ml-1 rounded-full px-1.5 py-0.5 text-[9.5px] font-extrabold" style="background:color-mix(in srgb, var(--accent) 10%, transparent);color:var(--accent)">SABİTLENDİ</span>' : "") +
          "</span>" +
          '<span class="block truncate text-[11px]" style="color:var(--muted)">' + timeAgo(p.createdAt) + " · Elbistan</span></span>" +
        "</a>" +
        '<div class="ml-auto flex shrink-0 items-center gap-1.5">' +
          '<a href="' + BASE + '/profil.php" class="rounded-full border px-3 py-1.5 text-[11px] font-extrabold" style="border-color:var(--line);background:var(--bg)">Profili Gör</a>' +
          (manage ? '<div class="relative"><button data-vmanage class="rounded-full p-1.5" style="color:var(--muted)"><svg width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="12" cy="19" r="1.6"/></svg></button>' +
            '<div data-vmenu class="animate-scale-in absolute right-0 top-9 z-30 hidden w-48 overflow-hidden rounded-2xl border py-1.5 shadow-xl" style="border-color:var(--line);background:var(--card)">' +
            '<button data-vpin class="flex w-full items-center gap-2.5 px-4 py-2.5 text-left text-[13px] font-semibold hover:bg-[var(--bg)]">' + (p.pinned ? "Sabitlemeyi Kaldır" : "Üste Sabitle") + "</button>" +
            '<button data-vedit class="flex w-full items-center gap-2.5 px-4 py-2.5 text-left text-[13px] font-semibold hover:bg-[var(--bg)]">Düzenle</button>' +
            '<button data-vdelete class="flex w-full items-center gap-2.5 px-4 py-2.5 text-left text-[13px] font-semibold text-rose-500">Sil</button></div></div>' : "") +
        "</div>" +
      "</header>" +
      '<div data-vwrap class="relative aspect-[4/5] max-h-[74vh] w-full cursor-pointer select-none overflow-hidden bg-black">' +
        "<video data-vplayer class=\"video-ease h-full w-full object-cover\" " + (p.posterUrl ? 'poster="' + esc(p.posterUrl) + '"' : "") + ' playsinline loop muted preload="metadata"></video>' +
        '<div data-vburst class="pointer-events-none absolute inset-0 hidden items-center justify-center"><svg width="110" height="110" viewBox="0 0 24 24" fill="white" class="animate-heart-pop"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg></div>' +
        '<div data-vflash class="pointer-events-none absolute inset-0 hidden items-center justify-center"></div>' +
        '<div class="absolute inset-x-0 bottom-0 h-[3px] bg-white/20"><div data-vprogress class="h-full" style="width:0%;background:var(--accent)"></div></div>' +
        '<button data-vmute class="absolute bottom-4 right-3 rounded-full bg-black/50 p-2.5 text-white backdrop-blur"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" data-icon-muted><path d="M11 5 6 9H2v6h4l5 4V5Z"/><line x1="23" x2="17" y1="9" y2="15"/><line x1="17" x2="23" y1="9" y2="15"/></svg><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" data-icon-sound class="hidden"><path d="M11 5 6 9H2v6h4l5 4V5Z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg></button>' +
        '<div data-vplayhint class="pointer-events-none absolute inset-0 flex items-center justify-center"><span class="rounded-full bg-black/35 p-4 text-white/95 backdrop-blur-sm"><svg width="30" height="30" viewBox="0 0 24 24" fill="currentColor"><path d="M6 4.5v15l13-7.5z"/></svg></span></div>' +
      "</div>" +
      '<div class="flex items-center gap-1 px-3 pt-2.5">' +
        '<button data-vlike class="group flex items-center gap-1.5 rounded-full px-2 py-1.5 transition active:scale-90"><svg data-vheart width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg><span data-vlikecount class="text-[13px] font-extrabold">' + formatCount(p.likes) + "</span></button>" +
        '<span class="flex items-center gap-1.5 px-2 py-1.5" style="color:var(--muted)"><svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg><span data-vviewcount class="text-[13px] font-bold">' + formatCount(p.views) + "</span></span>" +
        '<button data-vshare class="rounded-full px-2 py-1.5"><svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m22 2-7 20-4-9-9-4z"/><path d="M22 2 11 13"/></svg></button>' +
        '<span class="ml-auto pr-1 text-[11px] font-semibold" style="color:var(--muted)">' + esc(new Date(p.createdAt).toLocaleString("tr-TR", { day: "numeric", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })) + "</span>" +
      "</div>" +
      (p.title || p.description
        ? '<div class="px-4 pb-1.5 pt-1">' + (p.title ? '<h2 class="text-[14px] font-extrabold tracking-tight">' + esc(p.title) + "</h2>" : "") +
          (p.description ? '<p data-vdesc class="mt-0.5 line-clamp-2 whitespace-pre-line text-[13px] leading-relaxed" style="color:color-mix(in srgb, var(--ink) 80%, transparent)">' + esc(p.description) + "</p>" : "") + "</div>"
        : "") +
      '<div class="flex items-center gap-1.5 px-4 pb-3.5 pt-1 text-[11.5px] font-semibold" style="color:var(--muted)"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/><line x1="2" x2="22" y1="2" y2="22"/></svg>Yorumlar bu platformda kapalıdır</div>' +
    "</article>";
  }

  /* --------------------- Hikaye Görüntüleyici --------------------- */

  (function initStories() {
    var stories = window.SS_STORIES;
    if (!stories || !stories.length) return;
    var idx = -1, timer = null;

    function open(i) {
      idx = i;
      render();
    }
    function close() {
      if (timer) clearTimeout(timer);
      var ov = $("#storyOverlay");
      if (ov) ov.remove();
      idx = -1;
    }
    function nav(d) {
      var n = idx + d;
      if (n < 0) return;
      if (n >= stories.length) return close();
      idx = n;
      render();
    }

    function render() {
      if (timer) clearTimeout(timer);
      var old = $("#storyOverlay");
      if (old) old.remove();
      var item = stories[idx];
      var ov = document.createElement("div");
      ov.id = "storyOverlay";
      ov.className = "fixed inset-0 z-[95] flex items-center justify-center bg-black/95 backdrop-blur-sm";
      var segs = stories.map(function (s, i) {
        var inner = "";
        if (i < idx) inner = '<div class="h-full w-full bg-white"></div>';
        else if (i === idx) inner = item.mediaType === "video"
          ? '<div id="storyVProgress" class="h-full bg-white" style="width:0%"></div>'
          : '<div class="story-progress-run h-full bg-white"></div>';
        return '<div class="h-[3px] flex-1 overflow-hidden rounded-full bg-white/30">' + inner + "</div>";
      }).join("");
      ov.innerHTML =
        '<div class="animate-scale-in relative h-[100dvh] w-full overflow-hidden bg-black sm:h-[92dvh] sm:max-w-[410px] sm:rounded-2xl">' +
          (item.mediaType === "video"
            ? '<video id="storyVideo" src="' + esc(item.mediaUrl) + '" class="h-full w-full object-cover" autoplay playsinline></video>'
            : '<img src="' + esc(item.mediaUrl) + '" class="h-full w-full object-cover" alt="Hikaye">') +
          '<div class="pointer-events-none absolute inset-x-0 top-0 h-28" style="background:linear-gradient(to bottom, rgba(0,0,0,.7), transparent)"></div>' +
          '<div class="absolute inset-x-3 top-3 flex gap-1">' + segs + "</div>" +
          '<div class="absolute inset-x-0 top-7 flex items-center gap-2.5 px-4">' +
            '<img src="' + esc(SS.owner.avatar) + '" class="h-8 w-8 rounded-full border border-white/40 object-cover">' +
            '<span class="flex items-center gap-1 text-[13px] font-extrabold text-white drop-shadow">' + esc(SS.owner.username) +
              (SS.owner.verified ? '<svg width="14" height="14" viewBox="0 0 24 24" fill="#0095F6"><path d="M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z"/><path d="m9 12 2 2 4-4" stroke="#000" stroke-width="2" fill="none"/></svg>' : "") +
            "</span>" +
            '<span class="text-[11.5px] font-semibold text-white/70">' + timeAgo(item.createdAt) + "</span>" +
            '<div class="ml-auto flex items-center gap-1">' +
              (window.SS_STORY_MANAGE ? '<button id="storyDelete" class="rounded-full p-2 text-white/85 hover:bg-white/15"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>' : "") +
              '<button id="storyClose" class="rounded-full p-2 text-white hover:bg-white/15"><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg></button>' +
            "</div>" +
          "</div>" +
          '<button id="storyPrev" class="absolute inset-y-0 left-0 w-1/3" aria-label="Önceki"></button>' +
          '<button id="storyNext" class="absolute inset-y-0 right-0 w-2/3" aria-label="Sonraki"></button>' +
        "</div>";
      document.body.appendChild(ov);
      $("#storyClose", ov).addEventListener("click", close);
      $("#storyPrev", ov).addEventListener("click", function () { nav(-1); });
      $("#storyNext", ov).addEventListener("click", function () { nav(1); });
      if (window.SS_STORY_MANAGE) {
        var del = $("#storyDelete", ov);
        if (del) del.addEventListener("click", function () {
          api("stories.php?id=" + item.id, { method: "DELETE" }).then(function (r) {
            if (r.ok) {
              toast("Hikaye silindi");
              stories.splice(stories.indexOf(item), 1);
              if (!stories.length) { close(); location.reload(); return; }
              if (idx >= stories.length) idx = stories.length - 1;
              render();
            }
          });
        });
      }
      if (item.mediaType === "video") {
        var v = $("#storyVideo", ov);
        if (v) {
          v.addEventListener("ended", function () { nav(1); });
          v.addEventListener("timeupdate", function () {
            if (v.duration > 0) {
              var pr = $("#storyVProgress", ov);
              if (pr) pr.style.width = (v.currentTime / v.duration) * 100 + "%";
            }
          });
        }
      } else {
        timer = setTimeout(function () { nav(1); }, 5000);
      }
    }

    $$("[data-story-open]").forEach(function (b) {
      b.addEventListener("click", function () {
        open(Number(b.getAttribute("data-story-open")) || 0);
      });
    });
    document.addEventListener("keydown", function (e) {
      if (idx === -1) return;
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") nav(1);
      if (e.key === "ArrowLeft") nav(-1);
    });
  })();

  /* --------------------- Emlak Sayfası --------------------- */

  (function initEmlak() {
    var app = $("#emlakApp");
    if (!app) return;
    var listings = window.SS_LISTINGS || [];
    var ownerPhone = window.SS_OWNER_PHONE || "";

    // Filtre + arama (sunucu tarafı kartları gizle/göster)
    var filter = "all", query = "";
    function applyFilter() {
      var q = query.trim().toLocaleLowerCase("tr");
      $$("[data-listing-card]", app).forEach(function (card) {
        var type = card.getAttribute("data-type");
        var status = card.getAttribute("data-status");
        var hay = (card.getAttribute("data-hay") || "").toLocaleLowerCase("tr");
        var show = true;
        if (filter === "satilik" || filter === "kiralik") show = type === filter;
        else if (filter === "satildi" || filter === "kiralandi") show = status === filter;
        if (show && q) show = hay.indexOf(q) !== -1;
        card.style.display = show ? "" : "none";
      });
      var anyVisible = $$("[data-listing-card]", app).some(function (c) { return c.style.display !== "none"; });
      var empty = $("#emlakEmpty");
      if (empty) empty.style.display = anyVisible ? "none" : "";
    }
    $$("[data-emlak-filter]").forEach(function (chip) {
      chip.addEventListener("click", function () {
        filter = chip.getAttribute("data-emlak-filter");
        $$("[data-emlak-filter]").forEach(function (c) {
          var on = c === chip;
          c.style.background = on ? "var(--ink)" : "var(--card)";
          c.style.color = on ? "var(--bg)" : "var(--muted)";
          c.style.borderColor = on ? "var(--ink)" : "var(--line)";
        });
        applyFilter();
      });
    });
    var searchInput = $("#emlakSearch");
    if (searchInput) searchInput.addEventListener("input", function () {
      query = searchInput.value;
      applyFilter();
    });

    // Karuseller
    $$("[data-carousel]").forEach(function (car) {
      var images = (car.getAttribute("data-carousel") || "").split("|").filter(Boolean);
      if (images.length < 2) return;
      var img = $("img", car);
      var dots = $$("[data-dot]", car);
      var i = 0;
      function paint() {
        if (img) img.src = images[i];
        dots.forEach(function (d, di) {
          d.className = "h-1.5 rounded-full transition-all " + (di === i ? "w-4 bg-white" : "w-1.5 bg-white/50");
        });
      }
      $$("[data-car-prev]", car).forEach(function (b) {
        b.addEventListener("click", function (e) { e.stopPropagation(); i = (i - 1 + images.length) % images.length; paint(); });
      });
      $$("[data-car-next]", car).forEach(function (b) {
        b.addEventListener("click", function (e) { e.stopPropagation(); i = (i + 1) % images.length; paint(); });
      });
    });

    // Detay modalı
    function formatPrice(n, type) {
      var s = "₺" + Number(n || 0).toLocaleString("tr-TR");
      return type === "kiralik" ? s + "/ay" : s;
    }
    var STATUS_LABEL = { aktif: "Yayında", satildi: "Satıldı", kiralandi: "Kiralandı" };
    var STATUS_STYLE = { satildi: "bg-rose-600 text-white", kiralandi: "bg-amber-500 text-white" };

    function openDetail(l) {
      var phone = (l.phone || ownerPhone || "").replace(/[^\d]/g, "");
      var old = $("#emlakDetail");
      if (old) old.remove();
      var ov = document.createElement("div");
      ov.id = "emlakDetail";
      ov.className = "fixed inset-0 z-[90] flex items-end justify-center sm:items-center sm:p-4";
      var specs = [
        ["Oda", l.rooms || "—"], ["Brüt", l.area ? l.area + " m²" : "—"], ["Kat", l.floor || "—"],
        ["Isıtma", l.heating || "—"], ["Durum", STATUS_LABEL[l.status] || "—"],
        ["Görüntülenme", formatCount(l.views)], ["İlan No", "#" + l.id],
        ["Tarih", new Date(l.createdAt).toLocaleDateString("tr-TR", { day: "numeric", month: "long", year: "numeric" })],
      ];
      ov.innerHTML =
        '<div class="animate-fade-in absolute inset-0 bg-black/50 backdrop-blur-sm" data-detail-close></div>' +
        '<div class="animate-sheet-up no-scrollbar relative max-h-[94dvh] w-full overflow-y-auto rounded-t-3xl border shadow-2xl sm:max-w-xl sm:rounded-3xl" style="border-color:var(--line);background:var(--card)">' +
          '<div class="relative h-64 sm:h-72 overflow-hidden bg-neutral-200" data-carousel="' + esc((l.images || []).join("|")) + '">' +
            (l.images && l.images.length ? '<img src="' + esc(l.images[0]) + '" class="h-full w-full object-cover">' : "") +
            (l.images && l.images.length > 1
              ? '<button data-car-prev class="absolute left-2 top-1/2 -translate-y-1/2 rounded-full bg-black/45 p-1.5 text-white"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m15 18-6-6 6-6"/></svg></button>' +
                '<button data-car-next class="absolute right-2 top-1/2 -translate-y-1/2 rounded-full bg-black/45 p-1.5 text-white"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m9 18 6-6-6-6"/></svg></button>' +
                '<div class="absolute bottom-2 left-1/2 flex -translate-x-1/2 gap-1">' + l.images.map(function (_, i) { return '<span data-dot class="h-1.5 rounded-full ' + (i === 0 ? "w-4 bg-white" : "w-1.5 bg-white/50") + '"></span>'; }).join("") + "</div>"
              : "") +
            '<div class="pointer-events-none absolute left-3 top-3 flex gap-1.5">' +
              '<span class="rounded-full px-2.5 py-1 text-[10px] font-extrabold shadow ' + (l.type === "kiralik" ? "bg-sky-600 text-white" : "bg-white/95 text-neutral-900") + '">' + (l.type === "kiralik" ? "KİRALIK" : "SATILIK") + "</span>" +
              (STATUS_STYLE[l.status] ? '<span class="rounded-full px-2.5 py-1 text-[10px] font-extrabold shadow ' + STATUS_STYLE[l.status] + '">' + STATUS_LABEL[l.status].toUpperCase() + "</span>" : "") +
            "</div>" +
            '<button data-detail-close class="absolute right-3 top-3 rounded-full bg-black/50 p-2 text-white backdrop-blur hover:bg-black/70"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg></button>' +
          "</div>" +
          '<div class="p-5">' +
            '<p class="text-2xl font-extrabold tracking-tight" style="color:var(--accent)">' + formatPrice(l.price, l.type) + "</p>" +
            '<h3 class="mt-1 text-[16px] font-extrabold tracking-tight">' + esc(l.title) + "</h3>" +
            '<p class="mt-0.5 flex items-center gap-1 text-[12px] font-bold" style="color:var(--muted)"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/></svg>' + esc(l.district ? l.district + " · " : "") + "Elbistan / Kahramanmaraş</p>" +
            '<div class="mt-4 grid grid-cols-3 gap-2 sm:grid-cols-4">' +
              specs.map(function (s) {
                return '<div class="rounded-xl border p-2.5" style="border-color:var(--line);background:var(--bg)"><p class="text-[9.5px] font-extrabold uppercase tracking-wide" style="color:var(--muted)">' + s[0] + '</p><p class="truncate text-[11.5px] font-extrabold">' + esc(s[1]) + "</p></div>";
              }).join("") +
            "</div>" +
            (l.description ? '<p class="mt-4 whitespace-pre-line text-[13.5px] leading-relaxed" style="color:color-mix(in srgb, var(--ink) 85%, transparent)">' + esc(l.description) + "</p>" : "") +
            '<div class="mt-5 flex gap-2">' +
              '<a href="https://wa.me/' + phone + "?text=" + encodeURIComponent('Merhaba, "' + l.title + '" (İlan №' + l.id + ") hakkında bilgi almak istiyorum.") + '" target="_blank" rel="noopener" class="flex flex-1 items-center justify-center gap-2 rounded-xl bg-[#25D366] px-4 py-3 text-[13.5px] font-extrabold text-white shadow transition hover:opacity-90">WhatsApp\'tan Sor</a>' +
              '<a href="tel:+' + phone + '" class="flex items-center justify-center gap-2 rounded-xl border px-4 py-3 text-[13.5px] font-extrabold" style="border-color:var(--line);background:var(--bg)">Ara</a>' +
            "</div>" +
            (SS.canManage
              ? '<div class="mt-5 rounded-2xl border border-dashed p-4" style="border-color:color-mix(in srgb, var(--accent) 50%, transparent);background:color-mix(in srgb, var(--accent) 5%, transparent)">' +
                '<p class="text-[11px] font-extrabold uppercase tracking-wide" style="color:var(--accent)">Yönetici İşlemleri</p>' +
                '<div class="mt-2.5 flex flex-wrap gap-2">' +
                  ["aktif", "satildi", "kiralandi"].map(function (s) {
                    return '<button data-lstatus="' + s + '" class="rounded-full px-3.5 py-2 text-[11.5px] font-extrabold ' + (l.status === s ? "" : "border") + '" style="' + (l.status === s ? "background:var(--ink);color:var(--bg)" : "border-color:var(--line);background:var(--card);color:var(--muted)") + '">' + STATUS_LABEL[s] + "</button>";
                  }).join("") +
                  '<button data-lpin class="rounded-full border px-3.5 py-2 text-[11.5px] font-extrabold" style="border-color:var(--line);background:var(--card);color:var(--muted)">' + (l.pinned ? "Sabitlemeyi Kaldır" : "Üste Sabitle") + "</button>" +
                  '<button data-ledit class="rounded-full border px-3.5 py-2 text-[11.5px] font-extrabold" style="border-color:var(--line);background:var(--card);color:var(--muted)">Düzenle</button>' +
                  '<button data-ldel class="rounded-full border border-rose-500/30 bg-rose-500/10 px-3.5 py-2 text-[11.5px] font-extrabold text-rose-500">İlanı Sil</button>' +
                "</div></div>"
              : "") +
          "</div>" +
        "</div>";
      document.body.appendChild(ov);

      // Görüntülenme sayacı (oturum başına bir kez)
      try {
        var arr = JSON.parse(sessionStorage.getItem("ss_lviewed") || "[]");
        if (arr.indexOf(l.id) === -1) {
          arr.push(l.id);
          sessionStorage.setItem("ss_lviewed", JSON.stringify(arr));
          api("listing.php?id=" + l.id, { method: "PATCH", body: JSON.stringify({ action: "view" }) });
        }
      } catch (e) {}

      $$("[data-detail-close]", ov).forEach(function (b) {
        b.addEventListener("click", function () { ov.remove(); });
      });
      // Modal içi karusel
      var car = $("[data-carousel]", ov);
      if (car) {
        var images = (car.getAttribute("data-carousel") || "").split("|").filter(Boolean);
        var img = $("img", car);
        var i = 0;
        $$("[data-car-prev]", car).forEach(function (b) {
          b.addEventListener("click", function (e) { e.stopPropagation(); i = (i - 1 + images.length) % images.length; img.src = images[i]; });
        });
        $$("[data-car-next]", car).forEach(function (b) {
          b.addEventListener("click", function (e) { e.stopPropagation(); i = (i + 1) % images.length; img.src = images[i]; });
        });
      }
      // Yönetici işlemleri
      $$("[data-lstatus]", ov).forEach(function (b) {
        b.addEventListener("click", function () {
          api("listing.php?id=" + l.id, { method: "PATCH", body: JSON.stringify({ status: b.getAttribute("data-lstatus") }) })
            .then(function (r) { toast(r.ok ? "İlan durumu güncellendi" : "İşlem başarısız"); if (r.ok) location.reload(); });
        });
      });
      var pb = $("[data-lpin]", ov);
      if (pb) pb.addEventListener("click", function () {
        api("listing.php?id=" + l.id, { method: "PATCH", body: JSON.stringify({ pinned: !l.pinned }) })
          .then(function (r) { if (r.ok) location.reload(); });
      });
      var eb = $("[data-ledit]", ov);
      if (eb) eb.addEventListener("click", function () {
        ov.remove();
        $("#lm_id").value = l.id;
        $("#lm_title").value = l.title;
        $("#lm_type").value = l.type;
        $("#lm_status").value = l.status;
        $("#lm_price").value = l.price;
        $("#lm_rooms").value = l.rooms;
        $("#lm_area").value = l.area || "";
        $("#lm_floor").value = l.floor;
        $("#lm_heating").value = l.heating;
        $("#lm_district").value = l.district;
        $("#lm_phone").value = l.phone || "";
        $("#lm_desc").value = l.description;
        lmImages = (l.images || []).slice(0, 10);
        renderLmImages();
        setToggle($("#lm_pinned"), !!l.pinned);
        $("#listingModalTitle").textContent = "İlanı Düzenle";
        $("#lm_submit").textContent = "Güncelle";
        openModal("listingModal");
      });
      var db = $("[data-ldel]", ov);
      if (db) db.addEventListener("click", function () {
        if (!confirm("Bu ilan kalıcı olarak silinsin mi?")) return;
        api("listing.php?id=" + l.id, { method: "DELETE" })
          .then(function (r) { if (r.ok) { toast("İlan silindi"); ov.remove(); location.reload(); } });
      });
    }

    $$("[data-listing-card]", app).forEach(function (card) {
      card.addEventListener("click", function () {
        var id = Number(card.getAttribute("data-listing-card"));
        var l = listings.find(function (x) { return x.id === id; });
        if (l) openDetail(l);
      });
    });
  })();

  /* --------------------- Profil sayfası gönderi modalı --------------------- */

  (function initProfile() {
    var grid = $("#profileGrid");
    if (!grid) return;
    var videos = window.SS_VIDEOS || [];
    $$("[data-grid-post]", grid).forEach(function (cell) {
      cell.addEventListener("click", function () {
        var id = Number(cell.getAttribute("data-grid-post"));
        var p = videos.find(function (x) { return x.id === id; });
        if (!p) return;
        var old = $("#profilePostModal");
        if (old) old.remove();
        var ov = document.createElement("div");
        ov.id = "profilePostModal";
        ov.className = "fixed inset-0 z-[90] flex items-end justify-center sm:items-center sm:p-4";
        ov.innerHTML =
          '<div class="animate-fade-in absolute inset-0 bg-black/50 backdrop-blur-sm" data-pp-close></div>' +
          '<div class="animate-sheet-up no-scrollbar relative max-h-[92dvh] w-full overflow-y-auto rounded-t-3xl border shadow-2xl sm:max-w-md sm:rounded-3xl" style="border-color:var(--line);background:var(--card)">' +
            '<div class="sticky top-0 z-10 flex items-center justify-between border-b px-5 py-4" style="border-color:var(--line)">' +
              '<h3 class="text-[15px] font-extrabold tracking-tight">' + esc(p.title || "Gönderi") + "</h3>" +
              '<button data-pp-close class="rounded-full p-1.5" style="color:var(--muted)">✕</button>' +
            "</div>" +
            '<div class="p-5" id="ppBody"></div>' +
          "</div>";
        document.body.appendChild(ov);
        var body = $("#ppBody", ov);
        body.innerHTML = buildCard(p);
        initVideoCard(body.firstElementChild);
        $$("[data-pp-close]", ov).forEach(function (b) {
          b.addEventListener("click", function () { ov.remove(); });
        });
      });
    });
  })();
})();
