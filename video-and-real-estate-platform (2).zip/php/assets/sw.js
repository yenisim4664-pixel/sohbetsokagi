/* Sohbet Sokağı — Web Push Service Worker (PHP sürümü) */

self.addEventListener("install", function () {
  self.skipWaiting();
});

self.addEventListener("activate", function (event) {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("push", function (event) {
  var data = {
    title: "Sohbet Sokağı",
    body: "Yeni bir içerik sizi bekliyor!",
    url: "./index.php",
    icon: "assets/img/icon-512.png",
  };
  try {
    if (event.data) {
      var parsed = event.data.json();
      data = Object.assign(data, parsed);
    }
  } catch (e) {
    if (event.data) data.body = event.data.text();
  }
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: data.icon || "assets/img/icon-512.png",
      badge: "assets/img/icon-512.png",
      dir: "ltr",
      lang: "tr",
      tag: "sohbet-sokagi-" + Date.now(),
      renotify: false,
      data: { url: data.url || "./index.php" },
    })
  );
});

self.addEventListener("notificationclick", function (event) {
  event.notification.close();
  var url = (event.notification.data && event.notification.data.url) || "./index.php";
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then(function (clients) {
      for (var i = 0; i < clients.length; i++) {
        var client = clients[i];
        if ("focus" in client) {
          client.navigate(url);
          return client.focus();
        }
      }
      return self.clients.openWindow(url);
    })
  );
});
