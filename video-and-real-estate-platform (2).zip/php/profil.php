<?php
/**
 * SOHBET SOKAĞI — Sahip profili
 */
require_once __DIR__ . '/includes/render.php';

$S = siteData();
$rows = dbAll('SELECT * FROM videos ORDER BY pinned DESC, created_at DESC LIMIT 60');
$jsonVideos = array_map('videoToJson', $rows);
$agg = dbOne('SELECT COUNT(*) AS c, COALESCE(SUM(views),0) AS sv, COALESCE(SUM(likes),0) AS sl FROM videos') ?: ['c' => 0, 'sv' => 0, 'sl' => 0];

$PAGE_TITLE = $S['owner']['name'] . ' (@' . $S['owner']['username'] . ') | ' . $S['siteName'];
$PAGE_DESCRIPTION = mb_substr($S['owner']['bio'], 0, 160);
$PAGE_ACTIVE = 'profil';
$PAGE_OG_IMAGE = $S['owner']['avatar'];
$PAGE_JSONLD = [[
    '@context' => 'https://schema.org',
    '@type' => 'ProfilePage',
    'mainEntity' => [
        '@type' => 'Person',
        'name' => $S['owner']['name'],
        'alternateName' => $S['owner']['username'],
        'image' => $S['owner']['avatar'],
        'description' => $S['owner']['bio'],
        'sameAs' => array_filter([$S['owner']['instagram']]),
        'address' => [
            '@type' => 'PostalAddress',
            'addressLocality' => 'Elbistan',
            'addressCountry' => 'TR',
        ],
    ],
]];

require __DIR__ . '/includes/header.php';
?>
<div class="mx-auto w-full max-w-[520px]">
  <div class="flex flex-col px-4 pt-6">
    <div class="flex items-center gap-6">
      <span class="ring-gradient shrink-0 rounded-full p-[3px]">
        <img src="<?= e($owner['avatar']) ?>" alt="<?= e($owner['name']) ?>" class="h-[84px] w-[84px] rounded-full border-4 object-cover" style="border-color:var(--bg)">
      </span>
      <div class="grid flex-1 grid-cols-3 gap-1 text-center">
        <div><p class="text-[17px] font-extrabold tracking-tight"><?= e(formatCount($agg['c'])) ?></p><p class="text-[10.5px] font-bold" style="color:var(--muted)">Gönderi</p></div>
        <div><p class="text-[17px] font-extrabold tracking-tight"><?= e(formatCount($agg['sv'])) ?></p><p class="text-[10.5px] font-bold" style="color:var(--muted)">İzlenme</p></div>
        <div><p class="text-[17px] font-extrabold tracking-tight"><?= e(formatCount($agg['sl'])) ?></p><p class="text-[10.5px] font-bold" style="color:var(--muted)">Beğeni</p></div>
      </div>
    </div>

    <div class="mt-4">
      <h1 class="flex items-center gap-1.5 text-[19px] font-extrabold tracking-tight">
        <?= e($owner['name']) ?>
        <?php if ($owner['verified']) echo verifiedBadge(19); ?>
      </h1>
      <p class="text-[12.5px] font-bold" style="color:var(--muted)">@<?= e($owner['username']) ?> · Elbistan</p>
      <?php if ($owner['bio']): ?>
      <p class="mt-2 whitespace-pre-line text-[13.5px] leading-relaxed" style="color:color-mix(in srgb, var(--ink) 85%, transparent)"><?= e($owner['bio']) ?></p>
      <?php endif; ?>
    </div>

    <div class="mt-4 flex flex-col gap-2">
      <div class="grid grid-cols-2 gap-2">
        <a href="<?= e(waLink($owner['whatsapp'], 'Merhaba, Sohbet Sokağı profilinizden ulaşıyorum.')) ?>" target="_blank" rel="noopener" class="flex items-center justify-center gap-2 rounded-xl bg-[#25D366] px-3 py-3 text-[13px] font-extrabold text-white shadow-sm transition hover:opacity-90 active:scale-[.98]">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/></svg>
          WhatsApp
        </a>
        <a href="<?= e($owner['instagram']) ?>" target="_blank" rel="noopener" class="flex items-center justify-center gap-2 rounded-xl border px-3 py-3 text-[13px] font-extrabold transition active:scale-[.98]" style="border-color:var(--line);background:var(--card)">
          <?= instagramIcon(16) ?> Instagram
        </a>
      </div>
      <a href="<?= e(waLink($owner['whatsapp'], 'Merhaba, Sohbet Sokağı üzerinden reklam ve iş birliği için ulaşıyorum.')) ?>" target="_blank" rel="noopener" class="flex items-center justify-center gap-2 rounded-xl px-3 py-3 text-[13px] font-extrabold shadow-md transition hover:opacity-90 active:scale-[.98]" style="background:var(--accent);color:var(--accent-ink)">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 11 18-5v12L3 14v-3z"/><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"/></svg>
        Reklam ve İş Birliği
      </a>
    </div>

    <div class="mt-6 border-t pt-1.5" style="border-color:var(--line)">
      <?php if (count($rows) === 0): ?>
        <p class="py-14 text-center text-sm font-semibold" style="color:var(--muted)">Henüz gönderi yok.</p>
      <?php else: ?>
      <div id="profileGrid" class="grid grid-cols-3 gap-1.5">
        <?php foreach ($jsonVideos as $p): ?>
        <button data-grid-post="<?= (int)$p['id'] ?>" class="group relative aspect-square overflow-hidden rounded-lg bg-neutral-200" aria-label="<?= e($p['title'] ?: 'Video gönderisi') ?>">
          <?php if ($p['posterUrl']): ?>
            <img src="<?= e($p['posterUrl']) ?>" alt="<?= e($p['title']) ?>" loading="lazy" class="h-full w-full object-cover transition duration-300 group-hover:scale-105">
          <?php else: ?>
            <video src="<?= e($p['videoUrl']) ?>" class="h-full w-full object-cover" muted playsinline preload="metadata"></video>
          <?php endif; ?>
          <?php if ($p['pinned']): ?>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="white" class="absolute right-1.5 top-1.5 drop-shadow-md"><path d="M12 17v5"/><path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1z"/></svg>
          <?php endif; ?>
          <span class="absolute inset-0 flex items-center justify-center gap-3.5 bg-black/40 opacity-0 transition group-hover:opacity-100">
            <span class="flex items-center gap-1 text-[12.5px] font-extrabold text-white">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="white"><path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"/></svg>
              <?= e(formatCount($p['likes'])) ?>
            </span>
            <span class="flex items-center gap-1 text-[12.5px] font-extrabold text-white">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2"><path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>
              <?= e(formatCount($p['views'])) ?>
            </span>
          </span>
        </button>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
<script>
window.SS_VIDEOS = <?= json_encode(array_values($jsonVideos), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
