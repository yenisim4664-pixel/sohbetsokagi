<?php
/**
 * ============================================================
 * SOHBET SOKAĞI — Ana Yapılandırma Dosyası
 * Sadece bu dosyayı kendi hosting bilgilerinize göre düzenleyin.
 * ============================================================
 */

// ---------- MySQL Veritabanı Bilgileri ----------
define('DB_HOST', 'localhost');        // Genelde 'localhost' kalır
define('DB_NAME', 'sohbet_sokagi');    // Veritabanı adı
define('DB_USER', 'root');             // Veritabanı kullanıcı adı
define('DB_PASS', '');                 // Veritabanı şifresi
define('DB_CHARSET', 'utf8mb4');

// ---------- Oturum Güvenliği ----------
// Rastgele uzun bir değerle değiştirmeniz önerilir (örn. 40+ karakter)
define('SESSION_SECRET', 'sohbet-sokagi-gizli-anahtar-2026-degistirin');

// ---------- Zaman Dilimi ----------
date_default_timezone_set('Europe/Istanbul');

// ---------- Hata Raporlama ----------
// Canlıya aldıktan sonra '0' yapmanız önerilir.
define('SS_DEBUG', 0);

if (SS_DEBUG) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(0);
}
