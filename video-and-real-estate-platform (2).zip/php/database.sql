-- ============================================================
-- SOHBET SOKAĞI — Elbistan Video Akışı ve Emlak Platformu
-- MySQL Kurulum Dosyası (saf PHP sürümü)
-- ============================================================
-- ÖNEMLİ (InfinityFree / paylaşımlı hosting kullanıcıları):
-- Ücretsiz hostinglerde phpMyAdmin'den veritabanı OLUŞTURULAMAZ
-- (#1044 "Access denied" hatası bu yüzden çıkar). Bu yüzden bu
-- dosyada CREATE DATABASE satırı YOKTUR.
--
-- DOĞRU KURULUM SIRASI:
-- 1) Hosting panelinden veritabanı oluşturun
--    (InfinityFree: Control Panel > MySQL Databases). Veritabanı
--    adı "if0_43017888_sohbet" gibi otomatik verilir.
-- 2) phpMyAdmin'i açın ve SOL menüden kendi veritabanınıza
--    (if0_43017888_...) tıklayarak içine girin.
-- 3) Üstteki "İçe Aktar" (Import) sekmesinden bu dosyayı seçip
--    "Git"e basın — tablolar seçili veritabanının içine kurulur.
-- 4) Son olarak config.php içindeki DB_HOST, DB_NAME, DB_USER,
--    DB_PASS değerlerini hosting panelinde yazan bilgilerle
--    güncelleyin (InfinityFree'de DB_HOST genelde
--    "sqlXXX.infinityfree.com" gibi bir adrestir, localhost DEĞİLDİR).
-- ============================================================

SET NAMES utf8mb4;
SET time_zone = '+03:00';

-- ------------------------------------------------------------
-- AYARLAR (site adı, tema, sahip profili, SEO, banner, IP'ler)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
  `key`   VARCHAR(100) NOT NULL,
  `value` MEDIUMTEXT   NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ------------------------------------------------------------
-- VİDEOLAR (akış gönderileri)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS videos (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title       VARCHAR(255)  NOT NULL DEFAULT '',
  description TEXT          NOT NULL,
  video_url   TEXT          NOT NULL,
  poster_url  TEXT          NOT NULL,
  views       INT UNSIGNED  NOT NULL DEFAULT 0,
  likes       INT UNSIGNED  NOT NULL DEFAULT 0,
  pinned      TINYINT(1)    NOT NULL DEFAULT 0,
  created_at  DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_videos_order (pinned, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ------------------------------------------------------------
-- HİKAYELER (24 saat sonra otomatik silinir)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS stories (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  media_url  TEXT         NOT NULL,
  media_type VARCHAR(10)  NOT NULL DEFAULT 'image', -- image | video
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at DATETIME     NOT NULL,
  PRIMARY KEY (id),
  KEY idx_stories_exp (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ------------------------------------------------------------
-- EMLAK İLANLARI
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS listings (
  id          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  title       VARCHAR(255) NOT NULL,
  description TEXT         NOT NULL,
  price       BIGINT       NOT NULL DEFAULT 0,
  type        VARCHAR(10)  NOT NULL DEFAULT 'satilik', -- satilik | kiralik
  status      VARCHAR(12)  NOT NULL DEFAULT 'aktif',   -- aktif | satildi | kiralandi
  rooms       VARCHAR(20)  NOT NULL DEFAULT '',
  area        INT UNSIGNED NOT NULL DEFAULT 0,
  floor       VARCHAR(30)  NOT NULL DEFAULT '',
  heating     VARCHAR(40)  NOT NULL DEFAULT '',
  district    VARCHAR(60)  NOT NULL DEFAULT '',
  images      TEXT         NOT NULL, -- JSON dizisi
  phone       VARCHAR(20)  NOT NULL DEFAULT '',
  pinned      TINYINT(1)   NOT NULL DEFAULT 0,
  views       INT UNSIGNED NOT NULL DEFAULT 0,
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_listings_order (pinned, created_at),
  KEY idx_listings_filter (type, status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ------------------------------------------------------------
-- BEĞENİLER (IP ile tekilleştirilmiş)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS likes (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  video_id   INT UNSIGNED NOT NULL,
  ip         VARCHAR(45)  NOT NULL,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_like (video_id, ip)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ------------------------------------------------------------
-- ZİYARETÇİ KAYITLARI (sayaç + şüpheli IP analizi)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS visits (
  id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  ip         VARCHAR(45)   NOT NULL,
  path       VARCHAR(200)  NOT NULL DEFAULT '/',
  ua         VARCHAR(300)  NOT NULL DEFAULT '',
  created_at DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_visits_created (created_at),
  KEY idx_visits_ip (ip)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ------------------------------------------------------------
-- YASAKLI IP ADRESLERİ
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS banned_ips (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  ip         VARCHAR(45)  NOT NULL,
  reason     VARCHAR(200) NOT NULL DEFAULT '',
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_banned_ip (ip)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ------------------------------------------------------------
-- WEB PUSH ABONELİKLERİ
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  endpoint   TEXT         NOT NULL,
  data       TEXT         NOT NULL, -- abonelik JSON'ı (p256dh + auth dahil)
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_endpoint (endpoint(190))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_turkish_ci;

-- ============================================================
-- VARSAYILAN AYARLAR + ÖRNEK İÇERİK
-- ============================================================

INSERT INTO settings (`key`, `value`) VALUES
('site_name', 'Sohbet Sokağı'),
('tagline', 'Elbistan’’ın sokak sokak video ve emlak platformu'),
('logo_url', ''),
('footer_text', '© Sohbet Sokağı — Elbistan. Tüm hakları saklıdır.'),
('theme', '{"accent":"#FF5A3C","accentInk":"#FFFFFF","gradientFrom":"#FF8A00","gradientTo":"#E1306C","bg":"#FAF7F3","card":"#FFFFFF","ink":"#1C1611","muted":"#98897B","line":"#F0E8E0","radius":"20px"}'),
('owner', '{"name":"Sohbet Sokağı","username":"sohbetsokagi","avatar":"assets/img/avatar.jpg","bio":"Elbistan’’ın video ve emlak platformu.\nSokaktan kesitler, güncel ilanlar, şehrin nabzı.\nReklam ve iş birliği için WhatsApp.","verified":true,"instagram":"https://instagram.com/sohbetsokagi","whatsapp":"905551112233","email":"info@sohbetsokagi.com"}'),
('seo', '{"title":"Sohbet Sokağı — Elbistan Video Akışı ve Emlak Platformu","description":"Elbistan merkezli Sohbet Sokağı: şehirden akıcı videolar, 24 saatlik hikayeler ve Sohbet Sokağı Emlak ile kiralık & satılık ilanları. Giriş yok, üyelik yok — herkes izleyebilir.","keywords":"Elbistan, sohbet sokağı, elbistan emlak, elbistan kiralık daire, elbistan satılık ev, elbistan videoları, Kahramanmaraş Elbistan","ogImage":"assets/img/icon-512.png"}'),
('banners', '[{"id":"bnr-emlak","imageUrl":"https://images.pexels.com/photos/6920439/pexels-photo-6920439.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200","title":"Sohbet Sokağı Emlak — Aradığın ev burada","linkUrl":"emlak.php","active":true,"position":"feed-top"},{"id":"bnr-ilan","imageUrl":"https://images.pexels.com/photos/8089172/pexels-photo-8089172.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200","title":"Kiralık mı arıyorsun? Güncel ilanlara göz at","linkUrl":"emlak.php","active":true,"position":"feed-inline"},{"id":"bnr-isbirligi","imageUrl":"https://images.pexels.com/photos/6585598/pexels-photo-6585598.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200","title":"İşletmeni binlerce Elbistanlıya tanıt — Reklam ver","linkUrl":"https://wa.me/905551112233?text=Merhaba,%20reklam%20vermek%20istiyorum.","active":true,"position":"emlak-top"}]'),
('owner_ips', ''),
('push_on_post', '1'),
-- Varsayılan admin şifresi: admin123 (panele girip Güvenlik sekmesinden değiştirin!)
('admin_password_hash', '85c5a50eee07ca7b14d5fea132a70376b68b1720848dc19e8c37f5ec8d763ca9')
ON DUPLICATE KEY UPDATE `value` = VALUES(`value`);

INSERT INTO videos (title, description, video_url, poster_url, views, likes, pinned, created_at) VALUES
('Elbistan sokaklarından herkese merhaba!', 'Sohbet Sokağı artık yayında. Şehrin nabzı burada atıyor — videolar, hikayeler ve emlak ilanlarıyla takipte kalın.', 'https://videos.pexels.com/video-files/33567764/14271284_1920_1080_60fps.mp4', 'https://images.pexels.com/videos/33567764/pexels-photo-33567764.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200', 1284, 342, 1, NOW() - INTERVAL 31 HOUR),
('Elbistan ovasında sisli bir sabah', 'Gün doğumunda ovanın üzerinde süzülen sis... Bazen şehrin en güzel hali sessiz halidir.', 'https://videos.pexels.com/video-files/6062828/6062828-uhd_2560_1440_30fps.mp4', 'https://images.pexels.com/videos/6062828/pexels-photo-6062828.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200', 2143, 587, 0, NOW() - INTERVAL 22 HOUR),
('Çarşıda hafta sonu bereketi', 'Elbistan çarşısı yine capcanlı. Esnafımıza hayırlı işler, hemşehrilerimize keyifli alışverişler.', 'https://videos.pexels.com/video-files/39571015/16865430_2160_3840_60fps.mp4', 'https://images.pexels.com/videos/39571015/pexels-photo-39571015.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630', 864, 219, 0, NOW() - INTERVAL 14 HOUR),
('Akşam üzeri sokak turu', 'Gün batarken sokaklarda kısa bir gezinti. Bu şehirde her köşe ayrı bir hikaye.', 'https://videos.pexels.com/video-files/16668257/16668257-uhd_2160_3840_24fps.mp4', 'https://images.pexels.com/videos/16668257/pexels-photo-16668257.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=630', 697, 180, 0, NOW() - INTERVAL 7 HOUR),
('Sokakta hayat var', 'Sabahın erken saatlerinden itibaren şehir uyanıyor. Sohbet Sokağı ile anı yakala.', 'https://videos.pexels.com/video-files/5044654/5044654-hd_1920_1080_25fps.mp4', 'https://images.pexels.com/videos/5044654/pexels-photo-5044654.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=630&w=1200', 512, 143, 0, NOW() - INTERVAL 2 HOUR);

INSERT INTO stories (media_url, media_type, created_at, expires_at) VALUES
('https://images.pexels.com/photos/8815915/pexels-photo-8815915.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800', 'image', NOW() - INTERVAL 6 HOUR, NOW() + INTERVAL 18 HOUR),
('https://images.pexels.com/photos/8470800/pexels-photo-8470800.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800', 'image', NOW() - INTERVAL 4 HOUR, NOW() + INTERVAL 20 HOUR),
('https://images.pexels.com/photos/7587828/pexels-photo-7587828.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200', 'image', NOW() - INTERVAL 2 HOUR, NOW() + INTERVAL 22 HOUR),
('https://videos.pexels.com/video-files/16668257/16668257-uhd_2160_3840_24fps.mp4', 'video', NOW() - INTERVAL 1 HOUR, NOW() + INTERVAL 23 HOUR);

INSERT INTO listings (title, description, price, type, status, rooms, area, floor, heating, district, images, pinned, views, created_at) VALUES
('Cumhuriyet Mah. 3+1 Satılık Daire', 'Elbistan merkezde, okul ve çarşıya yürüme mesafesinde, geniş ve ferah 3+1 daire. Güney cepheli, gün boyu güneş alır. Binada asansör ve otopark mevcuttur. Krediye uygundur.', 3450000, 'satilik', 'aktif', '3+1', 145, '3. Kat', 'Doğalgaz Kombi', 'Cumhuriyet', '["https://images.pexels.com/photos/11631278/pexels-photo-11631278.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200","https://images.pexels.com/photos/8089172/pexels-photo-8089172.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200","https://images.pexels.com/photos/6585598/pexels-photo-6585598.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"]', 1, 342, NOW() - INTERVAL 50 HOUR),
('Pınarbaşı’’nda 2+1 Kiralık Eşyalı Daire', 'Tam eşyalı, temiz ve bakımlı 2+1 daire. Öğrenci ve memur için ideal. Merkezi konum, ulaşım sorunu yok. Depozito 2 kiradır.', 22500, 'kiralik', 'aktif', '2+1', 95, '5. Kat', 'Doğalgaz Kombi', 'Pınarbaşı', '["https://images.pexels.com/photos/16110999/pexels-photo-16110999.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200","https://images.pexels.com/photos/19916712/pexels-photo-19916712.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200","https://images.pexels.com/photos/6580396/pexels-photo-6580396.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"]', 1, 511, NOW() - INTERVAL 40 HOUR),
('Güneşli Mah. Müstakil Bahçeli Ev', '210 m² kullanım alanlı, 400 m² bahçe içerisinde müstakil ev. Meyve ağaçları, kiler ve otopark mevcut. Sessiz, sakin bir mahallede aile yaşamına uygun.', 5750000, 'satilik', 'aktif', '4+1', 210, 'Müstakil', 'Kat Kaloriferi', 'Güneşli', '["https://images.pexels.com/photos/5674684/pexels-photo-5674684.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200","https://images.pexels.com/photos/6920439/pexels-photo-6920439.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200","https://images.pexels.com/photos/27459248/pexels-photo-27459248.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"]', 0, 289, NOW() - INTERVAL 30 HOUR),
('Orhangazi’’de Satılık Dükkan — Cadde Üzeri', 'Ana cadde üzerinde, yüksek yaya trafiğine sahip 120 m² dükkan. Her türlü ticari faaliyete uygun. Yatırım için kaçırılmayacak fırsat.', 8250000, 'satilik', 'aktif', 'Dükkan', 120, 'Zemin Kat', 'Klima', 'Orhangazi', '["https://images.pexels.com/photos/31656156/pexels-photo-31656156.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200","https://images.pexels.com/photos/31656143/pexels-photo-31656143.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"]', 0, 176, NOW() - INTERVAL 26 HOUR),
('Tepebaşı 1+1 Kiralık Rezidans', 'Yeni binada, modern tasarımlı 1+1 rezidans dairesi. Eşyalı teslim. Site içerisinde güvenlik ve otopark mevcut.', 18000, 'kiralik', 'kiralandi', '1+1', 62, '7. Kat', 'Merkezi Isıtma', 'Tepebaşı', '["https://images.pexels.com/photos/37224965/pexels-photo-37224965.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200","https://images.pexels.com/photos/19916712/pexels-photo-19916712.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"]', 0, 420, NOW() - INTERVAL 70 HOUR),
('Yunus Emre Mah. 4+1 Lüks Dubleks', 'Geniş aileler için 4+1 dubleks. Teraslı, ebeveyn banyolu, ankastre mutfaklı. Elbistan’’ın en nezih mahallelerinden birinde.', 6900000, 'satilik', 'satildi', '4+1', 240, '6-7. Kat (Dubleks)', 'Doğalgaz Kombi', 'Yunus Emre', '["https://images.pexels.com/photos/31656143/pexels-photo-31656143.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200","https://images.pexels.com/photos/8089172/pexels-photo-8089172.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200","https://images.pexels.com/photos/6580396/pexels-photo-6580396.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"]', 0, 638, NOW() - INTERVAL 90 HOUR);
